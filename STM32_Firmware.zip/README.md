# STM32 Zipper CNC — V17.1.0 Pure Bare-Metal CMSIS Production Edition (C6T6 32KB & C8T6 64KB)

**Organization:** Nipon Zipper Industries Pvt. Ltd. (Sarigam GIDC / Surat, Gujarat, India)  
**Lead Systems Architect:** Rajesh Shah  
**Version:** `V17.1.0-PA0-TIM2-CAPTURE-PA8-TIM1` (100% Original C8T6 Features in Pure Bare-Metal CMSIS)  
**Target MCUs:** `STM32F103C6T6` (32 KB Flash / 10 KB RAM) & `STM32F103C8T6` (64 KB Flash / 20 KB RAM) @ 72 MHz

---

## 1. Overview & Bare-Metal CMSIS Architecture

This repository contains the complete, un-trimmed **Original C8T6 V17.1.0 Production Firmware** converted directly to **Pure Bare-Metal CMSIS Register-Level C/C++** so that 100% of the original features fit comfortably inside the **STM32F103C6T6 (32 KB Flash)** boundary (~18–22 KB total binary size, leaving >9 KB free Flash headroom and reserving Page 31 at `0x08007C00` for dual-slot ping-pong EEPROM persistence).

### Key Bare-Metal Register Subsystems
1. **Direct CMSIS GPIO Controller (`GPIOA`, `GPIOB`, `GPIOC`)**:
   - Single-cycle register reads/writes (`IDR`, `BSRR`, `CRL`, `CRH`), eliminating `wiring_digital.c` and `PinMap_GPIO` lookup tables.
2. **Direct CMSIS `I2C1` Driver (`0x40005400`, `PB6`=SCL, `PB7`=SDA)**:
   - Drives the 16x2 PCF8574 HD44780 LCD (`0x27`) directly via `I2C1->CR1`, `I2C1->DR`, `I2C1->SR1`, `I2C1->SR2` with automatic 9-clock SCL bus recovery and bounded hardware timeouts. Eliminates `Wire.h`, `TwoWire`, `HAL_I2C`, and `HAL_DMA`.
3. **Direct CMSIS `FLASH` Dual-Slot Ping-Pong Persistence (`0x40022000`, Page 31 @ `0x08007C00`)**:
   - Stores Slot 0 (`0..127`) and Slot 1 (`128..255`) with CRC32 verification directly in hardware Flash at `0x08007C00` (31 KB offset — valid on both 32 KB C6T6 and 64 KB C8T6). Eliminates `EEPROM.h`, `HAL_FLASH`, and 1 KB RAM buffer overhead.
4. **Direct Silicon NVIC Timer Interrupts (`TIM1`, `TIM2`, `TIM4`)**:
   - `TIM1_UP_IRQHandler` (Priority 0): Drives `PA8` (`PUL-`) in hardware PWM Mode 2 (5.0 µs active-LOW pulse, 8.0 µs opto-safe minimum period floor).
   - `TIM2_IRQHandler` (Priority 1): Latches `PA0` cam proximity falling edges in hardware via `TIM2->CCR1` with silicon digital filter `IC1F = 0011` (`N=8`).
   - `TIM4_IRQHandler` (Priority 2 on C8T6) / `TIM2` 32-bit 1.0 MHz monotonic hardware clock on C6T6.
5. **Zero-`snprintf` Lightweight Formatter & Pure 32-Bit Single-Precision Math**:
   - Eliminates `newlib` `_svfprintf_r` and 64-bit software `double` emulation while preserving 100% character-for-character identical LCD output.

---

## 2. Full Original C8T6 Feature Set Retained (Zero Feature Trimming)

- **Level 1 Main Settings Menu (7 Options)**:
  1. `1. Max RPM` (`0100..4000 RPM`)
  2. `2. Motor Dir` (`NORMAL [FW]` $\leftrightarrow$ `REVERSE [RV]`)
  3. `3. Auto Lock` (`OFF` / `010..300s`, default `30s`)
  4. `4. Backlight` (`ALWAYS ON` / `010..300s` with Wake-Up Shield)
  5. `5. Diagnostics` (All 5 Diagnostic Pages)
  6. `6. Advance Menu` (5 Machine Geometry Options)
  7. `7. Save & Exit` (Dual-Slot Ping-Pong Flash Save)
- **Level 2 Advance Menu (5 Options)**:
  1. `1. Driver Res` (16 DM542 DIP resolutions: `400..51200`)
  2. `2. Roller Dia` (`010.0..100.0 mm`)
  3. `3. Feed Angle` (`030..270 deg`)
  4. `4. Safety Margin` (`00..29 %`)
  5. `5. << Back`
- **5-Page Interactive Diagnostics (`menuState == 9`)**:
  - Page 1: `ACTIVE ISSUE` (Real-time configuration feasibility & RPM/Resolution advisor)
  - Page 2: `STEPPER JOG TST` (`[UP]` = Forward Jog, `[DOWN]` = Reverse Jog at standstill)
  - Page 3: `OPTO SINK TST` (Hold `[UP]` to test `PA8` optocoupler current sinking)
  - Page 4: `TRIGGER & NOISE` (`T:xxxxx O:xx R:xx` live trigger, overcapture, and noise counters)
  - Page 5: `V17.1.0 (NIPON)` (`DEV: RAJESH SHAH` / `BLD: OCT-2026`)

---

## 3. Repository Structure

```text
├── .github/workflows/
│   └── auto_unzip_compile.yml                 # Automated CI Test + Bare-Metal C6T6/C8T6 Build
├── STM32_Zipper_CNC_V17_1_0_Firmware/
│   ├── STM32_Zipper_CNC_V17_1_0_Firmware.ino  # Authoritative Bare-Metal CMSIS V17.1.0 Sketch
│   ├── hal_conf_extra.h                       # Disables unused HAL drivers & HardwareTimer C++ wrapper
│   ├── build_opt.h                            # Compiler optimization flags (-Os -flto -fsingle-precision-constant)
│   ├── burst_queue.h                          # Lock-free SPSC burst queue
│   ├── hardware_capture_spec.h                # TIM2 PA0 capture invariants
│   ├── motion_scheduler.h                     # Q16.16 servo-synchronized step scheduler
│   └── pulsestep_persistence.h                # Dual-slot ping-pong CRC32 record structures
├── include/ & src/                            # Synchronized header mirrors for host test runner
├── tests/
│   ├── run_tests.sh                           # Master 11-suite regression runner
│   └── test_*.cpp                             # 11 formal & HIL verification suites
└── README.md
```

---

## 4. How to Compile on GitHub Actions (New Repository)

1. Create a new GitHub repository.
2. Add `.github/workflows/auto_unzip_compile.yml` and push either the structured repository files or `STM32_Firmware.zip`.
3. Open the **Actions** tab on GitHub — the workflow automatically runs all 11 host regression suites, compiles the Bare-Metal CMSIS binary for `BLUEPILL_F103C6` (< 31 KB, compatible with both C6T6 and C8T6), verifies the ARM Cortex-M3 vector table, and uploads `STM32_Zipper_CNC_V17_1_0_Production_Binary`.
