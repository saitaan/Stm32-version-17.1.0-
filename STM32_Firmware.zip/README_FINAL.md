# STM32 Zipper CNC — V17.1.0 Production Master Firmware Package

## Release Overview
Authoritative production firmware for the **Nipon Zipper Industries Pvt. Ltd.** (Sarigam GIDC / Surat, Gujarat) high-speed zipper stitching CNC feeder (`STM32F103C8T6` Blue Pill @ 72 MHz, Lead Systems Architect: **Rajesh Shah**).

### 1. Direct Max-RPM Clamped Step Engine & Timer Architecture
- **MCU:** `STM32F103C8T6` (ARM Cortex-M3 @ 72 MHz)
- **Direct `Max RPM` Clamp Step Engine:**
  - Stepper burst timing (`configuredDeadlineUs` and `W`) is directly governed by **`maximumBurstWindowUs(maxRPMSetting, feedAngleDeg, safetyMarginPercent)`** with zero redundant per-stitch dynamic-RPM division overhead inside the real-time interrupt.
  - Changing **`1. Max RPM`** (or `Feed Angle` / `Safety Margin`) in Settings immediately updates the clamp window and step pulse width (`W` / `TIM1->ARR`).
  - Safe for both **Direct Button-Operated (Push-Button Auto Start)** and **Foot-Pedal** 500W AC Servo machines (burst finishes within `4,250 µs` at `3000 RPM` default, guaranteeing zero step-pulse overlap and zero needle collision).
  - Measured `PA0` trigger intervals (`diff`) are used strictly for **Live 4-Digit RPM Display** (`0000` at standstill, live RPM while running), **Noise/Glitch Rejection**, **Standstill Accumulator Reset (`> 400 ms` / `> 2.0 s`)**, and **Motion Sync Watchdog (`>= 150 RPM`)**.
- **`PA0` (`proxSensorPin`):** Cam proximity sensor input (`TIM2_CH1` hardware falling-edge capture, `1 MHz` counter, `IC1F = 0x3` 8-cycle silicon digital filter, internal pull-up + external `PC817` optocoupler). Sole authoritative motion trigger (`NVIC Priority 1`).
- **`PA8` (`stepPin`):** Stepper driver `PUL-` output (`TIM1_CH1` hardware PWM Mode 2 active-low burst engine, `5.0 µs` pulse width, `NVIC Priority 0`, `7 µs` hardware floor).
- **`PA2` (`dirPin`):** Stepper driver `DIR-` output (`HIGH` = Normal Forward `[FW]`, `LOW` = Reverse `[RV]`, with `20 µs` hardware setup/hold guard).
- **`PB1` (`motorEnaPin`):** Stepper driver `ENA-` output (`LOW` = Driver Active/Enabled, `HIGH` = Standstill Motor Sleep Mode with 1-cycle `13.8 ns` hardware wake ISR `tim2WakeOnceCallback`).
- **`PB6` / `PB7` (`I2C1_SCL` / `I2C1_SDA`):** 16x2 I2C LCD (`0x27` PCF8574) driven by deterministic `FastLiquidCrystal_I2C` (`100 kHz` zero-blink power-on boot splash `NIPON ZIPPER IND` / `DEV: RAJESH SHAH` for `2.0 s`, switching to `400 kHz` Fast-Mode in `loop()`).
- **Universal 3-Mode Keypad (Single Firmware, Single PCB):**
  - **3-Button Mode (`keypadMode = 0`):** `PB12` (`[DOWN]`), `PB13` (`[UP]`), `PB14` (`[MODE]`) to `GND`.
  - **6-Button Mode (`keypadMode = 1`):** Adds `PB10` (`[RIGHT]`), `PB11` (`[LEFT]`), `PB15` (`[BACK]`) to `GND`.
  - **4x4 Matrix Mode (`keypadMode = 2`):** Rows on `PB12..PB15` (`INPUT_PULLUP`), Columns on `PB8..PB11`.
  - **One-Time Guided Calibration Gate:** Automatically detects and locks 3-Button, 6-Button, or 4x4 Matrix mode in EEPROM on first boot or after Factory Reset.

## 2. Operator Controls & Main Screen Behavior (`menuState == 0`)
- **Main Screen Telemetry:**
  - Row 0: `S:8  0000 F:1.77` at standstill (`0 RPM`), or `S:8  2400 F:1.77` while running.
  - Row 1: `P:80.0 W:53  [U]` (Active Pulses, Step Period `µs`, Notification Bell `\x01`: Steady ON at `W = 9 µs`, Blinking at `W <= 8 µs`, Hard Floor `8 µs`, Lock State `[U]`/`[L]`).
- **4x4 Direct Speed Dial (4x4 Matrix Mode):**
  - Dialing `0..9` on the Main Screen opens Direct Speed Dial (`SET: 80_ / [#]OK   [C]CLEAR`), `*` = Decimal (`.`), `#` = Confirm immediately (Tenths-Only rule: `88*54#` -> `88.50`).
- **Sleep Wake-Up Shield:** When the screen is OFF or motor is asleep, the first button press only wakes the screen and motor into Active Standby and consumes that press so no pulse or setting is altered accidentally.

## 3. 2-Tier Settings Menu (`menuState == 1` & `menuState == 2`)
### Level 1: Main User Menu (8 Options — `menuState == 1`)
1. **`1. Max RPM`:** `0100` to `4000 RPM` (Default `3000 RPM`). Directly updates the step window clamp (`maximumBurstWindowUs`) and `W`.
2. **`2. Motor Dir`:** `NORMAL [FW]` <-> `REVERSE [RV]` (Default `NORMAL [FW]`).
3. **`3. Auto Lock`:** `Lock: 030s [ON]` <-> `Lock: OFF [OFF]` (`010s..300s`, Default `030s [ON]`).
4. **`4. Backlight`:** `ALWAYS ON` (`000s`) or `010s..300s` timeout (Default `ALWAYS ON`).
5. **`5. Motor Sleep`:** `OFF` (`000m`) or `020m..300m` standstill sleep timer on `PB1` (`20 min` minimum limit, Default `OFF`).
6. **`6. Diagnostics`:** Opens the **Streamlined 6-Page Diagnostics Suite** (`menuState = 9`, Page 1 = `ACTIVE ISSUE` at 0 scrolls).
7. **`7. Advance Menu`:** Opens **Level 2 Advance Menu** (`menuState = 2`).
8. **`8. Save & Exit`:** Opens `SAVE CHANGES? >YES  NO` (`menuState = 13`), writing selectively to Dual-Slot Ping-Pong EEPROM (`0x5A431710UL`).

### Level 2: Advance Menu (5 Options — `menuState == 2`)
1. **`1. Driver Res`:** Discrete DM542 DIP resolutions (`400` to `51200`, Default `6400 steps`).
2. **`2. Roller Dia`:** 4-digit Digital Watch / 4x4 editor (`010.0` to `100.0 mm`, Default `045.0 mm`).
3. **`3. Feed Angle`:** 3-digit Digital Watch / 4x4 editor (`030` to `270 deg`, Default `090 deg`).
4. **`4. Safety Margin`:** 2-digit Digital Watch / 4x4 editor (`00` to `29 %`, Default `15 %`).
5. **`5. << Back`:** Returns to Level 1 Main User Menu.

## 4. Build & Regression Test Verification
Run all 11 fail-fast host regression & HIL simulation suites:
```bash
bash tests/run_tests.sh
```
