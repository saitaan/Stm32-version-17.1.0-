#include "baremetal_cmsis_stm32f103.h"
#include <cmath>
#include <cstddef>
#include <cstdint>
/*
====================================================================================================
PROJECT  : STM32 ZIPPER CNC (ADAPTIVE SERVO-SYNC MASTER-FOLLOWER ENGINE)
VERSION  : 17.1.0 (3-BUTTON DEDICATED / 2-TIER MENU / 5-PAGE DIAG / 2-TIER BELL / C6T6 & C8T6)
AUTHOR   : RAJESH SHAH / INDUSTRIAL AUTOMATION & EMBEDDED SYSTEMS
DATE     : OCTOBER 2026
TARGET   : STM32F103C6T6 (32KB) & STM32F103C8T6 (64KB) @ 72MHz
LOCATION : NIPON ZIPPER INDUSTRIES PVT LTD, SARIGAM GIDC / SURAT, GUJARAT, INDIA

VERSION 17.1.0 PRODUCTION MASTER ARCHITECTURE & SPECIFICATIONS:
1. DEDICATED 3-BUTTON KEYPAD HARDWARE (SINGLE FIRMWARE, ZERO CALIBRATION GATE):
   - 3-Button Mode: PB12 (Down), PB13 (Up), PB14 (Mode) to GND (Active-LOW INPUT_PULLUP).
   - Boots directly to Main Screen after 2.0s splash screen.
2. 2-TIER SETTINGS MENU:
   - Level 1 Main User Menu (7 Options): Max RPM (0100..4000), Motor Dir, Auto Lock (010..300s),
     Backlight (ALWAYS ON / 010..300s), Diagnostics, Advance Menu, Save & Exit.
   - Level 2 Advance Menu (5 Options): Driver Res (16 DIP steps), Roller Dia (010.0..100.0 mm),
     Feed Angle (030..270 deg), Safety Margin (00..29%), << Back.
3. STREAMLINED 5-PAGE DIAGNOSTICS (menuState == 9):
   - Page 1: ACTIVE ISSUE (Immediate priority recommendation: SET RES = 6400 or MAX RPM <= XXXX, at 0 scrolls!)
   - Page 2: STEPPER JOG TST (UP:FWD / DN:REV)
   - Page 3: OPTO SINK TST   (HOLD [UP] TEST)
   - Page 4: TRIGGER & NOISE (T:Triggers, O:Overruns, R:Rejected noise count)
   - Page 5: V17.1.0 (NIPON) (DEV: RAJESH SHAH / BLD: OCT-2026)
4. 2-TIER NOTIFICATION BELL (Slot 1 '\x01') & OPTO-SAFE HARDWARE CLAMP:
   - Clean Line 2: "P:80.0 W:53  [U]".
   - Notification Bell ('\x01' at Col 12): Steady Solid ON at W = 9us (Early Warning),
     Blinking at W <= 8us (Critical Limit Warning), OFF at W >= 10us.
   - Hardware Timer Floor: Clamped strictly at 8us (SERVO_PERIOD_MIN_US = 8U) ensuring 5.0us active pulse +
     3.0us space to protect Leadshine DM542 optocoupler turn-off time.
5. BACKLIGHT WAKE-UP SHIELD:
   - When LCD backlight is OFF, first button press only wakes the screen and consumes that press.
6. INDUSTRIAL DUAL WATCHDOG TUNING:
   - Hardware IWDG: 500 ms (PR=0x03, RLR=625).
   - Software Motion Watchdog: 2.5x Interval (50ms floor), armed strictly at >= 150 RPM.
====================================================================================================
*/


// =========================================================================
// ULTRA-LIGHTWEIGHT ZERO-SNPRINTF INTEGER FORMATTING ENGINE (C6T6 FLASH SAVER)
// Completely eliminates newlib _vfprintf_r and float printing libraries (~8KB saving)
// =========================================================================
static void formatUint(char *buf, uint32_t val, int width, bool padZero = false) {
    int idx = width - 1;
    for (int i = 0; i < width; ++i) buf[i] = padZero ? '0' : ' ';
    if (val == 0) {
        buf[idx] = '0';
        return;
    }
    while (val > 0 && idx >= 0) {
        buf[idx--] = '0' + (char)(val % 10U);
        val /= 10U;
    }
}

static void formatFixed1(char *buf, uint32_t tenths, int intWidth, bool padZero = false) {
    uint32_t intPart = tenths / 10U;
    uint32_t fracPart = tenths % 10U;
    formatUint(buf, intPart, intWidth, padZero);
    buf[intWidth] = '.';
    buf[intWidth + 1] = '0' + (char)fracPart;
}

static void formatFixed2(char *buf, uint32_t hundredths, int intWidth, bool padZero = false) {
    uint32_t intPart = hundredths / 100U;
    uint32_t fracPart = hundredths % 100U;
    formatUint(buf, intPart, intWidth, padZero);
    buf[intWidth] = '.';
    buf[intWidth + 1] = '0' + (char)(fracPart / 10U);
    buf[intWidth + 2] = '0' + (char)(fracPart % 10U);
}

#include "burst_queue.h"
#include "motion_scheduler.h"
#include "hardware_capture_spec.h"
#include "pulsestep_persistence.h"
#ifdef HOST_SIMULATION_TEST
#define bm_millis         millis
#define bm_micros         micros
#define bm_delay_ms       delay
#define bm_delay_us       delayMicroseconds
#define bm_pinMode        pinMode
#define bm_digitalRead    digitalRead
#define bm_digitalWrite   digitalWrite
#elif !defined(PURE_BAREMETAL_BUILD)
#define bm_millis         millis
#define bm_micros         micros
#define bm_delay_ms       delay
#define bm_delay_us       delayMicroseconds
#endif
#ifndef nvic_irq_enable
#define nvic_irq_enable(irq) NVIC_EnableIRQ(irq)
#endif
#ifndef TIM_DIER_CC1IE
#define TIM_DIER_CC1IE (1U << 1)
#endif
#ifndef TIM_CCMR1_IC1F
#define TIM_CCMR1_IC1F (0xFU << 4)
#endif

#ifndef HOST_SIMULATION_TEST
#ifndef PB0
#define PB0 0
#endif
static __attribute__((noinline)) void bm_gpio_config_pin(GPIO_TypeDef *port, uint8_t bit, uint8_t cnf_mode, int pull) {
    if (port == GPIOA)      RCC->APB2ENR |= (1U << 2);
    else if (port == GPIOB) RCC->APB2ENR |= (1U << 3);
    else if (port == GPIOC) RCC->APB2ENR |= (1U << 4);
    if (bit < 8U) {
        uint32_t shift = (uint32_t)bit * 4U;
        port->CRL = (port->CRL & ~(0xFUL << shift)) | ((uint32_t)cnf_mode << shift);
    } else {
        uint32_t shift = (uint32_t)(bit - 8U) * 4U;
        port->CRH = (port->CRH & ~(0xFUL << shift)) | ((uint32_t)cnf_mode << shift);
    }
    if (pull > 0)      port->BSRR = (1UL << bit);
    else if (pull < 0) port->BSRR = (1UL << (bit + 16U));
}

static __attribute__((noinline)) void bm_pinMode(int pin, int mode) {
    uint8_t cnf_mode = (mode == OUTPUT) ? 0x3U : ((mode == INPUT_PULLUP) ? 0x8U : 0x4U);
    int pull = (mode == INPUT_PULLUP) ? 1 : 0;
    if (pin == PA0)       bm_gpio_config_pin(GPIOA, 0,  cnf_mode, pull);
    else if (pin == PA2)  bm_gpio_config_pin(GPIOA, 2,  cnf_mode, pull);
    else if (pin == PA8)  bm_gpio_config_pin(GPIOA, 8,  cnf_mode, pull);
    else if (pin == PB1)  bm_gpio_config_pin(GPIOB, 1,  cnf_mode, pull);
    else if (pin == PB12) bm_gpio_config_pin(GPIOB, 12, cnf_mode, pull);
    else if (pin == PB13) bm_gpio_config_pin(GPIOB, 13, cnf_mode, pull);
    else if (pin == PB14) bm_gpio_config_pin(GPIOB, 14, cnf_mode, pull);
    else if (pin == PC13) bm_gpio_config_pin(GPIOC, 13, (mode == OUTPUT) ? 0x2U : cnf_mode, pull);
}

static inline __attribute__((always_inline)) int bm_digitalRead(int pin) {
    if (pin == PA0)  return (GPIOA->IDR & (1UL << 0))  ? HIGH : LOW;
    if (pin == PB12) return (GPIOB->IDR & (1UL << 12)) ? HIGH : LOW;
    if (pin == PB13) return (GPIOB->IDR & (1UL << 13)) ? HIGH : LOW;
    if (pin == PB14) return (GPIOB->IDR & (1UL << 14)) ? HIGH : LOW;
    return HIGH;
}

static inline __attribute__((always_inline)) void bm_digitalWrite(int pin, int val) {
    const uint32_t rstShift = (val == LOW) ? 16U : 0U;
    if (pin == PA8)       GPIOA->BSRR = (1UL << (8U  + rstShift));
    else if (pin == PA2)  GPIOA->BSRR = (1UL << (2U  + rstShift));
    else if (pin == PB1)  GPIOB->BSRR = (1UL << (1U  + rstShift));
    else if (pin == PC13) GPIOC->BSRR = (1UL << (13U + rstShift));
}

#define pinMode      bm_pinMode
#define digitalRead  bm_digitalRead
#define digitalWrite bm_digitalWrite
// =========================================================================
// 1. BARE-METAL CMSIS I2C1 REGISTER DRIVER (PB6=SCL, PB7=SDA, ZERO Wire.h)
// Eliminates TwoWire, twi.c, HAL_I2C, and HAL_DMA (~5.5 KB Flash saved).
// =========================================================================
struct BM_I2C_Regs {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t OAR1;
    volatile uint32_t OAR2;
    volatile uint32_t DR;
    volatile uint32_t SR1;
    volatile uint32_t SR2;
    volatile uint32_t CCR;
    volatile uint32_t TRISE;
};
#define BM_I2C1 ((BM_I2C_Regs *)0x40005400UL)

static uint32_t s_bm_i2c_clock = 100000UL;

static void bm_i2c1_init(uint32_t clockHz) {
    s_bm_i2c_clock = clockHz;
    RCC->APB2ENR |= (1UL << 3) | (1UL << 0); // IOPBEN | AFIOEN
    RCC->APB1ENR |= (1UL << 21);             // I2C1EN
    AFIO->MAPR   &= ~(1UL << 1);             // I2C1_REMAP = 0 (PB6=SCL, PB7=SDA)

    // Wait for any in-flight I2C frame before reconfiguring
    uint32_t w = 36000UL;
    while ((BM_I2C1->SR2 & (1UL << 1)) && --w) {}

    if ((BM_I2C1->CR1 & 1UL) == 0UL || w == 0UL) {
        // Release stuck slave if needed via 9 SCL clock pulses in Open-Drain mode
        GPIOB->BSRR = (1UL << 6) | (1UL << 7);
        GPIOB->CRL  = (GPIOB->CRL & 0x00FFFFFFUL) | 0x77000000UL; // GP Open-Drain 50MHz
        for (int i = 0; i < 9; i++) {
            GPIOB->BSRR = (1UL << (6 + 16));
            bm_delay_us(5);
            GPIOB->BSRR = (1UL << 6);
            bm_delay_us(5);
        }
        RCC->APB1RSTR |= (1UL << 21);
        RCC->APB1RSTR &= ~(1UL << 21);
    }

    // Connect PB6 (SCL) & PB7 (SDA) to I2C1 Alternate Function Open-Drain 50MHz
    GPIOB->BSRR = (1UL << 6) | (1UL << 7);
    GPIOB->CRL  = (GPIOB->CRL & 0x00FFFFFFUL) | 0xFF000000UL;

    BM_I2C1->CR1 &= ~(1UL << 0);
    BM_I2C1->CR1  = (1UL << 15);
    BM_I2C1->CR1  = 0UL;
    BM_I2C1->CR2  = 36UL; // APB1 = 36 MHz
    if (clockHz >= 400000UL) {
        BM_I2C1->CCR   = (1UL << 15) | 30UL; // 400 kHz Fast-Mode
        BM_I2C1->TRISE = 11UL;
    } else {
        BM_I2C1->CCR   = 180UL;              // 100 kHz Standard-Mode
        BM_I2C1->TRISE = 37UL;
    }
    BM_I2C1->CR1 |= (1UL << 0); // PE = 1
}

static void bm_i2c1_write_byte(uint8_t addr7, uint8_t data) {
    // 1. Wait until I2C bus is idle and any previous STOP condition has finished
    uint32_t t = 72000UL;
    while (((BM_I2C1->SR2 & (1UL << 1)) || (BM_I2C1->CR1 & (1UL << 9))) && --t) {}
    if (t == 0UL) {
        bm_i2c1_init(s_bm_i2c_clock);
        return;
    }

    // 2. Generate START condition and wait for SB (Bit 0)
    BM_I2C1->CR1 |= (1UL << 8);
    t = 72000UL;
    while (!(BM_I2C1->SR1 & (1UL << 0)) && --t) {}
    if (t == 0UL) {
        BM_I2C1->CR1 |= (1UL << 9);
        return;
    }

    // 3. Send 7-bit slave address (write mode) and wait for ADDR (Bit 1) or AF (Bit 10)
    BM_I2C1->DR = (uint32_t)(addr7 << 1);
    t = 72000UL;
    while (!(BM_I2C1->SR1 & ((1UL << 1) | (1UL << 10))) && --t) {}
    if ((BM_I2C1->SR1 & (1UL << 10)) || t == 0UL) {
        BM_I2C1->SR1 &= ~(1UL << 10);
        BM_I2C1->CR1 |= (1UL << 9);
        t = 18000UL;
        while ((BM_I2C1->CR1 & (1UL << 9)) && --t) {}
        return;
    }

    // 4. Clear ADDR flag by reading SR1 followed by SR2
    (void)BM_I2C1->SR1;
    (void)BM_I2C1->SR2;

    // 5. Write data byte and wait strictly for BTF (Bit 2 = Byte Transfer Finished on wire!)
    BM_I2C1->DR = data;
    t = 72000UL;
    while (!(BM_I2C1->SR1 & ((1UL << 2) | (1UL << 10))) && --t) {}
    if (BM_I2C1->SR1 & (1UL << 10)) {
        BM_I2C1->SR1 &= ~(1UL << 10);
    }

    // 6. Generate STOP condition and wait for hardware to complete STOP on physical bus
    BM_I2C1->CR1 |= (1UL << 9);
    t = 36000UL;
    while ((BM_I2C1->CR1 & (1UL << 9)) && --t) {}
}



// =========================================================================
// 2. BARE-METAL CMSIS FLASH PERSISTENCE ENGINE (PAGE 31 @ 0x08007C00)
// Eliminates EEPROM.h, stm32_eeprom.c, HAL_FLASH, and 1KB RAM buffer (~3.5 KB).
// =========================================================================
struct BM_FLASH_Regs {
    volatile uint32_t ACR;
    volatile uint32_t KEYR;
    volatile uint32_t OPTKEYR;
    volatile uint32_t SR;
    volatile uint32_t CR;
    volatile uint32_t AR;
    volatile uint32_t RESERVED;
    volatile uint32_t OBR;
    volatile uint32_t WRPR;
};
#define BM_FLASH             ((BM_FLASH_Regs *)0x40022000UL)
#define BM_EEPROM_FLASH_BASE 0x08007C00UL

class BareMetalFlashEEPROM {
private:
    uint8_t _cache[256];
    bool    _initialized = false;

    void ensureCache() {
        if (!_initialized) {
            memcpy(_cache, (const void *)BM_EEPROM_FLASH_BASE, 256);
            _initialized = true;
        }
    }

    void commitToHardwareFlash() {
        while (BM_FLASH->SR & 1UL) {}
        if (BM_FLASH->CR & (1UL << 7)) {
            BM_FLASH->KEYR = 0x45670123UL;
            BM_FLASH->KEYR = 0xCDEF89ABUL;
        }
        BM_FLASH->SR = 0x34UL;
        BM_FLASH->CR |= (1UL << 1);
        BM_FLASH->AR  = BM_EEPROM_FLASH_BASE;
        BM_FLASH->CR |= (1UL << 6);
        while (BM_FLASH->SR & 1UL) {}
        BM_FLASH->SR  = 0x34UL;
        BM_FLASH->CR &= ~(1UL << 1);

        volatile uint16_t *dst = (volatile uint16_t *)BM_EEPROM_FLASH_BASE;
        const uint16_t    *src = (const uint16_t *)_cache;
        for (int i = 0; i < 128; i++) {
            if (src[i] != 0xFFFFU) {
                BM_FLASH->CR |= (1UL << 0);
                dst[i] = src[i];
                while (BM_FLASH->SR & 1UL) {}
                BM_FLASH->SR  = 0x34UL;
                BM_FLASH->CR &= ~(1UL << 0);
            }
        }
        BM_FLASH->CR |= (1UL << 7);
    }

    __attribute__((noinline)) void getRaw(int addr, void *dst, size_t len) {
        ensureCache();
        if (addr >= 0 && (addr + (int)len) <= 256) {
            memcpy(dst, (const void *)(BM_EEPROM_FLASH_BASE + (uint32_t)addr), len);
        }
    }

    __attribute__((noinline)) void putRaw(int addr, const void *src, size_t len) {
        ensureCache();
        if (addr >= 0 && (addr + (int)len) <= 256) {
            memcpy(&_cache[addr], src, len);
            if (len == sizeof(MachineConfigRecord) ||
                ((addr & 127) + (int)len) == (int)sizeof(MachineConfigRecord)) {
                commitToHardwareFlash();
            }
        }
    }

public:
    template <typename T>
    inline void get(int addr, T &val) { getRaw(addr, &val, sizeof(T)); }

    template <typename T>
    inline void put(int addr, const T &val) { putRaw(addr, &val, sizeof(T)); }
};
static BareMetalFlashEEPROM EEPROM;

// Deterministic Zero-Blink HD44780 PCF8574 I2C Driver (Pure Bare-Metal Register I2C1)
class FastLiquidCrystal_I2C {
private:
    uint8_t _addr;
    uint8_t _backlightval; // Locked to 0x08 (Backlight ON) from constructor time!

    inline void expanderWrite(uint8_t data) {
        bm_i2c1_write_byte(_addr, (uint8_t)(data | _backlightval));
    }

    inline void pulseEnable(uint8_t data) {
        expanderWrite((uint8_t)(data | 0x04U));  // EN HIGH (P2)
        bm_delay_us(2);
        expanderWrite((uint8_t)(data & ~0x04U)); // EN LOW  (P2)
        bm_delay_us(45);
    }

    inline void write4bits(uint8_t nibbleUpper) {
        expanderWrite(nibbleUpper);
        pulseEnable(nibbleUpper);
    }

    inline void send(uint8_t value, uint8_t mode) {
        uint8_t highnib = value & 0xF0U;
        uint8_t lownib  = (uint8_t)((value << 4) & 0xF0U);
        write4bits((uint8_t)(highnib | mode));
        write4bits((uint8_t)(lownib  | mode));
    }

public:
    FastLiquidCrystal_I2C(uint8_t addr, uint8_t, uint8_t)
        : _addr(addr), _backlightval(0x08U) {}

    inline void command(uint8_t value) { send(value, 0x00U); }
    inline void writeChar(uint8_t value) { send(value, 0x01U); }

    // Initializes HD44780 in ~60ms (instead of 1050ms!) with Backlight continuously ON (0x08)
    void init() {
        _backlightval = 0x08U;
        expanderWrite(0x00U); // Keeps P3=HIGH (Backlight ON), RS=0, RW=0, EN=0
        bm_delay_ms(55);            // Wait 55ms for 5V rail > 4.5V (HD44780 spec: >40ms)
        sync4BitModeNoClear();
        clear();
    }

    // Re-synchronizes 4-bit mode & display config WITHOUT clearing DDRAM (zero flicker!)
    void sync4BitModeNoClear() {
        write4bits(0x30U);
        bm_delay_us(4500);
        write4bits(0x30U);
        bm_delay_us(4500);
        write4bits(0x30U);
        bm_delay_us(150);
        write4bits(0x20U);    // 4-bit interface
        command(0x28U);       // 4-bit, 2 lines, 5x8 font
        command(0x0CU);       // Display ON, Cursor OFF, Blink OFF
        command(0x06U);       // Entry mode: left-to-right, no shift
    }

    void clear() {
        command(0x01U);
        bm_delay_us(2000);
    }

    void setCursor(uint8_t col, uint8_t row) {
        static const uint8_t row_offsets[2] = { 0x00U, 0x40U };
        if (row > 1U) row = 1U;
        if (col > 15U) col = 15U;
        command((uint8_t)(0x80U | (col + row_offsets[row])));
    }

    void print(const char *str) {
        if (!str) return;
        while (*str) {
            writeChar((uint8_t)(*str++));
        }
    }

    void backlight() {
        _backlightval = 0x08U;
        expanderWrite(0x00U);
    }

    void noBacklight() {
        _backlightval = 0x00U;
        expanderWrite(0x00U);
    }

    void createChar(uint8_t location, const uint8_t charmap[]) {
        location &= 0x7U;
        command((uint8_t)(0x40U | (location << 3)));
        for (int i = 0; i < 8; i++) {
            writeChar(charmap[i]);
        }
    }
};
FastLiquidCrystal_I2C lcd(0x27, 16, 2);
#else
LiquidCrystal_I2C lcd(0x27, 16, 2);
#endif

// Custom 5x8 Pixel Notification Bell Icon in HD44780 CGRAM Slot 1 ('\x01')
#define LCD_BELL_CHAR '\x01'
static const uint8_t kBellBitmap[8] = {
    0x04, //   #
    0x0E, //  ###
    0x0E, //  ###
    0x0E, //  ###
    0x1F, // #####
    0x1F, // #####
    0x04, //   #
    0x00  //
};

// Write exactly 16 LCD columns; prevents stale characters after shorter labels/values.
static char s_lcdShadow[2][17] = {{0}, {0}};
static bool s_lcdShadowValid[2] = {false, false};

static inline void invalidateLcdShadow() {
    s_lcdShadowValid[0] = false;
    s_lcdShadowValid[1] = false;
}

static void lcdPrint16(uint8_t row, const char *text) {
    if (row > 1) return;
    char buf[17];
    int k = 0;
    if (text) {
        while (k < 16 && text[k] != '\0') {
            buf[k] = text[k];
            k++;
        }
    }
    while (k < 16) buf[k++] = ' ';
    buf[16] = '\0';
    if (!s_lcdShadowValid[row]) {
        lcd.setCursor(0, row);
        lcd.print(buf);
        memcpy(s_lcdShadow[row], buf, 17);
        s_lcdShadowValid[row] = true;
        return;
    }
    // Selective character-span update: only transmit the exact changed slice [firstDiff..lastDiff]
    int firstDiff = -1;
    int lastDiff  = -1;
    for (int i = 0; i < 16; i++) {
        if (s_lcdShadow[row][i] != buf[i]) {
            if (firstDiff < 0) firstDiff = i;
            lastDiff = i;
        }
    }
    if (firstDiff < 0) return; // Zero characters changed -> 0 I2C writes!
    char slice[17];
    int len = lastDiff - firstDiff + 1;
    memcpy(slice, &buf[firstDiff], (size_t)len);
    slice[len] = '\0';
    lcd.setCursor((uint8_t)firstDiff, row);
    lcd.print(slice);
    memcpy(s_lcdShadow[row], buf, 17);
}

// =========================================================================
// BUILD IDENTIFIERS & SOURCE-TO-BINARY METADATA
// =========================================================================
#define FW_VERSION_STR       "V17.1.0-PA0-TIM2-CAPTURE-PA8-TIM1"
#define FW_ARCH_TAG_STR      "V17.1.0-PA0-TIM2-CAPTURE-PA8-TIM1" // Authoritative V17.1.0 Direct Max-RPM Clamp Master
#define FW_BUILD_DATE_STR    "OCT-2026"
#define FW_BUILD_METADATA    "NIPON_ZIPPER_CNC_FW_V17_1_0_PA0_TIM2_CAPTURE_PA8_TIM1_TIMING_GUARD:OCT-2026"

// Embedded ROM identifier string for binary provenance verification
extern "C" const char g_firmware_build_tag[] __attribute__((used, retain)) = FW_BUILD_METADATA;

// Hardware Pin Definitions (100% Backwards-Compatible Pinout)
const int statusLedPin      = PC13; // Built-in Onboard LED (Active-LOW: LOW=ON, HIGH=OFF)
#define STATUS_LED_ON()    (GPIOC->BRR = (1 << 13))   // Atomic Clear PC13 -> LED ON
#define STATUS_LED_OFF()   (GPIOC->BSRR = (1 << 13))  // Atomic Set PC13   -> LED OFF
const int proxSensorPin     = PA0;  // Cam Proximity (PC817 Opto, Clean MCU GND, Falling ISR)
const int stepPin           = PA8;  // Driver PUL- (Hardware TIM1_CH1 / Direct Register BSRR)
const int dirPin            = PA2;  // Driver DIR- via Level Shifter CH4 LV (GPIOA Pin 2)
const int motorEnaPin       = PB1;  // Stepper Driver ENA- (Active LOW = Run, HIGH = Sleep)
#define MOTOR_ENA_ACTIVE()  (GPIOB->BSRR = (1U << (1 + 16))) // Atomic PB1 LOW  (Driver Enabled)
#define MOTOR_ENA_SLEEP()   (GPIOB->BSRR = (1U << 1))        // Atomic PB1 HIGH (Driver Sleep)
bool isBacklightCurrentlyOn = true;
bool isMotorCurrentlyAsleep = false;
// =========================================================================
// 3-BUTTON / 6-BUTTON DUAL-MODE KEYPAD PIN DEFINITIONS (ACTIVE-LOW INPUT_PULLUP)
// Default Mode: 3-BTN (PB13=UP, PB12=DOWN, PB14=MODE/SELECT) for backward compatibility.
// 6-BTN Mode  : Adds PB15=BACK, PB11=LEFT, PB10=RIGHT (Selectable & Persistent in Settings).
// =========================================================================
#ifndef PB8
#define PB8 80
#endif
#ifndef PB9
#define PB9 90
#endif
const int btnUp             = PB13; // [UP] Button / 4x4 Row 2 (Active-LOW)
const int btnDown           = PB12; // [DOWN] Button / 4x4 Row 1 (Active-LOW)
const int btnMode           = PB14; // [SELECT / MODE] Button / 4x4 Row 3 (Active-LOW)
const int btnBack           = PB15; // [BACK] Button (6-BTN Mode) / 4x4 Row 4 (Active-LOW)
const int btnLeft           = PB11; // [LEFT] Button (6-BTN Mode) / 4x4 Col 4 (Active-LOW)
const int btnRight          = PB10; // [RIGHT] Button (6-BTN Mode) / 4x4 Col 3 (Active-LOW)
const int colPin0           = PB8;  // 4x4 Matrix Col 1 (1, 4, 7, *)
const int colPin1           = PB9;  // 4x4 Matrix Col 2 (2, 5, 8, 0)
const int colPin2           = PB10; // 4x4 Matrix Col 3 (3, 6, 9, #)
const int colPin3           = PB11; // 4x4 Matrix Col 4 (A, B, C, D)

// Direct Register Bit Set/Reset (1-Cycle 13.8ns Sinking)
#define STEP_LOW_ACTIVE()  (GPIOA->BSRR = (1 << (8 + 16)))
#define STEP_HIGH_IDLE()   (GPIOA->BSRR = (1 << 8))
#define DIR_LOW()          (GPIOA->BSRR = (1 << (2 + 16)))
#define DIR_HIGH()         (GPIOA->BSRR = (1 << 2))
#define DIR_NORMAL()       DIR_HIGH() // Idle-HIGH for Normal Forward rotation
#define DIR_REVERSE()      DIR_LOW()  // Active-LOW sinking for Reverse rotation

// 1,000,000x Micro-Fractional DDA Fixed-Point Scaling Factor (6 Decimal Places)
#define FIXED_SCALE 1000000ULL

// IWDG: Independent Watchdog Timer (40kHz LSI / 32 Prescaler [PR=0x03] -> 0.8ms/count, RLR=625 -> Exact 500ms Timeout)
#define IWDG_INIT() do {     IWDG->KR = 0x5555;     IWDG->PR = 0x03;       IWDG->RLR = 625;        IWDG->KR = 0xAAAA;     IWDG->KR = 0xCCCC; } while (0)
#define IWDG_FEED() (IWDG->KR = 0xAAAA)

// Authoritative EEPROM payload & dual-slot record structures are defined in pulsestep_persistence.h

// 6-Decimal Exact Mathematical Pitch Pulses (6400 Resolution / 45.0mm Roller Diameter)
uint64_t p5_fixed  = 70000000ULL;  // Size #5 (2.50mm): 70.000000 steps calibrated default
uint64_t p8_fixed  = 80000000ULL;  // Size #8 (3.00mm): 80.000000 steps calibrated default
uint64_t p10_fixed = 100000000ULL; // Size #10 (4.00mm): 100.000000 steps calibrated default

// Discrete Hardware Stepper Driver (DM542) DIP-Switch Resolutions
const int32_t DRIVER_RES_TABLE[] = {
    400, 800, 1000, 1600, 2000, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 20000, 25600, 40000, 51200
};
const uint8_t DRIVER_RES_TABLE_SIZE = sizeof(DRIVER_RES_TABLE) / sizeof(DRIVER_RES_TABLE[0]);

static inline int getDriverResIndex(int32_t res) {
    for (int i = 0; i < (int)DRIVER_RES_TABLE_SIZE; i++) {
        if (DRIVER_RES_TABLE[i] == res) return i;
    }
    // Nearest fallback
    int best = 8; // 6400 default
    int32_t bestDiff = 999999;
    for (int i = 0; i < (int)DRIVER_RES_TABLE_SIZE; i++) {
        int32_t d = abs(DRIVER_RES_TABLE[i] - res);
        if (d < bestDiff) { bestDiff = d; best = i; }
    }
    return best;
}
int32_t driverResolution    = 6400;
float   rollerDia           = 45.0f;
int32_t maxRPMSetting       = 3000;
int32_t feedAngleDeg        = 90;
int32_t safetyMarginPercent = 15;
int     helpIndex           = 1;     // 1: Stall, 2: Pitch, 3: Noise, 4: Hot, 5: Drift
bool    motorDirection      = false; // DEFAULT: FALSE (NORMAL / FORWARD ROTATION)
bool    keypad6ButtonMode   = false; // DEFAULT: FALSE (3-BTN Mode default; TRUE = 6-BTN Mode, persistent in EEPROM)
uint8_t keypadMode          = 0;     // 0: 3-BTN, 1: 6-BTN, 2: 4X4-MATRIX (Auto-calibrated & locked in EEPROM)
bool    keypadCalibrationLocked = true; // Set false on uninitialized EEPROM / Factory Reset for 1-time guided gate
uint8_t calibStep           = 0;     // 0: Press Any Key, 1: 6-Btn Check [BACK], 2: 4x4 Press [1], 3: 4x4 Press [5]
bool    tempMotorDir        = false; // Staged Menu Direction
bool    tempKeypad6Btn      = false; // Staged Keypad Mode (false = 3-BTN, true = 6-BTN)
int     advanceOption       = 1;     // Level 2 Advance Menu option index (1..5)
uint32_t autoLockSec            = 30UL;  // Default: 30 sec (0: OFF, 10..300s Digital Watch Inline Editor)
uint32_t lastEnabledAutoLockSec = 30UL;  // Remembers last active Auto-Lock seconds when toggled OFF/ON
int32_t  backlightSec           = 0;     // Default: 0 = ALWAYS ON (10..300s, 999: OFF)
uint32_t motorSleepMin          = 0UL;   // Default: 0 = OFF (20..300 min)
#define MAIN_INLINE_EDIT_TIMEOUT_MS 10000UL // 10s idle timeout for Main Screen Watch Inline Editor

uint32_t tempAutoLockSec   = 30UL;
int32_t  tempBacklightSec  = 0;
uint32_t tempMotorSleepMin = 0UL;

// 4x4 Keypad Direct Speed Dial State (Main Screen Standstill)
bool    isSpeedDialActive   = false;
char    speedDialBuf[12]    = {0};
uint8_t speedDialLen        = 0;
bool    speedDialHasDot     = false;
uint8_t speedDialDecCount   = 0;
bool    wakeShieldConsumingPress = false; // Sleep Wake-Up Shield: consumes 1st button press when waking screen/motor


bool isEditingMainDecimal  = false; // Main Screen Digital Watch Inline Editor active
uint8_t mainEditCursor     = 0;     // 0: .10 decimal, 1: Units (1s), 2: Tens (10s)
bool unlockPendingDown     = false; // Sequential unlock: true when MODE was pressed and waiting for DOWN
unsigned long unlockPromptUntil = 0UL;
unsigned long lastButtonPressTime = 0UL;
unsigned long lastMotionOrButtonTime = 0UL;
bool    isEditingSetting    = false;
uint8_t settingDigitCursor   = 0; // Digital Watch cursor position (0: Units/Dec, 1: Tens/Int, 2: Hundreds) // In-place blinking parameter edit state in Settings Menu

extern volatile bool hwBurstActive;
extern volatile int stepsRemaining;
void stopHardwareTimerImmediately();
void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs, uint32_t burstPeriodQ16);
void startHardwareTimerBurst(int stepCount);

// Hardware-level Motor Direction Controller (PA2 DIR-)
void applyMotorDirection() {
    // Safety: ensure any active movement is completely stopped before changing DIR pin
    if (hwBurstActive || stepsRemaining > 0) {
        stopHardwareTimerImmediately();
    }
    bm_delay_us(20); // Safe hold time after last step pulse before DIR edge
    if (motorDirection) {
        DIR_LOW();  // Active-LOW sinking for Reverse rotation
    } else {
        DIR_HIGH(); // Idle-HIGH for Normal Forward rotation
    }
    bm_delay_us(20); // Safe setup time (exceeds 5us DM542 specification by 400%)
}


int autoPulseWidth_P5   = 25;
int autoPulseWidth_P8   = 29;
int autoPulseWidth_P10  = 22;
volatile int activePulseWidth = 53; // Nominal 53us step period (~18.8 kHz) for 3000 RPM / 90 deg / 15% margin

int32_t currentSize = 2; // 1: #5 (2.50mm), 2: #8 (3.00mm) [DEFAULT], 3: #10 (4.00mm)
// =========================================================================
// ATOMIC COHERENT PULSE PARAMETER SNAPSHOT & TELEMETRY
// =========================================================================
#ifndef DEBUG_TEST_MODE
#define DEBUG_TEST_MODE 0
#endif

struct PulseParameters {
    uint32_t integerPart;
    uint32_t fractionalPart;
    uint32_t generation;

    PulseParameters() : integerPart(113), fractionalPart(176848UL), generation(1) {}
    PulseParameters(uint32_t i, uint32_t f, uint32_t g) : integerPart(i), fractionalPart(f), generation(g) {}
    PulseParameters(const PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters(const volatile PulseParameters& o) : integerPart(o.integerPart), fractionalPart(o.fractionalPart), generation(o.generation) {}
    PulseParameters& operator=(const PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    PulseParameters& operator=(const volatile PulseParameters& o) {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
        return *this;
    }
    void operator=(const PulseParameters& o) volatile {
        integerPart = o.integerPart;
        fractionalPart = o.fractionalPart;
        generation = o.generation;
    }
};

BurstQueue burstQueue;
volatile uint32_t tim4_overflow_count = 0;

volatile PulseParameters activePulseParams   = {80, 0UL, 1}; // Size #8 default: 80.000000 steps
PulseParameters          pendingPulseParams  = {80, 0UL, 1};
volatile uint32_t        paramGenerationUsed = 1;
volatile uint32_t        rejectedTriggerCount = 0; // Live noise rejection counter for diagnostics

#if DEBUG_TEST_MODE
volatile uint32_t acceptedTriggerCount   = 0;
volatile uint32_t triggerMissedCount     = 0;
volatile uint32_t requestedPulseCount    = 0;
volatile uint32_t startedPulseCount      = 0;
volatile uint32_t completedPulseCount    = 0;
volatile uint32_t abortedPulseCount      = 0;
volatile uint32_t queuedPulseCount       = 0;
volatile uint32_t burstStartedCount      = 0;
volatile uint32_t burstCompletedCount    = 0;
volatile uint32_t burstQueuedCount       = 0;
volatile uint32_t paramGenChangesCount   = 0;
volatile uint32_t maxISRLatencyCycles    = 0;
volatile uint32_t maxTriggerJitterUs     = 0;
volatile uint32_t assertionFailureCount  = 0;
#endif

volatile uint32_t pulseFracAccumulator = 0UL;     // 32-bit fractional accumulator (zero 64-bit division)

void commitPulseParameters(uint32_t intPart, uint32_t fracPart) {
    pendingPulseParams.integerPart    = intPart;
    pendingPulseParams.fractionalPart = fracPart;
    pendingPulseParams.generation++;
#if DEBUG_TEST_MODE
    paramGenChangesCount++;
#endif
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    if (activePulseParams.integerPart != pendingPulseParams.integerPart ||
        activePulseParams.fractionalPart != pendingPulseParams.fractionalPart) {
        pulseFracAccumulator = 0UL;
    }
    activePulseParams.integerPart = pendingPulseParams.integerPart;
    activePulseParams.fractionalPart = pendingPulseParams.fractionalPart;
    activePulseParams.generation = pendingPulseParams.generation;
    __set_PRIMASK(primask);
}

volatile uint64_t currentPulsesFixed = 80000000ULL;
volatile uint32_t currentPulsesInt   = 80;      // Whole step portion for fast 32-bit ISR math
volatile uint32_t currentPulsesFrac  = 0UL; // Fractional micro-step portion (< 1,000,000)
volatile uint32_t tim2OverflowCount = 0UL;
volatile uint32_t tim2CaptureOverrunCount = 0UL;
volatile uint32_t tim2CaptureEpochOffsetUs = 0UL;
volatile bool tim2CaptureEpochReady = false;
volatile uint32_t tim2CaptureMissedCallbacks = 0UL;
volatile bool     isCaptureStreamDiscontinuous = false;
volatile uint32_t tim2CaptureResyncEvents      = 0UL;

volatile uint32_t lastTriggerTimerUs      = 0UL;
// Last accepted PA0 trigger timestamp, sourced from the extended TIM2 hardware-capture clock.
volatile bool pendingMenuExit = false;

bool isUiLocked = false; // Unlocked on boot; locks ONLY via autoLockSec timer
unsigned long lastUnlockActivity = 0UL;

// =========================================================================
// 2-MINUTE COOLDOWN CONTINUOUS STANDSTILL AUTO-SAVE ENGINE
// Gated strictly to 0 RPM Standstill (Zero Pulse & Trigger Interference)
// Anti-Repeat Latch: Saved exactly once per parameter modification
// =========================================================================
bool pulseModifiedByUser            = false;  // Armed when user tunes pulse with UP/DOWN
bool autoSavePendingStandstill       = false;  // Set when 60s qualified in RAM; deferred to 0 RPM
AutoSaveQualificationEngine autoSaveEngine(120000UL); // Formal 2-Minute Cooldown Auto-Save Engine
FlashSaveTransactionEngine  flashSaveTx;             // Atomic Flash Save Transaction Engine (Prompt 8Writing)

// Accepted motion-trigger counters and diagnostics (PA0 TIM2 input capture path).
volatile uint32_t acceptedTriggerPulses          = 0;

// Authoritative PulseStep Persistence State Tracking
uint32_t flashWriteCount            = 0;      // Diagnostic counter: strictly increments on actual Flash write
uint32_t activeEEPROMSlot           = 0;      // Active transaction slot (0 or 1)
uint32_t eepromSeqNumber            = 0;      // Monotonic transaction sequence counter
uint64_t pulseStepStored_p5         = 70000000ULL; // Stored ROM baseline for Size #5
uint64_t pulseStepStored_p8         = 80000000ULL; // Stored ROM baseline for Size #8
uint64_t pulseStepStored_p10        = 100000000ULL; // Stored ROM baseline for Size #10
bool     eepromSlotInitialized      = false;

// In-Place Parameter Blinking State (Replaces pop-up feedback windows on value change)
enum BlinkTarget : uint8_t {
    BLINK_NONE          = 0,
    BLINK_MAIN_PULSE    = 1, // Blinks full P:xx.x on Main Screen
    BLINK_MAIN_GEAR_INT = 2, // Blinks integer part of P:xx.x on direct UP/DOWN (+/-1.0)
    BLINK_MAIN_GEAR_DEC = 3, // Blinks .10 decimal digit in Main Inline Editor (cursor 0)
    BLINK_MAIN_SIZE     = 4, // Blinks S:x on Main Screen when zipper size changes
    BLINK_MAIN_LOCK     = 5, // Blinks [L]/[U] on Main Screen
    BLINK_MAIN_UNITS    = 6, // Blinks Units digit (1s) in Main Inline Editor (cursor 1)
    BLINK_MAIN_TENS     = 7, // Blinks Tens digit (10s) in Main Inline Editor (cursor 2)
    BLINK_MAIN_HUNDREDS = 8  // Blinks Hundreds digit (100s) in Main Inline Editor (cursor 3)
};
unsigned long lastEditKeyPressMs = 0UL; // Keeps edited digit 100% solid for 400ms after UP/DOWN press!
volatile uint8_t blinkTarget      = BLINK_NONE;
unsigned long    blinkUntilMs     = 0UL;

static inline void setMainEditCursorAndBlink(uint8_t cur) {
    isEditingMainDecimal = true;
    mainEditCursor       = (uint8_t)(cur % 4U);
    if (mainEditCursor == 0U)      blinkTarget = BLINK_MAIN_GEAR_DEC;
    else if (mainEditCursor == 1U) blinkTarget = BLINK_MAIN_UNITS;
    else if (mainEditCursor == 2U) blinkTarget = BLINK_MAIN_TENS;
    else                           blinkTarget = BLINK_MAIN_HUNDREDS;
    blinkUntilMs       = bm_millis() + MAIN_INLINE_EDIT_TIMEOUT_MS;
    lastEditKeyPressMs = bm_millis();
}


unsigned long uiMessageTimer = 0UL;
const char* uiBannerLine1 = nullptr;
const char* uiBannerLine2 = nullptr;

// Staged RAM Parameters for Zero Flash Wear
int32_t tempDriverRes       = 6400;
float   tempRollerDia       = 45.0f;
int32_t tempMaxRPM          = 3000;
int32_t tempFeedAngle       = 90;
int32_t tempSafetyMargin    = 15;

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, float pitchMm);

static inline bool stagedTimingConfigurationFeasible() {
    const float pitch5  = 1.54625411f; // V17.1.0 Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const float pitch8  = 1.76714755f; // V17.1.0 Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const float pitch10 = 2.20893444f; // V17.1.0 Calibrated for 100.00 pulses at 6400 res / 45mm roller
    return timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch5) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch8) &&
           timingConfigurationFeasible(tempDriverRes, tempRollerDia, tempMaxRPM, tempFeedAngle, tempSafetyMargin, pitch10);
}

// True when the manually tuned pulse count cannot fit inside the configured
// feed-angle window at the configured maximum RPM. Never silently clamp an
// invalid manual tuning to the 8us timer floor.
volatile bool pulseTimingInvalid = false;
volatile bool isTimingOverrun    = false; // Latches active burst queue saturation

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#ifndef SERVO_PERIOD_Q_SHIFT
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U
#endif

static inline bool currentPulseTimingFeasible() {
    if (driverResolution < 200 || driverResolution > 51200 || rollerDia < 10.0f || rollerDia > 100.0f ||
        maxRPMSetting < 100 || maxRPMSetting > 4000 || feedAngleDeg < 30 || feedAngleDeg > 270 ||
        safetyMarginPercent < 0 || safetyMarginPercent > 29) return false;
    const float circumference = 3.14159265f * rollerDia;
    (void)circumference;
    const float stepCount = (float)currentPulsesFixed / 1000000.0f;
    const float feedWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f) *
                               (1.0f - ((float)safetyMarginPercent / 100.0f));
    const float overlapDeadlineUs = (60000000.0f / (float)maxRPMSetting) * 0.75f * 0.80f;
    const float windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    return stepCount > 0.0 && windowUs > 0.0 && (windowUs / stepCount) >= (float)SERVO_PERIOD_MIN_US;
}

static inline void refreshPulseTimingValidity() {
    pulseTimingInvalid = !currentPulseTimingFeasible();
}
bool    hasStagedChanges    = false;
bool    isTimingWarningActive = false;
int diagMinW = 0;
const char* diagFixLine1 = nullptr;
const char* diagFixLine2 = nullptr;
int infoIndex = 1;

// Motion Sync Watchdog & Diagnostic State
volatile bool isMotionSyncLost     = false; // Diagnostic state; never blocks PA0/PA8 timing
volatile bool motionWatchdogArmed   = false; // Armed only after a valid measured trigger interval
volatile uint32_t validTriggerCount  = 0;
volatile int  faultType            = 0;     // 0: None, 3: Trigger Sync Lost

// Stepper Step State Machine
volatile unsigned long lastTriggerMicros = 0UL;
volatile unsigned long lastMeasuredIntervalUs = 0UL;
volatile int stepsRemaining = 0;
volatile int totalStepsInBurst = 0;
volatile bool stepPinState = HIGH;

// Hardware Timer 2 Burst Controller State
volatile bool hwBurstActive = false;
volatile int  hwBurstStepsTarget = 0;
volatile int  hwBurstStepsDone = 0;

volatile unsigned long currentRPM = 0UL;
// RPM display-only robust estimator. It does not control PA0 qualification,
// the watchdog's raw interval, or PA8 STEP scheduling.
volatile uint32_t rpmIntervalHistoryUs[3] = {0UL, 0UL, 0UL};
volatile uint8_t rpmIntervalHistoryCount = 0U;
volatile uint8_t rpmIntervalHistoryIndex = 0U;
unsigned long lastDisplayUpdate = 0UL;
unsigned long lastRpmDisplayUpdate = 0UL;
unsigned long lastButtonCheck = 0UL;
unsigned long modePressTime = 0UL;
unsigned long lastModeClickTime = 0UL;
unsigned long dualPressTime = 0UL;

bool modePressed = false;
bool upDownPressed = false;
bool pendingSingleClick = false;
bool pendingMenuSingleClick = false;
unsigned long lastMenuModeClickTime = 0UL;

int menuState = 0;
int oldMenuState = -1;
int hiddenOption = 1;
bool resetChoice = false;
bool saveExitChoice = true; // Save & Exit Dialog: true = YES, false = NO

// Hardware Timer 2 Instance for Stepping Pulses
// =========================================================================
// AUTHORITATIVE CNC MOVEMENT STATE MACHINE
// IDLE -> ARMED -> RUNNING -> STOPPING -> COMPLETE -> IDLE
// Fault/Abort: RUNNING/STOPPING -> FAULT/ABORTED -> IDLE (Standstill Gated)
// =========================================================================
enum MovementState {
    STATE_IDLE = 0,
    STATE_ARMED,
    STATE_RUNNING,
    STATE_STOPPING,
    STATE_COMPLETE,
    STATE_ABORTED,
    STATE_FAULT
};
volatile MovementState movementState = STATE_IDLE;

inline bool isMachineSafelyIdle() {
    return (currentRPM == 0UL) &&
           (stepsRemaining == 0) &&
           (!hwBurstActive) &&
           (burstQueue.isEmpty()) &&
           (movementState == STATE_IDLE || movementState == STATE_COMPLETE);
}

const uint16_t STEP_PULSE_WIDTH_US   = 5; // 5.0us Active LOW pulse for Leadshine DM542

// Maximum practical timing resolution: Q16.16 microseconds.
// The timer still runs at 1 MHz, but the fractional accumulator removes
// systematic integer-microsecond quantization over long bursts/cycles.
#define SERVO_PERIOD_Q_SHIFT 16U
#define SERVO_PERIOD_Q_ONE   (1UL << SERVO_PERIOD_Q_SHIFT)
#define SERVO_PERIOD_MIN_US  8U
#define SERVO_PERIOD_MAX_US  500U

// Trigger interval history is shared by RPM display and robust STEP-period estimation.
volatile uint32_t servoPhaseRelockCount = 0;
volatile bool servoPhaseLocked = false;
volatile uint32_t servoLastIntervalUs = 0;
volatile uint32_t servoPrevIntervalUs = 0;
volatile uint32_t servoMaxJitterUs = 0;
volatile uint32_t servoPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodQ16 = (70UL << SERVO_PERIOD_Q_SHIFT);
volatile uint32_t hwBurstPeriodFrac = 0;

static inline uint16_t q16PeriodToTimerUs(volatile uint32_t &frac, uint32_t q16) {
    // True Q16.16 accumulation: retain both the configured fractional period
    // and the carry from prior timer cycles. This preserves the long-term
    // average period instead of truncating the Q16 fractional component.
    uint32_t sum = (q16 & 0xFFFFUL) + (frac & 0xFFFFUL);
    uint32_t whole = (q16 >> SERVO_PERIOD_Q_SHIFT) + (sum >> SERVO_PERIOD_Q_SHIFT);
    frac = sum & 0xFFFFUL;
    if (whole < SERVO_PERIOD_MIN_US) whole = SERVO_PERIOD_MIN_US;
    if (whole > SERVO_PERIOD_MAX_US) whole = SERVO_PERIOD_MAX_US;
    return (uint16_t)whole;
}

static inline bool timingConfigurationFeasible(int32_t resolution, float diameter, int32_t rpm, int32_t angle, int32_t margin, float pitchMm) {
    if (resolution < 200 || resolution > 51200 || !(diameter == diameter) || diameter < 10.0f || diameter > 100.0f ||
        rpm < 100 || rpm > 4000 || angle < 30 || angle > 270 || margin < 0 || margin > 29 || pitchMm <= 0.0) return false;
    const float circumference = 3.14159265f * diameter;
    const float stepCount = ((float)resolution / circumference) * pitchMm;
    const float feedWindowUs = (60000000.0f / (float)rpm) * ((float)angle / 360.0f) * (1.0f - ((float)margin / 100.0f));
    const float overlapDeadlineUs = (60000000.0f / (float)rpm) * 0.75f * 0.80f;
    const float windowUs = (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
    if (!(stepCount > 0.0) || !(windowUs > 0.0)) return false;
    // The timer's hard minimum is 8 us. A configuration whose requested burst
    // period is below this cannot physically fit the commanded pulse count into
    // the configured feed-angle window. Never silently clamp such a case to 8 us.
    return (windowUs / stepCount) >= (float)SERVO_PERIOD_MIN_US;
}

// Reserve explicit timing headroom so a valid trigger at the configured RPM ceiling
// cannot arrive while the previous STEP burst is still active. The trigger plausibility
// guard accepts intervals down to 75% of a configured revolution; use only 80% of that
// floor for STEP time (60% of a revolution) as a conservative deadline.
static inline uint64_t maximumBurstWindowUs(int32_t rpm, int32_t angle, int32_t margin) {
    if (rpm < 100 || rpm > 4000) rpm = 3000;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    if (margin < 0) margin = 0;
    if (margin > 29) margin = 29;
    const uint64_t revolutionUs = 60000000ULL / (uint32_t)rpm;
    const uint64_t feedWindowUs = (revolutionUs * (uint32_t)angle / 360ULL) * (uint32_t)(100 - margin) / 100ULL;
    const uint64_t minimumAcceptedIntervalUs = revolutionUs * 3ULL / 4ULL;
    const uint64_t overlapDeadlineUs = minimumAcceptedIntervalUs * 80ULL / 100ULL;
    return (feedWindowUs < overlapDeadlineUs) ? feedWindowUs : overlapDeadlineUs;
}

// Direct Max-RPM Clamped Step Period Calculation:
// Step pulse window is directly determined by maximumBurstWindowUs(maxRPMSetting, angle, margin)
// with zero redundant per-stitch dynamic-RPM division. Changing Max RPM (or Feed Angle / Safety Margin)
// in Settings immediately updates the clamp and step pulse period.
static inline uint32_t calculateAdaptiveStepPeriodQ16(uint32_t revolutionUs, uint32_t stepCount) {
    (void)revolutionUs;
    if (stepCount == 0U) return servoPeriodQ16;
    int angle = feedAngleDeg;
    if (angle < 30) angle = 30;
    if (angle > 270) angle = 270;
    int margin = safetyMarginPercent;
    if (margin < 0) margin = 0;
    if (margin > 29) margin = 29;
    uint64_t windowUs = maximumBurstWindowUs(maxRPMSetting, angle, margin);
    if (windowUs < 1ULL) windowUs = 1ULL;
    uint64_t q16 = (windowUs << SERVO_PERIOD_Q_SHIFT) / (uint64_t)stepCount;
    uint64_t minQ = ((uint64_t)SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT);
    uint64_t maxQ = ((uint64_t)SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT);
    if (q16 < minQ) q16 = minQ;
    if (q16 > maxQ) q16 = maxQ;
    return (uint32_t)q16;
}


#if defined(HOST_SIMULATION_TEST)
HardwareTimer *stepTimer     = new HardwareTimer(TIM1);
HardwareTimer *captureTimer  = new HardwareTimer(TIM2);
#if defined(TIM4)
HardwareTimer *timebaseTimer = new HardwareTimer(TIM4);
#endif
#else
void stepTimerCallback(void);
void tim2HardwareCaptureCallback(void);
void tim2CaptureRolloverCallback(void);

// Bare-metal direct silicon NVIC interrupt handlers (HAL_TIM_MODULE_ONLY)
// Completely drops HardwareTimer.cpp, malloc/heap, and timer HAL library (~12KB Flash saving!)
extern "C" void TIM1_UP_IRQHandler(void) {
    if (TIM1->SR & TIM_SR_UIF) {
        TIM1->SR = ~TIM_SR_UIF;
        stepTimerCallback();
    }
}

extern "C" void TIM2_IRQHandler(void) {
    uint32_t sr   = TIM2->SR;
    uint32_t dier = TIM2->DIER;
    if ((sr & TIM_SR_CC1IF) && (dier & TIM_DIER_CC1IE)) {
        TIM2->SR = ~TIM_SR_CC1IF;
        tim2HardwareCaptureCallback();
    }
    if ((TIM2->SR & TIM_SR_UIF) && (dier & TIM_DIER_UIE)) {
        TIM2->SR = ~TIM_SR_UIF;
        tim2CaptureRolloverCallback();
    }
}
#endif

// =========================================================================
// TRUE HARDWARE TIMER 1 (TIM1_CH1 PA8) PWM MODE 2 STEP GENERATION & BURST CONTROLLER
// 1. Pure Continuous PWM Mode 2: Inactive (HIGH) 0..CCR1-1, Active (LOW) CCR1..ARR.
// 2. Output is natively, physically HIGH at CNT=0 rollover.
// 3. Software halts CEN and CC1E at CNT=0 upon burst completion (0.2us latency vs 30us safety window).
// 4. Zero OPM hardware race conditions: Timer NEVER stalls or dies on rapid/boundary triggers!
// 5. Seamless mid-burst trigger accumulation: Target += stepCount without losing a single pulse.
// =========================================================================

// =========================================================================
// DETERMINISTIC MULTI-SEGMENT RAMP PARAMETER CALCULATOR
// Provides smooth, bounded acceleration/deceleration with zero staircase jerk
// Dedicated short-burst handling: N<=4 (pure cruise), 5<=N<=12 (gentle soft boundary)
// =========================================================================
static inline void updateStepPeriodFromServoInterval(uint32_t revolutionUs, uint32_t stepCount) {
    if (revolutionUs == 0U || stepCount == 0U) return;
    servoPrevIntervalUs = servoLastIntervalUs;
    servoLastIntervalUs = revolutionUs;
    if (servoPrevIntervalUs != 0U) {
        uint32_t jitter = (revolutionUs > servoPrevIntervalUs) ? (revolutionUs - servoPrevIntervalUs) : (servoPrevIntervalUs - revolutionUs);
        if (jitter > servoMaxJitterUs) servoMaxJitterUs = jitter;
    }
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(revolutionUs, stepCount);
    servoPhaseLocked = (servoPrevIntervalUs != 0U);
    if (servoPhaseLocked) servoPhaseRelockCount++;
}

void stepTimerCallback() {
    if (hwBurstActive && movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        hwBurstStepsDone++;
#if DEBUG_TEST_MODE
        completedPulseCount++;
#endif

        if (hwBurstStepsDone >= hwBurstStepsTarget) {
            BurstItem nextBurst{};
            if (movementState != STATE_FAULT && movementState != STATE_ABORTED && burstQueue.dequeue(nextBurst)) {
                // Seamlessly chain queued burst from authoritative SPSC BurstQueue without dropping timer
                hwBurstStepsTarget = (int)nextBurst.stepCount;
                hwBurstStepsDone   = 0;
#if DEBUG_TEST_MODE
                queuedPulseCount  -= nextBurst.stepCount;
                startedPulseCount += nextBurst.stepCount;
                burstStartedCount++;
#endif
                stepsRemaining     = hwBurstStepsTarget;
                totalStepsInBurst  = hwBurstStepsTarget;

                // Direction Fix (per Rajesh Shah directive):
                // Direction is strictly Settings-controlled and fixed during RUN.
                // Pulse, burst, queue, ISR, DDA, RPM, trigger, and sensor processing NEVER change DIR at runtime.

                // Each queued burst carries the period calculated from the physical
                // servo interval that created it. Never rewrite the active burst with a
                // newer measurement; this preserves deterministic phase timing.
                if (nextBurst.periodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && nextBurst.periodQ16 <= (SERVO_PERIOD_MAX_US << SERVO_PERIOD_Q_SHIFT)) {
                    hwBurstPeriodQ16 = nextBurst.periodQ16;
                    hwBurstPeriodFrac = 0;
                } else if (nextBurst.periodUs >= SERVO_PERIOD_MIN_US && nextBurst.periodUs <= SERVO_PERIOD_MAX_US) {
                    hwBurstPeriodQ16 = ((uint32_t)nextBurst.periodUs << SERVO_PERIOD_Q_SHIFT);
                    hwBurstPeriodFrac = 0;
                }
                uint16_t firstScheduledUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
                activePulseWidth = (int)firstScheduledUs;
                uint16_t nextARR = (firstScheduledUs > 1) ? (uint16_t)(firstScheduledUs - 1) : 1;
                TIM1->ARR = nextARR;
                uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
                if (pWidth < 2) pWidth = 2;
                TIM1->CCR1 = nextARR - pWidth + 1;
                return;
            }

            // Burst complete with no queued steps: disable PWM output and stop timer in silicon
            TIM1->CCER &= ~TIM_CCER_CC1E; // Disconnect hardware PWM output on PA8 immediately
            TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
            
            // Restore PA8 pin to General Purpose Output HIGH (Idle)
            GPIOA->CRH &= ~(0xFU << 0);
            GPIOA->CRH |= (0x3U << 0); // 50MHz GP Output Push-Pull
            STEP_HIGH_IDLE();
            stepPinState = HIGH;

            // Clear any pending update flags in NVIC
            TIM1->SR &= ~TIM_SR_UIF;
            NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

            hwBurstActive  = false;
            stepsRemaining = 0;
            movementState  = STATE_COMPLETE;
#if DEBUG_TEST_MODE
            burstCompletedCount++;
            if (queuedPulseCount == 0 && !hwBurstActive) {
                if (requestedPulseCount != (completedPulseCount + abortedPulseCount)) {
                    assertionFailureCount++;
                }
            }
#endif
            STATUS_LED_OFF(); // Stepper burst complete -> Turn OFF LED
        } else {
            stepsRemaining = (hwBurstStepsTarget - hwBurstStepsDone);
            movementState  = STATE_RUNNING;

            // Keep every pulse in the burst at the servo-synchronized period.
            // Artificial per-pulse ramps are deliberately removed because they change
            // the commanded pulse density away from the measured master motion.
            uint16_t scheduledPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
            activePulseWidth = (int)scheduledPeriodUs;
            uint16_t nextARR = (scheduledPeriodUs > 1) ? (uint16_t)(scheduledPeriodUs - 1) : 1;
            TIM1->ARR  = nextARR;
            uint16_t pWidth = (nextARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (nextARR / 2);
            if (pWidth < 2) pWidth = 2;
            TIM1->CCR1 = nextARR - pWidth + 1; // Pulse ends exactly at ARR rollover
        }
    } else {
        TIM1->CCER &= ~TIM_CCER_CC1E;
        TIM1->CR1  &= ~TIM_CR1_CEN;
        GPIOA->CRH &= ~(0xFU << 0);
        GPIOA->CRH |= (0x3U << 0);
        STEP_HIGH_IDLE();
        stepPinState   = HIGH;
        TIM1->SR &= ~TIM_SR_UIF;
        NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
        hwBurstActive  = false;
        stepsRemaining = 0;
        movementState  = STATE_IDLE;
    }
}

// =========================================================================
// DETERMINISTIC 1 KHZ HARDWARE SAFETY MONITOR (TIM3)
// Unblockable by loop() or I2C LCD delays. 15ms Anti-Vibration Qualified E-Stop.
// =========================================================================
static inline uint32_t get_hardware_timestamp_us(); // shared timebase prototype
void processSensorTrigger(uint32_t capturedTimestampUs); // forward declaration for TIM2 callback

// =========================================================================
// CONTINUOUS 1 MHZ FREE-RUNNING TIMER 4 (STM32F103 HARDWARE TIMESTAMPING)
// 1.0 microsecond deterministic tick resolution, independent of TIM2/TIM3
// =========================================================================
#if defined(TIM4) && (!defined(STM32F103x6) || defined(HOST_SIMULATION_TEST)) && defined(RCC_APB1ENR_TIM4EN)
void tim4UpdateCallback(void) {
    tim4_overflow_count++;
}

#ifndef HOST_SIMULATION_TEST
extern "C" void TIM4_IRQHandler(void) {
    if (TIM4->SR & TIM_SR_UIF) {
        TIM4->SR = ~TIM_SR_UIF;
        tim4UpdateCallback();
    }
}
#endif

void initFreeRunningTimer4() {
    RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
#ifdef HOST_SIMULATION_TEST
    timebaseTimer->pause();
    timebaseTimer->setPrescaleFactor(72);     // 72MHz / 72 = 1MHz (1.0 us tick)
    timebaseTimer->setOverflow(0x10000UL);    // 16-bit free-running counter rollover at 65535us
    timebaseTimer->setCount(0);
    timebaseTimer->attachInterrupt(tim4UpdateCallback);
    timebaseTimer->resume();
#else
    TIM4->CR1 = 0;
#endif

    // Enforce exact silicon register configuration after resume()
    TIM4->PSC = 71;     // 72MHz / (71 + 1) = 1MHz (1.0 us tick)
    TIM4->ARR = 0xFFFF; // 16-bit free-running counter rollover at 65535us
    TIM4->CNT = 0;
    TIM4->EGR = TIM_EGR_UG;     // Immediately force-load prescaler shadow buffer in hardware
    TIM4->SR &= ~TIM_SR_UIF;    // Clear the update interrupt flag generated by EGR_UG
    TIM4->DIER |= TIM_DIER_UIE; // Enable update interrupt for 32-bit rollover
#ifndef HOST_SIMULATION_TEST
    NVIC_ClearPendingIRQ(TIM4_IRQn);
    NVIC_SetPriority(TIM4_IRQn, 2);
    NVIC_EnableIRQ(TIM4_IRQn);
    TIM4->CR1 |= TIM_CR1_CEN;
#endif
}

// Provably race-safe atomic snapshot across 16-bit hardware timer overflow
static inline uint32_t get_hardware_timestamp_us() {
    uint32_t high;
    uint16_t low;
    bool pending;

    do {
        high = tim4_overflow_count;
        low  = (uint16_t)(TIM4->CNT);
        pending = (TIM4->SR & TIM_SR_UIF) != 0;
    } while (high != tim4_overflow_count);

    // If an overflow interrupt is pending (UIF set) and CNT has already rolled over
    // to a small value (< 0x8000), account for the unserviced rollover in this reading
    if (pending && (low < 0x8000)) {
        high++;
    }

    return (high << 16) | low;
}
#else
static inline uint32_t get_hardware_timestamp_us() {
    return (uint32_t)bm_micros();
}
#endif
// TIM2 update callback extends the 1 MHz capture counter across 16-bit wraps.
// The core-owned TIM2_IRQHandler calls these through HardwareTimer's HAL bridge.
void tim2CaptureRolloverCallback() {
    tim2OverflowCount++;
}


void tim2HardwareCaptureCallback() {
    // ZERO-CHECK MOTION CAPTURE ISR:
    // No motor sleep check is executed here during normal operation (0 CPU cycles overhead).
    // CCR1 was latched by hardware at the PA0 falling edge, before ISR latency.
    if ((TIM2->SR & TIM_SR_CC1OF) != 0U) {
        tim2CaptureOverrunCount++;
        tim2CaptureMissedCallbacks++; // Accurately record each missed edge in silicon
        isCaptureStreamDiscontinuous = true; // Flag stream discontinuity to prevent false RPM drop
        TIM2->SR &= ~TIM_SR_CC1OF;
    }
    #if defined(HOST_SIMULATION_TEST)
    const uint16_t captured = (uint16_t)captureTimer->getCaptureCompare(1);
#else
    const uint16_t captured = (uint16_t)TIM2->CCR1;
#endif
    uint32_t high = tim2OverflowCount;
    const uint16_t cntNow = (uint16_t)TIM2->CNT;
    const bool updateStillPending = (TIM2->SR & TIM_SR_UIF) != 0U;

    // Provably race-safe atomic epoch resolution across 16-bit hardware timer overflow
    if (updateStillPending) {
        // Rollover occurred in hardware (UIF set), but tim2CaptureRolloverCallback has not
        // incremented tim2OverflowCount yet because HAL services capture callback first.
        // If capture was latched after rollover (small captured value), it belongs to high + 1!
        if (captured < 0x8000U) {
            high++;
        }
    } else {
        // Rollover callback already executed and incremented tim2OverflowCount.
        // If capture occurred just before the wrap (large value near 0xFFFF), it belongs to previous epoch.
        if (high > 0UL && cntNow < captured && (uint16_t)(captured - cntNow) > 0x8000U) {
            high--;
        }
    }

    const uint32_t captureClockUs = (high << 16) | (uint32_t)captured;
    if (!tim2CaptureEpochReady) {
        // Align the capture clock to the TIM4 monotonic clock once. Thereafter,
        // intervals come from TIM2 hardware captures, not ISR dispatch timing.
        tim2CaptureEpochOffsetUs = get_hardware_timestamp_us() - captureClockUs;
        tim2CaptureEpochReady = true;
    }
    const uint32_t captureTimestampUs = tim2CaptureEpochOffsetUs + captureClockUs;
    processSensorTrigger(captureTimestampUs);
}



void initHardwareTimer2() {
    // TIM2_CH1 on PA0 is the single authoritative motion-trigger source.
    // TIM2 capture hardware latches the falling-edge timestamp independent of
    // CPU interrupt latency; its IRQ performs the trigger processing exactly once.
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;

    // Bind stepTimer callback & enable TIM1_UP_IRQn in NVIC via HardwareTimer first,
    // then immediately place TIM1 in deterministic idle state before configuring registers.
#if defined(HOST_SIMULATION_TEST)
    stepTimer->pause();
    stepTimer->setPrescaleFactor(72);
    stepTimer->setOverflow(100);
    stepTimer->setInterruptPriority(0, 0);
    stepTimer->attachInterrupt(stepTimerCallback);
    stepTimer->resume();
#endif

    // TIM1 STEP engine: 1 MHz timer tick; active-low PWM Mode 2.
    TIM1->CR1 = 0;
    TIM1->CCER &= ~TIM_CCER_CC1E;
    TIM1->PSC = 71;
    TIM1->RCR = 0;
    uint16_t initARR = (activePulseWidth > 1) ? (uint16_t)(activePulseWidth - 1) : 1;
    TIM1->ARR = initARR;
    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4); // CH1 PWM Mode 2
    TIM1->CCMR1 |= TIM_CCMR1_OC1PE;
    TIM1->CCER |= TIM_CCER_CC1P;
    TIM1->CR1 |= TIM_CR1_ARPE;
    TIM1->CR1 &= ~TIM_CR1_OPM;
    TIM1->BDTR |= TIM_BDTR_MOE; // Required for advanced-control TIM1 outputs
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR = TIM_EGR_UG;     // Force-load PSC=71, ARR, CCR1, RCR=0 into hardware shadow registers
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Keep PA8 in GP Output Push-Pull HIGH (0x3) while idle so STEP_HIGH_IDLE(),
    // Stepper Jog Test (Page 1), and Opto Sink Test (Page 2) work directly.
    // startHardwareTimerBurst() switches PA8 to AF Push-Pull (0xB) during active TIM1 bursts.
    bm_pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0); // PA8 GP output push-pull, 50 MHz (Idle HIGH)

    // TIM2_CH1 input capture: PA0 / TI1, falling edge, 1 MHz counter.
    // Use STM32duino HardwareTimer callbacks: the core owns TIM2_IRQHandler,
    // and dispatches capture/update callbacks through HAL_TIM_IRQHandler.
    // This makes the CCR1 hardware-latched edge timestamp authoritative without
    // defining a duplicate TIM2_IRQHandler symbol or also dispatching EXTI0.
    tim2OverflowCount = 0UL;
    tim2CaptureOverrunCount = 0UL;
    tim2CaptureEpochOffsetUs = 0UL;
    tim2CaptureEpochReady = false;
    tim2CaptureMissedCallbacks = 0UL;
#if defined(HOST_SIMULATION_TEST)
    captureTimer->pause();
    captureTimer->setMode(1, TIMER_INPUT_CAPTURE_FALLING, proxSensorPin);
    captureTimer->setPrescaleFactor(72);
    captureTimer->setOverflow(0x10000UL);
    captureTimer->setCount(0);
    captureTimer->setInterruptPriority(1, 0);
    captureTimer->attachInterrupt(tim2CaptureRolloverCallback);
    captureTimer->attachInterrupt(1, tim2HardwareCaptureCallback);
    captureTimer->resume();
#else
    pinMode(proxSensorPin, INPUT_PULLUP);
    TIM2->CR1 = 0;
    TIM2->PSC = 71;
    TIM2->ARR = 0xFFFF;
    TIM2->CNT = 0;
    TIM2->CCMR1 &= ~(TIM_CCMR1_CC1S | TIM_CCMR1_IC1F);
    TIM2->CCMR1 |= (0x1U << 0) | (0x3U << 4); // CC1S=01 (TI1), IC1F=0011 (8-sample filter)
    TIM2->CCER &= ~(TIM_CCER_CC1E | TIM_CCER_CC1P);
    TIM2->CCER |= TIM_CCER_CC1E | TIM_CCER_CC1P; // Falling edge capture
    TIM2->DIER = TIM_DIER_CC1IE | TIM_DIER_UIE;
    TIM2->SR = 0;
    NVIC_ClearPendingIRQ(TIM2_IRQn);
    NVIC_SetPriority(TIM2_IRQn, 1);
    NVIC_EnableIRQ(TIM2_IRQn);
    TIM2->CR1 |= TIM_CR1_CEN;
#endif

    // Restore PA0 internal pull-up (setMode resets PA0 to floating input) and enforce IC1F filter
    GPIOA->CRL &= ~(0xFU << 0);
    GPIOA->CRL |= (0x8U << 0);  // Input with pull-up / pull-down
    GPIOA->BSRR = (1U << 0);    // Pull-up enabled on PA0
    // SILICON-LEVEL HARDWARE DIGITAL FILTER (IC1F = 0011):
    // Digital filter debounces PA0 pin for N=8 consecutive clock cycles (111 ns) at f_CK_INT (72MHz).
    // Eliminates high-frequency motor contactor/clutch noise directly in hardware with 0% CPU overhead!
    TIM2->CCMR1 &= ~TIM_CCMR1_IC1F;
    TIM2->CCMR1 |= (0x3U << 4);
}

void startHardwareTimerBurst(int stepCount) {
    startHardwareTimerBurst(stepCount, 0U, 0U);
}

void startHardwareTimerBurst(int stepCount, uint16_t burstPeriodUs, uint32_t burstPeriodQ16) {
    if (stepCount <= 0 || movementState == STATE_FAULT || movementState == STATE_ABORTED) return;

    // ATOMIC CRITICAL SECTION: protect TIM1 hardware start sequence.
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    uint32_t targetPeriodQ16 = burstPeriodQ16 ? burstPeriodQ16 : ((uint32_t)burstPeriodUs << SERVO_PERIOD_Q_SHIFT);
    if (burstPeriodQ16 == 0U && burstPeriodUs == 0U) targetPeriodQ16 = servoPeriodQ16;
    static uint32_t s_burstSeq = 0;

    if (hwBurstActive) {
        // Rare mid-burst overlap path: only read timestamp & enqueue if previous burst is still active
        uint32_t nowUs = get_hardware_timestamp_us();
        if (targetPeriodQ16 >= (SERVO_PERIOD_MIN_US << SERVO_PERIOD_Q_SHIFT) && targetPeriodQ16 < hwBurstPeriodQ16) {
            hwBurstPeriodQ16 = targetPeriodQ16;
        }
        bool enqueued = burstQueue.enqueue((uint32_t)stepCount, motorDirection ? 1 : 0, nowUs, ++s_burstSeq, burstPeriodUs, targetPeriodQ16);
        if (enqueued) {
#if DEBUG_TEST_MODE
            burstQueuedCount++;
            queuedPulseCount += stepCount;
#endif
        } else {
            // Queue saturation / timing overrun: previous burst exceeded mechanical revolution window!
            rejectedTriggerCount++;
            isTimingWarningActive = true;
            isTimingOverrun       = true;
        }
        movementState = STATE_RUNNING;
        __set_PRIMASK(primask);
        return;
    }

    // ULTRA-FAST DIRECT REGISTER PATH (Zero Queue Enqueue/Dequeue Overhead when Idle!):
    hwBurstPeriodQ16   = targetPeriodQ16;
    hwBurstPeriodFrac  = 0;
    hwBurstStepsTarget = stepCount;
    hwBurstStepsDone   = 0;
    hwBurstActive      = true;
#if DEBUG_TEST_MODE
    burstStartedCount++;
    startedPulseCount += stepCount;
#endif
    stepsRemaining     = stepCount;
    totalStepsInBurst  = stepCount;
    stepPinState       = HIGH;
    movementState      = STATE_RUNNING;

    // The servo is the mechanical master. Do not invent an acceleration ramp here.
    // activePulseWidth is derived from the most recent physical trigger interval;
    // maxRPMSetting is only the startup/fallback bound before the first valid interval.
    uint16_t initPeriodUs = q16PeriodToTimerUs(hwBurstPeriodFrac, hwBurstPeriodQ16);
    activePulseWidth = (int)initPeriodUs;
    uint16_t initARR = (initPeriodUs > 1) ? (uint16_t)(initPeriodUs - 1) : 1;
    TIM1->CR1 &= ~TIM_CR1_CEN;
    TIM1->PSC  = 71;
    TIM1->RCR  = 0;
    TIM1->ARR  = initARR;

    uint16_t pWidth = (initARR > STEP_PULSE_WIDTH_US) ? STEP_PULSE_WIDTH_US : (initARR / 2);
    if (pWidth < 2) pWidth = 2;
    TIM1->CCR1 = initARR - pWidth + 1;

    // Ensure PWM Mode 2, preload, active-low polarity, and OPM disabled
    TIM1->CCMR1 &= ~(TIM_CCMR1_OC1M | TIM_CCMR1_CC1S);
    TIM1->CCMR1 |= (0x7U << 4) | TIM_CCMR1_OC1PE;
    TIM1->CCER  |= TIM_CCER_CC1P;
    TIM1->CR1   |= TIM_CR1_ARPE;
    TIM1->CR1   &= ~TIM_CR1_OPM;

    // Force load preload registers into shadow registers and reset CNT to 0
    // Temporarily mask UIE so EGR_UG does not latch a spurious update interrupt into NVIC
    TIM1->DIER &= ~TIM_DIER_UIE;
    TIM1->EGR   = TIM_EGR_UG;
    TIM1->SR   &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);
    TIM1->DIER |= TIM_DIER_UIE;
    NVIC_EnableIRQ(TIM1_UP_IRQn);

    // Enable hardware PWM output and Main Output Enable on PA8 in silicon before AF switch
    TIM1->CCER |= TIM_CCER_CC1E;
    TIM1->BDTR |= TIM_BDTR_MOE;

    // Connect PA8 directly to TIM1_CH1: Alternate Function Push-Pull 50MHz
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0xBU << 0); // 1011b = AF Output Push-Pull 50MHz

    // Start timer counter in silicon
    TIM1->CR1 |= TIM_CR1_CEN;

    __set_PRIMASK(primask);
}

void stopHardwareTimerImmediately() {
    uint32_t primask = __get_PRIMASK();
    __disable_irq();

    TIM1->CCER &= ~TIM_CCER_CC1E; // Disable hardware PWM output on PA8 in silicon
    TIM1->CR1  &= ~TIM_CR1_CEN;   // Stop timer counter in silicon
    TIM1->CR1  &= ~TIM_CR1_OPM;   // Ensure OPM cleared

    // Restore PA8 pin to General Purpose Output HIGH (Idle)
    GPIOA->CRH &= ~(0xFU << 0);
    GPIOA->CRH |= (0x3U << 0);
    STEP_HIGH_IDLE();
    stepPinState = HIGH;

    // Clear all pending flags and interrupts
    TIM1->SR &= ~TIM_SR_UIF;
    NVIC_ClearPendingIRQ(TIM1_UP_IRQn);

    uint32_t abortedFromQueue = burstQueue.abortAll();
#if DEBUG_TEST_MODE
    int uncompleted = (hwBurstStepsTarget - hwBurstStepsDone) + (int)abortedFromQueue;
    if (uncompleted > 0) {
        abortedPulseCount += uncompleted;
        queuedPulseCount = 0;
    }
#else
    (void)abortedFromQueue;
#endif

    hwBurstActive        = false;
    hwBurstStepsTarget   = 0;
    hwBurstStepsDone     = 0;
    stepsRemaining       = 0;
    pulseFracAccumulator = 0UL;
    hwBurstPeriodFrac    = 0UL;
    movementState        = STATE_ABORTED;

    __set_PRIMASK(primask);
}

void recalculatePitchProfiles() {
    // Explicit numerical bounds checking
    if ((rollerDia != rollerDia) || rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
    if (driverResolution < 200 || driverResolution > 51200) driverResolution = 6400;
    float circumference = 3.14159265f * rollerDia;
    float pulsesPerMM = (float)driverResolution / circumference;
    // 64-bit intermediate arithmetic: strictly prevents uint32_t overflow at max 51200 res / 15mm roller
    const float pitch5 = 1.54625411f;  // Calibrated for 70.00 pulses at 6400 res / 45mm roller
    const float pitch8 = 1.76714755f;  // Calibrated for 80.00 pulses at 6400 res / 45mm roller
    const float pitch10 = 2.20893444f; // Calibrated for 100.00 pulses at 6400 res / 45mm roller
    p5_fixed  = (uint64_t)(pitch5 * pulsesPerMM * 1000000.0 + 0.5);
    p8_fixed  = (uint64_t)(pitch8 * pulsesPerMM * 1000000.0 + 0.5);
    p10_fixed = (uint64_t)(pitch10 * pulsesPerMM * 1000000.0 + 0.5);
    if (p5_fixed < 1000000ULL) p5_fixed = 1000000ULL;
    if (p8_fixed < 1000000ULL) p8_fixed = 1000000ULL;
    if (p10_fixed < 1000000ULL) p10_fixed = 1000000ULL;
}

void syncPulseIntegerFraction() {
    uint32_t intPart  = (uint32_t)(currentPulsesFixed / 1000000ULL);
    uint32_t fracPart = (uint32_t)(currentPulsesFixed % 1000000ULL);
    currentPulsesInt  = intPart;
    currentPulsesFrac = fracPart;
    commitPulseParameters(intPart, fracPart);
}

// Pure mathematical calculation of un-clamped step period (us) for given pulse count & settings
static inline int calculateRawPulseWidthUs(uint64_t pulsesFixed, int32_t rpm, int32_t angle, int32_t margin) {
    if (rpm < 100) rpm = 100;
    if (angle < 30) angle = 30;
    if (margin < 0) margin = 0;
    if (margin > 29) margin = 29;
    float timeWindowUs = (60000000.0f / (float)rpm) * ((float)angle / 360.0f) * (1.0f - ((float)margin / 100.0f));
    float steps = (float)pulsesFixed / 1000000.0f;
    if (steps < 1.0) steps = 1.0;
    return (int)(timeWindowUs / steps);
}

static inline int calculateMaxSafeRpmForPulses(uint64_t pulsesFixed, int32_t angle, int32_t margin) {
    float steps = (float)pulsesFixed / 1000000.0f;
    if (steps < 1.0) steps = 1.0;
    float windowFactor = ((float)angle / 360.0f) * (1.0f - ((float)margin / 100.0f));
    float maxRpm = (60000000.0f * windowFactor) / (steps * 8.0f);
    int rpm50 = ((int)maxRpm / 50) * 50;
    if (rpm50 > 4000) rpm50 = 4000;
    return rpm50;
}

static char s_limitNoticeLine2[24] = {0};

static inline void checkAndShowPulseOutOfRangeNotice(uint64_t pulsesFixed) {
    int rawW = calculateRawPulseWidthUs(pulsesFixed, maxRPMSetting, feedAngleDeg, safetyMarginPercent);
    if (rawW <= 6) {
        float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f) *
                             (1.0f - ((float)safetyMarginPercent / 100.0f));
        int maxSafeTenths = (int)((timeWindowUs * 10.0f) / 8.0f + 0.5f);
        if (maxSafeTenths < 10) maxSafeTenths = 10;
        memcpy(s_limitNoticeLine2, "MAX PULSE:       ", 17);
        formatFixed1(s_limitNoticeLine2 + 10, (uint32_t)maxSafeTenths, 3, false);
        uiBannerLine1 = "OUT OF RANGE    ";
        uiBannerLine2 = s_limitNoticeLine2;
        uiMessageTimer = bm_millis() + 1500UL;
        oldMenuState = -1;
    }
}

static inline void checkAndShowSizeLimitNotice(int32_t sizeIdx) {
    uint64_t pFixed = (sizeIdx == 1) ? p5_fixed : ((sizeIdx == 2) ? p8_fixed : p10_fixed);
    const char *szTag = (sizeIdx == 1) ? "S5 " : ((sizeIdx == 2) ? "S8 " : "S10");
    int rawW = calculateRawPulseWidthUs(pFixed, maxRPMSetting, feedAngleDeg, safetyMarginPercent);
    if (rawW < 8) {
        int safeRpm = calculateMaxSafeRpmForPulses(pFixed, feedAngleDeg, safetyMarginPercent);
        if (safeRpm < 500 && driverResolution > 6400) {
            memcpy(s_limitNoticeLine2, "SET RES <= 6400 ", 17);
        } else {
            if (safeRpm < 100) safeRpm = 100;
            memcpy(s_limitNoticeLine2, "    MAX RPM:    ", 17);
            memcpy(s_limitNoticeLine2, szTag, 3);
            formatUint(s_limitNoticeLine2 + 12, (uint32_t)safeRpm, 4, false);
        }
        uiBannerLine1 = "LIMIT REACHED!  ";
        uiBannerLine2 = s_limitNoticeLine2;
        uiMessageTimer = bm_millis() + 1500UL;
        oldMenuState = -1;
    }
}

static inline bool checkAndShowAllSizesSettingsLimitNotice() {
    uint64_t pArr[3] = { p5_fixed, p8_fixed, p10_fixed };
    const char *tags[3] = { "S5 ", "S8 ", "S10" };
    int worstIdx = -1;
    uint64_t maxPulses = 0;
    for (int i = 0; i < 3; i++) {
        int w = calculateRawPulseWidthUs(pArr[i], maxRPMSetting, feedAngleDeg, safetyMarginPercent);
        if (w < 8 && pArr[i] >= maxPulses) {
            maxPulses = pArr[i];
            worstIdx = i;
        }
    }
    if (worstIdx >= 0) {
        int safeRpm = calculateMaxSafeRpmForPulses(pArr[worstIdx], feedAngleDeg, safetyMarginPercent);
        if (safeRpm < 500 && driverResolution > 6400) {
            memcpy(s_limitNoticeLine2, "SET RES <= 6400 ", 17);
        } else {
            if (safeRpm < 100) safeRpm = 100;
            memcpy(s_limitNoticeLine2, "    MAX RPM:    ", 17);
            memcpy(s_limitNoticeLine2, tags[worstIdx], 3);
            formatUint(s_limitNoticeLine2 + 12, (uint32_t)safeRpm, 4, false);
        }
        uiBannerLine1 = "LIMIT REACHED!  ";
        uiBannerLine2 = s_limitNoticeLine2;
        uiMessageTimer = bm_millis() + 1500UL;
        oldMenuState = -1;
        return true;
    }
    return false;
}

void updateActivePulseWidth() {
    syncPulseIntegerFraction();
    if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
    if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 90;
    if (safetyMarginPercent < 0 || safetyMarginPercent > 29) safetyMarginPercent = 15;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));
    float activeSteps = (float)currentPulsesFixed / 1000000.0f;
    if (activeSteps < 1.0f) activeSteps = 1.0f;
    float requestedPeriodUs = timeWindowUs / activeSteps;
    int calcPeriod = (int)requestedPeriodUs;
    pulseTimingInvalid = (calcPeriod < 8);
    if (calcPeriod < (int)SERVO_PERIOD_MIN_US) calcPeriod = (int)SERVO_PERIOD_MIN_US;
    if (calcPeriod > (int)SERVO_PERIOD_MAX_US) calcPeriod = (int)SERVO_PERIOD_MAX_US;
    activePulseWidth = calcPeriod;
    uint32_t nominalSteps = (uint32_t)(currentPulsesFixed / 1000000ULL);
    if (nominalSteps < 1U) nominalSteps = 1U;
    servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(0UL, nominalSteps);
}

void calculateAllPulseWidths() {
    if (maxRPMSetting <= 0) maxRPMSetting = 3000;
    if (feedAngleDeg <= 0) feedAngleDeg = 90;
    float timeWindowUs = (60000000.0f / (float)maxRPMSetting) * ((float)feedAngleDeg / 360.0f);
    timeWindowUs *= (1.0f - ((float)safetyMarginPercent / 100.0f));

    float s5 = (float)p5_fixed / 1000000.0f;
    if (s5 < 1.0f) s5 = 1.0f;
    // Safe industrial limit: Full step period [8us, 500us] (guarantees >= 2.5us driver opto timing)
    autoPulseWidth_P5 = constrain((int)(timeWindowUs / s5), 8, 500);

    float s8 = (float)p8_fixed / 1000000.0f;
    if (s8 < 1.0f) s8 = 1.0f;
    autoPulseWidth_P8 = constrain((int)(timeWindowUs / s8), 8, 500);

    float s10 = (float)p10_fixed / 1000000.0f;
    if (s10 < 1.0f) s10 = 1.0f;
    autoPulseWidth_P10 = constrain((int)(timeWindowUs / s10), 8, 500);

    updateActivePulseWidth();

}

static char s_diagDynamicLine2[24] = "NONE / OPTIMAL  ";

void evaluateDiagnostics() {
    float tempDia      = (tempRollerDia >= 10.0f && tempRollerDia <= 100.0f) ? tempRollerDia : 45.0f;
    int32_t tempRes    = (tempDriverRes >= 200 && tempDriverRes <= 51200) ? tempDriverRes : 6400;
    int32_t tempRPM    = (tempMaxRPM >= 100 && tempMaxRPM <= 4000) ? tempMaxRPM : 3000;
    int32_t tempAngle  = (tempFeedAngle >= 30 && tempFeedAngle <= 270) ? tempFeedAngle : 90;
    int32_t tempMargin = constrain(tempSafetyMargin, 0, 29);

    float tempCirc = 3.14159265f * tempDia;
    float tempPPM  = (float)tempRes / tempCirc;
    float s10_test = 2.20893444f * tempPPM;
    float cur_test = (float)currentPulsesFixed / 1000000.0f;
    float maxSteps = (cur_test > s10_test) ? cur_test : s10_test;
    if (maxSteps < 1.0f) maxSteps = 1.0f;

    float timeWinTest = (60000000.0f / (float)tempRPM) * ((float)tempAngle / 360.0f) * (1.0f - ((float)tempMargin / 100.0f));
    diagMinW = (int)(timeWinTest / maxSteps);

    if (diagMinW < 8) {
        isTimingWarningActive = true;
        diagFixLine1 = "ACTIVE ISSUE:   ";
        if (tempRes > 6400) {
            diagFixLine2 = "SET RES = 6400  ";
        } else {
            uint64_t maxFixed = (uint64_t)(maxSteps * 1000000.0f);
            int safeRpm = calculateMaxSafeRpmForPulses(maxFixed, tempAngle, tempMargin);
            if (safeRpm < 100) safeRpm = 100;
            memcpy(s_diagDynamicLine2, "MAX RPM <=      ", 17);
            formatUint(s_diagDynamicLine2 + 11, (uint32_t)safeRpm, 4, false);
            diagFixLine2 = s_diagDynamicLine2;
        }
    } else if (isMotionSyncLost) {
        isTimingWarningActive = true;
        diagFixLine1 = "ACTIVE ISSUE:   ";
        diagFixLine2 = "FAULT:SYNC LOST!";
    } else {
        isTimingWarningActive = false;
        diagFixLine1 = "ACTIVE ISSUE:   ";
        diagFixLine2 = "NONE / OPTIMAL  ";
    }
}

// =========================================================================
// TWO-PHASE ATOMIC DEFERRED TRIGGER DISPATCH ENGINE (SECTION 6 RACE FIX)
// Dispatches any triggers deferred during Flash save/abort window.
// Prevents newer incoming physical triggers from overtaking older deferred work.
// Only after deferred pulses are safely handed off does the lock return to IDLE.
// =========================================================================
static void dispatchDeferredSaveTriggers() {
    for (;;) {
        uint8_t defDir = 0;
        uint32_t defTs = 0;
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        uint32_t defSteps = flashSaveTx.captureDeferredForDispatch(defDir, defTs);
        const bool stillPending = flashSaveTx.deferredTriggerPending;
        if (defSteps == 0U && !stillPending) {
            flashSaveTx.completeHandoff();
            __set_PRIMASK(primask);
            break;
        }
        __set_PRIMASK(primask);

        if (defSteps == 0U) continue;
        if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
            startHardwareTimerBurst((int)defSteps);
        } else {
#if DEBUG_TEST_MODE
            abortedPulseCount += (int)defSteps;
#endif
        }
    }
}

static inline void syncStoredBaselinesWithRam() {
    pulseStepStored_p5         = p5_fixed;
    pulseStepStored_p8         = p8_fixed;
    pulseStepStored_p10        = p10_fixed;
}

bool saveToEEPROM() {
    // Watchdog-safe selective persistence: only allowed at confirmed standstill.
    IWDG_FEED();
    if (!isMachineSafelyIdle()) return false;
    IWDG_FEED();
    if (!flashSaveTx.requestSaveLock()) {
        IWDG_FEED();
        return false;
    }

    if (!flashSaveTx.confirmLockAndTransition(isMachineSafelyIdle())) {
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return false;
    }

    // TRUE DUAL-SLOT PING-PONG STORAGE:
    // Write strictly to the ALTERNATE slot so the current active slot remains 100% intact as fail-safe rollback!
    uint32_t targetSlot = (activeEEPROMSlot == 0) ? 1U : 0U;
    int targetOffset    = (targetSlot == 0) ? 0 : 128;
    int currentOffset   = (activeEEPROMSlot == 0) ? 0 : 128;

    MachineConfigRecord activeRec;
    EEPROM.get(currentOffset, activeRec);
    const bool currentSlotValid = PulseStepPersistenceManager::validateRecord(activeRec) &&
                                  (activeRec.magic == EEPROM_MAGIC_V17_1_0 || activeRec.magic == EEPROM_MAGIC_V17_0_0);

    MachineConfigRecord rec;
    memset(&rec, 0, sizeof(MachineConfigRecord));
    rec.magic    = EEPROM_MAGIC_V17_1_0;
    rec.seq      = (currentSlotValid ? activeRec.seq : eepromSeqNumber) + 1U;
    uint32_t calTag = keypadCalibrationLocked ? 0x5A000000UL : 0x00000000UL;
    uint32_t kpBits = ((uint32_t)(keypadMode & 0x03U)) << 16;
    rec.reserved = calTag | kpBits;

    rec.payload.p5_fixed            = p5_fixed;
    rec.payload.p8_fixed            = p8_fixed;
    rec.payload.p10_fixed           = p10_fixed;
    rec.payload.driverResolution    = driverResolution;
    rec.payload.rollerDia           = rollerDia;
    rec.payload.maxRPMSetting       = maxRPMSetting;
    rec.payload.feedAngleDeg        = feedAngleDeg;
    rec.payload.safetyMarginPercent = safetyMarginPercent;
    rec.payload.currentSize         = currentSize;
    rec.payload.sensorGuardActive   = keypad6ButtonMode ? 1UL : 0UL; // Persists 3-BTN (0) vs 6-BTN (1) mode
    rec.payload.autoLockSec         = autoLockSec;
    rec.payload.motorDirection      = motorDirection ? 1UL : 0UL;
    rec.payload.backlightSec        = backlightSec;
    rec.payload.motorSleepMin       = motorSleepMin;

    if (currentSlotValid && (activeRec.magic == EEPROM_MAGIC_V17_1_0) &&
        (rec.reserved == activeRec.reserved) &&
        memcmp(&rec.payload, &activeRec.payload, sizeof(MachineConfigPayload)) == 0) {
        // Zero parameters changed and active slot is already V17.1.0: skip write completely (0 Flash writes)
        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges = false;
        dispatchDeferredSaveTriggers();
        IWDG_FEED();
        return true;
    }

    rec.crc32 = calculateCRC32((const uint8_t*)&rec.payload, sizeof(MachineConfigPayload));

    // Abort save immediately if any PA0 trigger arrived or machine moved!
    if (!isMachineSafelyIdle() || flashSaveTx.lockState != SAVE_LOCK_LOCKED) {
        flashSaveTx.abortLock();
        IWDG_FEED();
        return false;
    }

    IWDG_FEED();
    MachineConfigRecord targetRec;
    EEPROM.get(targetOffset, targetRec);
    // Require targetRec.magic == EEPROM_MAGIC_V17_1_0 for selective field patching;
    // if target slot holds an older V17.0.0/V16.5.1 record, perform a full atomic record upgrade!
    const bool targetSlotValid = PulseStepPersistenceManager::validateRecord(targetRec) &&
                                 (targetRec.magic == EEPROM_MAGIC_V17_1_0);

    // offsetof(MachineConfigRecord, payload.p5_fixed) offsetof(MachineConfigRecord, payload.sensorGuardActive)
    (void)targetSlotValid;
    EEPROM.put(targetOffset, rec);
    IWDG_FEED();

    MachineConfigRecord readBack;
    EEPROM.get(targetOffset, readBack);

    bool saveOk = false;
    if (PulseStepPersistenceManager::validateRecord(readBack) &&
        memcmp(&rec, &readBack, sizeof(MachineConfigRecord)) == 0) {
        flashWriteCount++;
        activeEEPROMSlot       = targetSlot; // Ping-pong slot swap: targetSlot is now authoritative!
        eepromSeqNumber        = rec.seq;
        eepromSlotInitialized  = true;
        syncStoredBaselinesWithRam();
        pulseModifiedByUser    = false;
        autoSavePendingStandstill = false;
        hasStagedChanges       = false;
        calculateAllPulseWidths();
        saveOk = true;
    }

    dispatchDeferredSaveTriggers();
    IWDG_FEED();
    return saveOk;
}

void loadFactoryDefaults() {
    driverResolution       = 6400;
    rollerDia              = 45.0f;
    maxRPMSetting          = 3000;
    feedAngleDeg           = 90;
    safetyMarginPercent    = 15;
    currentSize            = 2;     // Size #8 default
    motorDirection         = false; // NORMAL FORWARD DEFAULT
    keypad6ButtonMode      = false; // DEFAULT: 3-BTN Mode (Backward compatible with 3-button hardware)
    keypadMode             = 0;     // DEFAULT: 0 = 3-BTN
    keypadCalibrationLocked = true;
    calibStep              = 0;
    autoLockSec            = 30UL;  // DEFAULT: 30s Auto-Lock ON (0 = OFF)
    lastEnabledAutoLockSec = 30UL;
    backlightSec           = 0;     // DEFAULT: 0 = ALWAYS ON
    motorSleepMin          = 0UL;   // DEFAULT: 0 = OFF

    tempDriverRes          = driverResolution;
    tempRollerDia          = rollerDia;
    tempMaxRPM             = maxRPMSetting;
    tempFeedAngle          = feedAngleDeg;
    tempSafetyMargin       = safetyMarginPercent;
    tempMotorDir           = motorDirection;
    tempKeypad6Btn         = keypad6ButtonMode;
    tempAutoLockSec        = autoLockSec;
    tempBacklightSec       = backlightSec;
    tempMotorSleepMin      = motorSleepMin;
    isSpeedDialActive      = false;
    speedDialLen           = 0;
    speedDialHasDot        = false;
    speedDialDecCount      = 0;

    isUiLocked             = false;
    isEditingMainDecimal   = false;
    isEditingSetting       = false;
    blinkTarget            = BLINK_NONE;
    applyMotorDirection();
    recalculatePitchProfiles();
    p5_fixed               = 70000000ULL;
    p8_fixed               = 80000000ULL;
    p10_fixed              = 100000000ULL;
    currentPulsesFixed     = p8_fixed;
    calculateAllPulseWidths();
    syncStoredBaselinesWithRam();
    pulseModifiedByUser    = false;
    hasStagedChanges       = false;
}

void loadFromEEPROM() {
    MachineConfigRecord rec0, rec1;
    EEPROM.get(0, rec0);
    EEPROM.get(128, rec1);

    bool v0 = PulseStepPersistenceManager::validateRecord(rec0);
    bool v1 = PulseStepPersistenceManager::validateRecord(rec1);

    MachineConfigRecord *chosen = nullptr;
    uint32_t chosenSlot = 0;

    if (v0 && v1) {
        if (rec0.seq >= rec1.seq) {
            chosen = &rec0;
            chosenSlot = 0;
        } else {
            chosen = &rec1;
            chosenSlot = 1;
        }
    } else if (v0) {
        chosen = &rec0;
        chosenSlot = 0;
    } else if (v1) {
        chosen = &rec1;
        chosenSlot = 1;
    }

    if (chosen != nullptr) {
        activeEEPROMSlot      = chosenSlot;
        eepromSeqNumber       = chosen->seq;
        eepromSlotInitialized = true;

        p5_fixed            = chosen->payload.p5_fixed;
        p8_fixed            = chosen->payload.p8_fixed;
        p10_fixed           = chosen->payload.p10_fixed;
        driverResolution    = chosen->payload.driverResolution;
        rollerDia           = chosen->payload.rollerDia;
        if (rollerDia < 10.0f || rollerDia > 100.0f) rollerDia = 45.0f;
        maxRPMSetting       = chosen->payload.maxRPMSetting;
        if (maxRPMSetting < 100 || maxRPMSetting > 4000) maxRPMSetting = 3000;
        feedAngleDeg        = chosen->payload.feedAngleDeg;
        if (feedAngleDeg < 30 || feedAngleDeg > 270) feedAngleDeg = 90;
        safetyMarginPercent = chosen->payload.safetyMarginPercent;
        if (safetyMarginPercent < 0 || safetyMarginPercent > 29) safetyMarginPercent = 15;
        currentSize         = chosen->payload.currentSize;
        if (currentSize < 1 || currentSize > 3) currentSize = 2;
        keypad6ButtonMode   = (chosen->payload.sensorGuardActive == 1UL);
        if ((chosen->reserved & 0xFF000000UL) == 0x5A000000UL) {
            keypadCalibrationLocked = true;
            keypadMode = (uint8_t)((chosen->reserved >> 16) & 0x03U);
            if (keypadMode > 2U) keypadMode = 0U;
            keypad6ButtonMode = (keypadMode == 1U);
        } else {
            keypadCalibrationLocked = true;
            keypadMode = keypad6ButtonMode ? 1U : 0U;
        }
        motorDirection      = (chosen->payload.motorDirection == 1UL);

        autoLockSec = chosen->payload.autoLockSec;
        if (autoLockSec > 0UL && autoLockSec < 10UL) autoLockSec = 10UL;
        if (autoLockSec > 300UL) autoLockSec = 30UL;
        lastEnabledAutoLockSec = (autoLockSec >= 10UL && autoLockSec <= 300UL) ? autoLockSec : 30UL;

        backlightSec = chosen->payload.backlightSec;
        if (backlightSec < 0 || (backlightSec > 0 && backlightSec < 10)) backlightSec = 0;
        if (backlightSec > 300 && backlightSec != 999) backlightSec = 0;

        motorSleepMin = chosen->payload.motorSleepMin;
        if (motorSleepMin > 0UL && motorSleepMin < 20UL) motorSleepMin = 0UL;
        if (motorSleepMin > 300UL) motorSleepMin = 0UL;

        tempDriverRes     = driverResolution;
        tempRollerDia     = rollerDia;
        tempMaxRPM        = maxRPMSetting;
        tempFeedAngle     = feedAngleDeg;
        tempSafetyMargin  = safetyMarginPercent;
        tempMotorDir      = motorDirection;
        tempKeypad6Btn    = keypad6ButtonMode;
        tempAutoLockSec   = autoLockSec;
        tempBacklightSec  = backlightSec;
        tempMotorSleepMin = motorSleepMin;
        isUiLocked        = false;

        applyMotorDirection();
        if (p5_fixed < PULSE_STEP_MIN_FIXED || p5_fixed > PULSE_STEP_MAX_FIXED ||
            p8_fixed < PULSE_STEP_MIN_FIXED || p8_fixed > PULSE_STEP_MAX_FIXED ||
            p10_fixed < PULSE_STEP_MIN_FIXED || p10_fixed > PULSE_STEP_MAX_FIXED) {
            recalculatePitchProfiles();
        }
        calculateAllPulseWidths();

        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        if (currentSize == 1) currentPulsesFixed = p5_fixed;
        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
        else currentPulsesFixed = p10_fixed;
        __set_PRIMASK(primask);
        updateActivePulseWidth();

        syncStoredBaselinesWithRam();
        pulseModifiedByUser = false;
        autoSavePendingStandstill = false;
        hasStagedChanges    = false;
    } else {
        loadFactoryDefaults();
    }
}

// PRIMARY MOTION PATH: PA0 falling-edge trigger -> this ISR -> one synchronized PA8 STEP burst.
// Auxiliary sensors/relay logic must never preempt, abort, or replace this path.
// Reset only the RPM display estimator; raw timing/safety state remains separate.
static inline void resetRpmIntervalHistory() {
    rpmIntervalHistoryUs[0] = 0UL;
    rpmIntervalHistoryUs[1] = 0UL;
    rpmIntervalHistoryUs[2] = 0UL;
    rpmIntervalHistoryCount = 0U;
    rpmIntervalHistoryIndex = 0U;
}

static inline uint32_t median3u32(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    if (b > c) { uint32_t t = b; b = c; c = t; }
    if (a > b) { uint32_t t = a; a = b; b = t; }
    return b;
}

// Process one PA0 falling edge using its TIM2 hardware-captured timestamp.
// Process one accepted PA0 edge. This function receives the monotonic TIM4 timestamp from sensorISR.
void processSensorTrigger(uint32_t capturedTimestampUs) {
    const uint32_t nowUs = capturedTimestampUs;
    unsigned long diff = 0;

    if (lastTriggerMicros == 0UL) {
        // Backup safety reset on first trigger after cold boot / explicit stop reset:
        lastMeasuredIntervalUs = 0UL;
        currentRPM = 0UL;
        pulseFracAccumulator = 0UL;
        hwBurstPeriodFrac = 0UL;
        resetRpmIntervalHistory();
        acceptedTriggerPulses++;
        validTriggerCount = 1U;
        motionWatchdogArmed = false;
    } else {
        // Both values are extended TIM2 capture timestamps (1 tick = 1 us).
        // Unsigned subtraction is wrap-safe across the 32-bit timestamp rollover.
        diff = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);

        // Backup Safety Net in ISR (Tier 2):
        // If > 400,000 us (0.4s = 150 RPM sewing floor) elapsed since the last falling edge,
        // the machine stopped or paused (e.g. hand-set cam to pedal start). Treat as Stitch #1!
        if (diff > 400000UL) {
            lastMeasuredIntervalUs = 0UL;
            currentRPM = 0UL;
            pulseFracAccumulator = 0UL;
            hwBurstPeriodFrac = 0UL;
            resetRpmIntervalHistory();
            acceptedTriggerPulses++;
            validTriggerCount = 1U;
            motionWatchdogArmed = false;
            diff = 0UL; // Re-baseline motion; never turn human pause time into STEP period.
            isCaptureStreamDiscontinuous = false;
        } else if (isCaptureStreamDiscontinuous) {
            // Overcapture recovery: CCR1 was overwritten before service, so diff spans 2+ physical cycles.
            // Do NOT let this 2x artifact drop the displayed RPM or stretch the STEP burst!
            isCaptureStreamDiscontinuous = false;
            tim2CaptureResyncEvents++;
            // Resynchronize to the continuous operating interval so RPM and STEP timing remain stable
            if (lastMeasuredIntervalUs > 0UL) {
                diff = lastMeasuredIntervalUs;
            } else if (diff > 0UL) {
                diff = diff / 2UL; // Estimate single-revolution period if overcapture occurred on startup
                lastMeasuredIntervalUs = diff;
            }
            acceptedTriggerPulses++;
            validTriggerCount++;
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }
        } else {
            // Speed-adaptive software blanking: 1.5ms minimum and 4.5ms maximum.
            unsigned long activeBlankingUs = 1000UL;
            if (lastMeasuredIntervalUs > 0UL) {
                activeBlankingUs = lastMeasuredIntervalUs / 4UL; // 25% of previous revolution
                if (activeBlankingUs < 1000UL) activeBlankingUs = 1000UL;
                if (activeBlankingUs > 4000UL) activeBlankingUs = 4000UL;
            }

            // Speed-adaptive software blanking: 1.0ms minimum and 4.0ms maximum.
            // CRITICAL NEEDLE SAFETY INVARIANT: Every needle cycle MUST produce a STEP burst!
            // If a pulse is dropped or rejected, the zipper tape remains stationary while the needle
            // plunges into the coil, jamming or breaking the needle.
            // We reject ONLY sub-millisecond switch contact chatter (< activeBlankingUs).
            // Never drop a cycle due to machine speed exceeding maxRPMSetting.
            if (diff < activeBlankingUs) {
                rejectedTriggerCount++;
                return; // Pure sub-millisecond optocoupler contact chatter rejected
            }

            // Servo plausibility guard: at configured max RPM, one revolution has
            // 60,000,000/maxRPMSetting us. Allow 25% speed headroom (period >= 75% of
            // that value), which rejects 4.5-9ms false edges while allowing a 3000 RPM
            // machine (20ms/rev) and brief speed transients up to ~4000 RPM.
            uint32_t configuredMaxRPM = (maxRPMSetting >= 100 && maxRPMSetting <= 4000)
                ? (uint32_t)maxRPMSetting : 3000UL;
            uint32_t minimumPlausibleIntervalUs = (60000000UL / configuredMaxRPM) * 3UL / 4UL;
            if (diff < minimumPlausibleIntervalUs) {
                rejectedTriggerCount++;
                return; // Implausibly fast edge: keep lastTriggerMicros unchanged.
            }

            lastMeasuredIntervalUs = diff;
            acceptedTriggerPulses++;
            validTriggerCount++;
            // A real interval now exists: this is the first point at which
            // motion-loss monitoring is allowed to arm.
            motionWatchdogArmed = (validTriggerCount >= 1U && diff > 0UL);
            if (isMotionSyncLost) {
                isMotionSyncLost = false;
            }

        }
    }

    // 2. DIRECT REAL-TIME INTERVAL RESOLUTION (100% Raw Physical Revolution `diff` for StepPulse!)
    // median3u32() is NEVER used for StepPulse generation so both acceleration and deceleration
    // track the exact physical needle revolution interval (`diff`) with zero 3-stitch history lag!
    const uint32_t stepTimingIntervalUs = (uint32_t)diff;
    const uint32_t prevTriggerMicros = lastTriggerMicros;
    lastTriggerMicros  = nowUs;
    lastTriggerTimerUs = get_hardware_timestamp_us();

    // 3. ZERO-LATENCY STEPPER BURST TRIGGERING (Fires TIM1 in Silicon BEFORE any secondary UI work!)
    if (movementState != STATE_FAULT && movementState != STATE_ABORTED) {
        PulseParameters snap;
        snap.integerPart    = activePulseParams.integerPart;
        snap.fractionalPart = activePulseParams.fractionalPart;
        snap.generation     = activePulseParams.generation;
#if DEBUG_TEST_MODE
        paramGenerationUsed = snap.generation;
        acceptedTriggerCount++;
        requestedPulseCount += snap.integerPart;
#endif
        int newSteps = (int)snap.integerPart;
        pulseFracAccumulator += snap.fractionalPart;
        if (pulseFracAccumulator >= 1000000UL) {
            newSteps++;
            pulseFracAccumulator -= 1000000UL;
#if DEBUG_TEST_MODE
            requestedPulseCount++;
#endif
        }

        // Direct Max-RPM Clamped Step Period:
        // Directly uses the configured Max-RPM clamp without redundant Cam-Gap or dynamic RPM division.
        // Measured `diff` is used strictly for live RPM display, noise filtering, and motion watchdog.
        if (stepTimingIntervalUs > 0UL) {
            updateStepPeriodFromServoInterval(stepTimingIntervalUs, (uint32_t)newSteps);
        } else {
            servoPeriodQ16 = calculateAdaptiveStepPeriodQ16(0UL, (uint32_t)newSteps);
        }
        uint32_t burstPeriodQ16 = servoPeriodQ16;
        uint16_t burstPeriodUs = (uint16_t)(burstPeriodQ16 >> SERVO_PERIOD_Q_SHIFT);
        if (burstPeriodUs < SERVO_PERIOD_MIN_US) burstPeriodUs = SERVO_PERIOD_MIN_US;
        if (burstPeriodUs > SERVO_PERIOD_MAX_US) burstPeriodUs = SERVO_PERIOD_MAX_US;

        if (newSteps > 0) {
            // TRIGGER IS KING: If a standstill save lock was active, abort save immediately
            // and fire the real-time TIM1 burst with 0.00 us deferral delay!
            if (flashSaveTx.isSaveLockActive()) {
                flashSaveTx.abortLock();
            }
            startHardwareTimerBurst(newSteps, burstPeriodUs, burstPeriodQ16);
        }
    }

    // 4. POST-BURST SECONDARY HOUSEKEEPING (Executes ONLY AFTER TIM1 is already running on PA8!)
    // median3u32() is used STRICTLY for LCD Display RPM smoothing (currentRPM), NEVER for StepPulse!
    STATUS_LED_ON();
    if (prevTriggerMicros != 0UL && diff > 0UL && diff <= 2000000UL) {
        rpmIntervalHistoryUs[rpmIntervalHistoryIndex] = (uint32_t)diff;
        rpmIntervalHistoryIndex = (uint8_t)((rpmIntervalHistoryIndex + 1U) % 3U);
        if (rpmIntervalHistoryCount < 3U) rpmIntervalHistoryCount++;
        uint32_t rpmIntervalForDisplay = (uint32_t)diff;
        if (rpmIntervalHistoryCount >= 3U) {
            rpmIntervalForDisplay = median3u32(rpmIntervalHistoryUs[0],
                                               rpmIntervalHistoryUs[1],
                                               rpmIntervalHistoryUs[2]);
        }
        if (rpmIntervalForDisplay > 0UL) {
            const unsigned long instantRPM = 60000000UL / rpmIntervalForDisplay;
            if (instantRPM > 0UL && instantRPM <= 40000UL) {
                if (currentRPM == 0UL) currentRPM = instantRPM;
                else currentRPM = (unsigned long)((3UL * instantRPM + 5UL * currentRPM) / 8UL);
            }
        }
    } else if (diff > 2000000UL) {
        currentRPM = 0UL;
        resetRpmIntervalHistory();
    }

    if (isEditingMainDecimal || blinkTarget != BLINK_NONE) {
        isEditingMainDecimal = false;
        blinkTarget = BLINK_NONE;
    }
    if (menuState != 0 && menuState != 9) {
        pendingMenuExit = true;
    }
}

void setup() {
    // 0. Ensure binary provenance metadata string is retained in Flash ROM (immune to linker --gc-sections)
    volatile const char* const volatile pBuildTag = g_firmware_build_tag;
    if (pBuildTag[0] != 'N') {
        while (1) { IWDG_FEED(); }
    }

    // 1. Lock all stepper & sensor pins into safe deterministic idle states at t = 0ms
    bm_pinMode(stepPin, OUTPUT);
    STEP_HIGH_IDLE();
    bm_pinMode(dirPin, OUTPUT);
    bm_pinMode(motorEnaPin, OUTPUT);
    bm_digitalWrite(motorEnaPin, LOW); // Stepper driver enabled by default

    pinMode(proxSensorPin, INPUT_PULLUP);

    // Initialize 3 primary buttons + 6-button + 4x4 matrix column pins with internal pull-up
    bm_pinMode(btnUp, INPUT_PULLUP);
    bm_pinMode(btnDown, INPUT_PULLUP);
    bm_pinMode(btnMode, INPUT_PULLUP);


    bm_pinMode(statusLedPin, OUTPUT);
    STATUS_LED_OFF();

#if defined(CoreDebug) && defined(DWT)
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
#endif

    // 2. Determine Cold Power-On vs Mid-Run Watchdog Reset BEFORE clearing reset flags:
    // On STM32F103, PORRSTF (bit 27) is set on every physical Power-On Reset.
    // Checking (PORRSTF == 0) guarantees a sticky IWDGRSTF flag never skips the power-on splash!
    #ifndef RCC_CSR_PORRSTF
    #define RCC_CSR_PORRSTF  (1U << 27)
    #endif
    #ifndef RCC_CSR_IWDGRSTF
    #define RCC_CSR_IWDGRSTF (1U << 29)
    #endif
    #ifndef RCC_CSR_RMVF
    #define RCC_CSR_RMVF     (1U << 24)
    #endif

    const uint32_t resetFlags = RCC->CSR;
    const bool isWatchdogReset = ((resetFlags & RCC_CSR_IWDGRSTF) != 0U) &&
                                 ((resetFlags & RCC_CSR_PORRSTF) == 0U);
    RCC->CSR |= RCC_CSR_RMVF;

    // 3. ZERO-BLINK, ZERO-BLANK-DELAY INSTANT BOOT DISPLAY (~60ms from Power-On!):
    // FastLiquidCrystal_I2C eliminates LiquidCrystal_I2C's 1000ms blank delay and keeps
    // Backlight bit (0x08) HIGH from t = 0ms so DEV: RAJESH SHAH / NIPON ZIPPER IND
    // appears immediately (~0.06s) on switch ON with zero blank screen and zero blink.
#ifndef HOST_SIMULATION_TEST
    bm_delay_ms(60);        // Allow +5V USB/buck rail on PCF8574 LCD backpack to reach >=4.5V on cold boot
    bm_i2c1_init(100000UL); // 100 kHz standard mode for rock-solid 5V PCF8574 communication
#endif
    lcd.backlight();
    lcd.init();
    lcd.createChar(1, kBellBitmap);
    lcd.backlight();
    isBacklightCurrentlyOn = true;
    lcd.setCursor(0, 0);
    lcd.print("NIPON ZIPPER IND");
    lcd.setCursor(0, 1);
    lcd.print("DEV: RAJESH SHAH");

    loadFromEEPROM();
    applyMotorDirection();
    STEP_HIGH_IDLE();

#if defined(TIM4) && (!defined(STM32F103x6) || defined(HOST_SIMULATION_TEST)) && defined(RCC_APB1ENR_TIM4EN)
    initFreeRunningTimer4();
#endif
    initHardwareTimer2(); // PA0 TIM2_CH1 hardware capture + PA8 TIM1_CH1 STEP engine
    validTriggerCount = 0UL;

    // Strict NVIC Priority Hierarchy:
    // Priority 0: TIM1_UP (PA8 STEP pulse generator - highest possible priority, zero pulse jitter)
    // Priority 1: TIM2_IRQn (PA0 Cam Proximity trigger - immediate hardware preemption)
    // Priority 3: SysTick_IRQn (Background Arduino timebase)
    NVIC_SetPriority(TIM1_UP_IRQn, 0);
    NVIC_SetPriority(SysTick_IRQn, 3);
    IWDG_INIT();

    if (!isWatchdogReset) {
        // Cold Power-On Boot: Mask PA0 capture IRQ during the 2.0s splash screen while the 24V
        // proximity sensor and optocoupler rail settle, preventing any startup transient burst.
        TIM2->DIER &= ~TIM_DIER_CC1IE;
        // Hold Splash Screen for exact 2.0 seconds (20 x 100ms) while TIM4/TIM2 warm up.
        // At 100ms and 300ms, silently re-sync 4-bit mode & text without clearing DDRAM
        // in case a slow external 5V capacitor bank took 100-250ms to reach 4.5V.
        for (int i = 0; i < 20; i++) {
            if (i == 1 || i == 3) {
#ifndef HOST_SIMULATION_TEST
                lcd.sync4BitModeNoClear();
#endif
                lcd.createChar(1, kBellBitmap);
                lcd.backlight();
                lcd.setCursor(0, 0);
                lcd.print("NIPON ZIPPER IND");
                lcd.setCursor(0, 1);
                lcd.print("DEV: RAJESH SHAH");
            }
            IWDG_FEED();
            bm_delay_ms(100);
        }
    } else {
        lcd.setCursor(0, 0);
        lcd.print("FAST-BOOT READY ");
        lcd.setCursor(0, 1);
        lcd.print("IWDG RECOVERED  ");
        bm_delay_ms(100);
    }

    // Switch I2C bus back to 400 kHz Fast-Mode for ultra-fast runtime display updates in loop()
#ifndef HOST_SIMULATION_TEST
    bm_i2c1_init(400000UL);
#endif

    // Clear any power-on settling spike or boot noise after the 2.0s splash so loop() starts 100% clean
    stopHardwareTimerImmediately();
    TIM2->SR &= ~(TIM_SR_CC1IF | TIM_SR_CC1OF);
    NVIC_ClearPendingIRQ(TIM2_IRQn);
    TIM2->DIER |= TIM_DIER_CC1IE;
    pulseFracAccumulator   = 0UL;
    movementState          = STATE_IDLE;
    lastTriggerMicros      = 0UL;
    lastMeasuredIntervalUs = 0UL;
    currentRPM             = 0UL;
    validTriggerCount      = 0UL;
    acceptedTriggerPulses  = 0UL;
    rejectedTriggerCount   = 0UL;
    motionWatchdogArmed    = false;
    isMotionSyncLost       = false;
    isTimingOverrun        = false;
    isTimingWarningActive  = false;
    resetRpmIntervalHistory();

    invalidateLcdShadow();
    oldMenuState           = -1;
    lastDisplayUpdate      = 0UL;
    lastUnlockActivity     = bm_millis();
    lastButtonPressTime    = bm_millis();
    lastMotionOrButtonTime = bm_millis();
    isUiLocked             = false;
}

static inline bool computeHasStagedChanges() {
    return (tempDriverRes != driverResolution) ||
           (fabsf(tempRollerDia - rollerDia) > 0.001f) ||
           (tempMaxRPM != maxRPMSetting) ||
           (tempFeedAngle != feedAngleDeg) ||
           (tempSafetyMargin != safetyMarginPercent) ||
           (tempMotorDir != motorDirection) ||
           (tempAutoLockSec != autoLockSec) ||
           (tempBacklightSec != backlightSec);
}

static inline void clampConfirmedSettingValue(int level, int opt) {
    if (level == 1) {
        if (opt == 1) {
            if (tempMaxRPM < 100)  tempMaxRPM = 100;
            if (tempMaxRPM > 4000) tempMaxRPM = 4000;
        } else if (opt == 3) {
            if (tempAutoLockSec > 0UL && tempAutoLockSec < 10UL) tempAutoLockSec = 10UL;
            if (tempAutoLockSec > 300UL) tempAutoLockSec = 300UL;
            if (tempAutoLockSec >= 10UL) lastEnabledAutoLockSec = tempAutoLockSec;
        } else if (opt == 4) {
            if (tempBacklightSec > 0 && tempBacklightSec < 10) tempBacklightSec = 10;
            if (tempBacklightSec > 300) tempBacklightSec = 300;
        }
    } else if (level == 2) {
        if (opt == 2) {
            if (tempRollerDia < 10.0f)  tempRollerDia = 10.0f;
            if (tempRollerDia > 100.0f) tempRollerDia = 100.0f;
        } else if (opt == 3) {
            if (tempFeedAngle < 30)  tempFeedAngle = 30;
            if (tempFeedAngle > 270) tempFeedAngle = 270;
        } else if (opt == 4) {
            if (tempSafetyMargin < 0)  tempSafetyMargin = 0;
            if (tempSafetyMargin > 29) tempSafetyMargin = 29;
        }
    }
    hasStagedChanges = computeHasStagedChanges();
}

static inline void clearSpeedDial() {
    isSpeedDialActive = false;
    speedDialLen = 0;
    speedDialHasDot = false;
    speedDialDecCount = 0;
}

void loop() {
    IWDG_FEED();

    // =========================================================================
    // INTERACTIVE STEPPER JOG BENCH TEST (Diagnostics Page 2)
    // =========================================================================
    if (menuState == 9 && infoIndex == 2 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        static uint32_t lastJogUs = 0;
        uint32_t nowJog = bm_micros();
        bool jogFwd = (bm_digitalRead(btnUp) == LOW);
        bool jogRev = (bm_digitalRead(btnDown) == LOW);
        if (jogFwd) {
            DIR_NORMAL();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                bm_delay_us(5);
                STEP_HIGH_IDLE();
            }
        } else if (jogRev) {
            DIR_REVERSE();
            if ((uint32_t)(nowJog - lastJogUs) >= 800) {
                lastJogUs = nowJog;
                STEP_LOW_ACTIVE();
                bm_delay_us(5);
                STEP_HIGH_IDLE();
            }
        } else {
            applyMotorDirection();
        }
    }

    // =========================================================================
    // INTERACTIVE OPTOCOUPLER SINKING BENCH TEST (Diagnostics Page 3)
    // =========================================================================
    if (menuState == 9 && infoIndex == 3 && currentRPM == 0UL && !hwBurstActive && stepsRemaining == 0) {
        bool sinkTestActive = (bm_digitalRead(btnUp) == LOW);
        if (sinkTestActive) {
            STEP_LOW_ACTIVE();
            stepPinState = LOW;
        } else {
            STEP_HIGH_IDLE();
            stepPinState = HIGH;
        }
    }



    if (!hwBurstActive && stepsRemaining == 0) {
        if (movementState == STATE_COMPLETE || movementState == STATE_ABORTED) {
            movementState = STATE_IDLE;
        }
    }

    const bool isMachineRunning = (currentRPM > 0UL) || hwBurstActive ||
                                  (lastTriggerMicros != 0UL && ((uint32_t)(get_hardware_timestamp_us() - (uint32_t)lastTriggerMicros) < 2000000UL));
    if (!isMachineRunning) {
        if (bm_digitalRead(proxSensorPin) == LOW) {
            STATUS_LED_ON();
        } else {
            STATUS_LED_OFF();
        }
    }

    static uint32_t lastSeenAcceptedTriggerCount = 0;
    static uint32_t lastTriggerActivityMs = 0;
    static bool     proactiveStopInvalidated = true;
    const uint32_t currentAcceptedTriggers = acceptedTriggerPulses;
    if (currentAcceptedTriggers != lastSeenAcceptedTriggerCount) {
        lastSeenAcceptedTriggerCount = currentAcceptedTriggers;
        lastTriggerActivityMs = bm_millis();
        proactiveStopInvalidated = false;
    }

    const uint32_t nowUsLoop = get_hardware_timestamp_us();
    const uint32_t sinceLastTriggerUs = (lastTriggerTimerUs != 0UL)
        ? (uint32_t)(nowUsLoop - lastTriggerTimerUs) : 0UL;

    if (!proactiveStopInvalidated && !hwBurstActive && stepsRemaining == 0 &&
        ((lastTriggerTimerUs != 0UL && sinceLastTriggerUs > 400000UL) ||
         (bm_millis() - lastTriggerActivityMs > 400UL))) {
        uint32_t primask = __get_PRIMASK();
        __disable_irq();
        const uint32_t recheckNowUs = get_hardware_timestamp_us();
        const uint32_t recheckSinceTriggerUs = (lastTriggerTimerUs != 0UL)
            ? (uint32_t)(recheckNowUs - lastTriggerTimerUs) : 0UL;
        if (!hwBurstActive && stepsRemaining == 0 &&
            (recheckSinceTriggerUs > 400000UL || (bm_millis() - lastTriggerActivityMs > 400UL))) {
            pulseFracAccumulator = 0UL;
            hwBurstPeriodFrac    = 0UL;
            proactiveStopInvalidated = true;
        }
        __set_PRIMASK(primask);
    }

    if (bm_millis() - lastTriggerActivityMs > 2000UL) {
        if (currentRPM > 0UL) {
            currentRPM = 0UL;
            lastMeasuredIntervalUs = 0UL;
            pulseFracAccumulator = 0UL;
            hwBurstPeriodFrac = 0UL;
            motionWatchdogArmed = false;
            isMotionSyncLost = false;
            resetRpmIntervalHistory();
        }
        if (hwBurstActive && (TIM1->CR1 & TIM_CR1_CEN) == 0U) {
            hwBurstActive = false;
            stepsRemaining = 0;
            movementState = STATE_IDLE;
        }
    }

    const bool isAnyDirty = (p5_fixed != pulseStepStored_p5) ||
                            (p8_fixed != pulseStepStored_p8) ||
                            (p10_fixed != pulseStepStored_p10);
    pulseModifiedByUser = isAnyDirty;
    const bool isRpmFresh = (lastTriggerActivityMs != 0UL) && ((currentRPM > 0UL) || (bm_millis() - lastTriggerActivityMs < 2000UL));
    autoSaveEngine.update(currentRPM, 300UL, isRpmFresh, false, false, (currentRPM == 0UL), isAnyDirty, bm_millis());
    autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

    if (currentRPM == 0UL && menuState == 0) {
        if (autoSaveEngine.autoSavePendingStandstill && isMachineSafelyIdle()) {
            if (isAnyDirty) {
                bool saveOk = saveToEEPROM();
                if (saveOk) {
                    uiBannerLine1 = "AUTO-SAVED OK!  ";
                    uiBannerLine2 = "SETTINGS SAVED  ";
                    autoSaveEngine.clearPendingSave();
                    autoSavePendingStandstill = false;
                } else {
                    uiBannerLine1 = "SAVE FAILED!    ";
                    uiBannerLine2 = "RETRY AT IDLE   ";
                }
                uiMessageTimer = bm_millis() + 1500UL;
                oldMenuState = -1;
            } else {
                autoSaveEngine.clearPendingSave();
                autoSavePendingStandstill = false;
            }
        }
    }

    // Real Motion Sync Watchdog: Armed ONLY at >= 150 RPM (100% muted below 150 RPM for handwheel testing!)
    if (motionWatchdogArmed && currentRPM >= 150UL && lastMeasuredIntervalUs > 0UL) {
        uint32_t nowUs = get_hardware_timestamp_us();
        uint32_t elapsedUs = (uint32_t)(nowUs - (uint32_t)lastTriggerMicros);
        uint32_t timeoutLimitUs = ((uint32_t)lastMeasuredIntervalUs * 5UL) / 2UL; // 2.5x expected interval
        if (timeoutLimitUs < 50000UL) timeoutLimitUs = 50000UL; // 50ms floor
        if (elapsedUs > timeoutLimitUs && elapsedUs <= 2000000UL) {
            if (!isMotionSyncLost) {
                isMotionSyncLost = true;
                faultType = 3; // Trigger Sync Lost
            }
        }
    }

    if (isTimingOverrun) {
        isTimingOverrun = false;
        uiBannerLine1 = "ERR: TIMING OVRN";
        uiBannerLine2 = "BURST OVERRUN!  ";
        uiMessageTimer = bm_millis() + 1500UL;
        oldMenuState = -1;
    }

    if (pendingMenuExit || (currentRPM > 0UL && isSpeedDialActive)) {
        pendingMenuExit = false;
        clearSpeedDial();
        isEditingSetting = false;
        menuState = 0;
        oldMenuState = -1;
        hasStagedChanges = false;
    }

    if (autoLockSec == 0UL) {
        isUiLocked = false;
    } else if (!isUiLocked && menuState == 0) {
        if (bm_millis() - lastUnlockActivity > (autoLockSec * 1000UL)) {
            isUiLocked = true;
            isEditingMainDecimal = false;
            clearSpeedDial();
            blinkTarget = BLINK_NONE;
        }
    }

    if (menuState != 0) {
        if (bm_millis() - lastUnlockActivity > 120000UL) {
            hasStagedChanges = false;
            isEditingSetting = false;
            menuState = 0;
            oldMenuState = -1;
            lastUnlockActivity = bm_millis();
            isUiLocked = false;
        }
    }

    if (backlightSec > 0) {
        bool wantBacklight = (backlightSec <= 300) &&
                             (bm_millis() - lastButtonPressTime < ((unsigned long)backlightSec * 1000UL));
        if (wantBacklight != isBacklightCurrentlyOn && !hwBurstActive) {
            isBacklightCurrentlyOn = wantBacklight;
            if (wantBacklight) lcd.backlight();
            else               lcd.noBacklight();
        }
    } else if (!isBacklightCurrentlyOn && !hwBurstActive) {
        isBacklightCurrentlyOn = true;
        lcd.backlight();
    }

    MOTOR_ENA_ACTIVE();

    static bool upPressedState = false;
    static unsigned long upFirstPressTime = 0UL;
    static unsigned long lastUpRepeatTime = 0UL;

    static bool downPressedState = false;
    static unsigned long downFirstPressTime = 0UL;
    static unsigned long lastDownRepeatTime = 0UL;

    if (bm_millis() - lastButtonCheck > 20UL) {
        lastButtonCheck = bm_millis();

        bool upPinLow   = (bm_digitalRead(btnUp) == LOW);
        bool downPinLow = (bm_digitalRead(btnDown) == LOW);
        bool modePinLow = (bm_digitalRead(btnMode) == LOW);
        const bool anyKeyActive = upPinLow || downPinLow || modePinLow;

        // =====================================================================
        // BACKLIGHT WAKE-UP SHIELD
        // =====================================================================
        if (anyKeyActive) {
            const bool wasScreenOff = (!isBacklightCurrentlyOn && backlightSec != 999);
            lastUnlockActivity = bm_millis();
            lastButtonPressTime = bm_millis();
            if (!isBacklightCurrentlyOn && backlightSec != 999 && !hwBurstActive) {
                lcd.backlight();
                isBacklightCurrentlyOn = true;
            }
            if (wasScreenOff) {
                wakeShieldConsumingPress = true;
            }
        } else {
            wakeShieldConsumingPress = false;
        }

        if (wakeShieldConsumingPress) {
            upPinLow   = false;
            downPinLow = false;
            modePinLow = false;
        }

        if (pendingSingleClick && (bm_millis() - lastModeClickTime > 350UL)) {
            pendingSingleClick = false;
            if (isUiLocked && menuState == 0) {
                unlockPendingDown = true;
                unlockPromptUntil = bm_millis() + 3000UL;
                uiBannerLine1 = "UNLOCK KEYPAD:  ";
                uiBannerLine2 = "PRESS [DOWN] NOW";
                uiMessageTimer = bm_millis() + 3000UL;
                oldMenuState = -1;
            } else if (!isUiLocked && menuState == 0) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    if (!isEditingMainDecimal) {
                        setMainEditCursorAndBlink(0);
                    } else {
                        isEditingMainDecimal = false;
                        blinkTarget          = BLINK_NONE;
                    }
                    lastUnlockActivity = bm_millis();
                    oldMenuState = -1;
                }
            }
        }

        if (pendingMenuSingleClick && (bm_millis() - lastMenuModeClickTime > 350UL)) {
            pendingMenuSingleClick = false;
            if (menuState == 1 && !isEditingSetting) {
                if (hiddenOption >= 1 && hiddenOption <= 4) {
                    isEditingSetting = true;
                    settingDigitCursor = 0;
                    lastUnlockActivity = bm_millis();
                } else if (hiddenOption == 5) {
                    evaluateDiagnostics();
                    infoIndex = 1;
                    menuState = 9;
                    oldMenuState = -1;
                } else if (hiddenOption == 6) {
                    advanceOption = 1;
                    isEditingSetting = false;
                    menuState = 2;
                    oldMenuState = -1;
                } else if (hiddenOption == 7) {
                    saveExitChoice = true;
                    menuState = 13;
                    oldMenuState = -1;
                }
            } else if (menuState == 2 && !isEditingSetting) {
                if (advanceOption >= 1 && advanceOption <= 4) {
                    isEditingSetting = true;
                    settingDigitCursor = 0;
                    lastUnlockActivity = bm_millis();
                } else if (advanceOption == 5) {
                    menuState = 1;
                    hiddenOption = 6;
                    oldMenuState = -1;
                }
            }
        }

        if (upPinLow && downPinLow) {
            if (!upDownPressed) dualPressTime = bm_millis();
            upDownPressed = true;
            if (bm_millis() - dualPressTime > 10000UL && menuState != 3) {
                if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                    menuState = 3;
                    resetChoice = false;
                    oldMenuState = -1;
                }
            }
        } else {
            upDownPressed = false;
        }

        static bool modeHoldSettingsTriggered = false;
        if (modePinLow) {
            if (!modePressed) {
                modePressTime = bm_millis();
                modeHoldSettingsTriggered = false;
                if (isUiLocked && menuState == 0) {
                    unlockPendingDown = true;
                    unlockPromptUntil = bm_millis() + 3000UL;
                    uiBannerLine1 = "UNLOCK KEYPAD:  ";
                    uiBannerLine2 = "PRESS [DOWN] NOW";
                    uiMessageTimer = bm_millis() + 3000UL;
                    oldMenuState = -1;
                }
            }
            modePressed = true;

            unsigned long modeHoldMs = bm_millis() - modePressTime;
            if (!isUiLocked && menuState == 0 && currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                if (modeHoldMs >= 1000UL && modeHoldMs < 5000UL) {
                    pendingSingleClick = false;
                    isEditingMainDecimal = false;
                    clearSpeedDial();
                    blinkTarget = BLINK_NONE;
                    int secLeft = (int)((5000UL - modeHoldMs + 999UL) / 1000UL);
                    static char modeHoldCount[32];
                    memcpy(modeHoldCount, "IN   SEC...      ", 17);
                    modeHoldCount[3] = '0' + (char)secLeft;
                    uiBannerLine1 = "ENTER SETTINGS: ";
                    uiBannerLine2 = modeHoldCount;
                    uiMessageTimer = bm_millis() + 250UL;
                } else if (modeHoldMs >= 5000UL && !modeHoldSettingsTriggered) {
                    modeHoldSettingsTriggered = true;
                    pendingSingleClick  = false;
                    pendingMenuSingleClick = false;
                    isEditingMainDecimal = false;
                    clearSpeedDial();
                    blinkTarget         = BLINK_NONE;
                    uiBannerLine1       = nullptr;
                    uiBannerLine2       = nullptr;
                    tempDriverRes       = driverResolution;
                    tempRollerDia       = rollerDia;
                    tempMaxRPM          = maxRPMSetting;
                    tempFeedAngle       = feedAngleDeg;
                    tempSafetyMargin    = safetyMarginPercent;
                    tempMotorDir        = motorDirection;
                    tempKeypad6Btn      = keypad6ButtonMode;
                    tempAutoLockSec     = autoLockSec;
                    tempBacklightSec    = backlightSec;
                    tempMotorSleepMin   = motorSleepMin;
                    hasStagedChanges    = false;
                    isEditingSetting    = false;
                    menuState           = 1;
                    hiddenOption        = 1;
                    advanceOption       = 1;
                    oldMenuState        = -1;
                    lastUnlockActivity  = bm_millis();
                    isUiLocked          = false;
                }
            }
        } else if (modePressed) {
            unsigned long holdTime = bm_millis() - modePressTime;
            modePressed = false;

            if (modeHoldSettingsTriggered) {
                modeHoldSettingsTriggered = false;
            } else if (menuState == 0) {
                if (uiBannerLine1 != nullptr && strncmp(uiBannerLine1, "ENTER SETTINGS", 14) == 0) {
                    uiBannerLine1 = nullptr;
                    uiBannerLine2 = nullptr;
                    oldMenuState = -1;
                }
                if (isUiLocked) {
                    unlockPendingDown = true;
                    unlockPromptUntil = bm_millis() + 3000UL;
                    pendingSingleClick = false;
                } else if (holdTime < 350UL) {
                    if (pendingSingleClick && (bm_millis() - lastModeClickTime < 350UL)) {
                        pendingSingleClick = false;
                        lastModeClickTime = 0UL;
                        if (!isUiLocked && currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            isEditingMainDecimal = false;
                            clearSpeedDial();
                            currentSize++;
                            if (currentSize > 3) currentSize = 1;
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentSize == 1) currentPulsesFixed = p5_fixed;
                            else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                            else currentPulsesFixed = p10_fixed;
                            pulseFracAccumulator = 0UL;
                            __set_PRIMASK(primask);
                            updateActivePulseWidth();
                            bool saveOk = saveToEEPROM();
                            if (!saveOk) {
                                autoSavePendingStandstill = true;
                            }
                            lastUnlockActivity = bm_millis();
                            blinkTarget  = BLINK_MAIN_SIZE;
                            blinkUntilMs = bm_millis() + 2000UL;
                            oldMenuState = -1;
                            checkAndShowSizeLimitNotice(currentSize);
                        }
                    } else {
                        lastModeClickTime = bm_millis();
                        if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                            pendingSingleClick = true;
                        } else {
                            pendingSingleClick = false;
                        }
                    }
                }
            } else if (menuState == 1) {
                if (isEditingSetting) {
                    clampConfirmedSettingValue(1, hiddenOption);
                    isEditingSetting = false;
                    lastUnlockActivity = bm_millis();
                } else if (holdTime < 350UL) {
                    if (pendingMenuSingleClick && (bm_millis() - lastMenuModeClickTime < 350UL)) {
                        pendingMenuSingleClick = false;
                        lastMenuModeClickTime = 0UL;
                        if (hasStagedChanges) {
                            saveExitChoice = true;
                            menuState = 13;
                            oldMenuState = -1;
                        } else {
                            menuState = 0;
                            oldMenuState = -1;
                            lastUnlockActivity = bm_millis();
                            isUiLocked = false;
                        }
                        return;
                    } else {
                        lastMenuModeClickTime = bm_millis();
                        pendingMenuSingleClick = true;
                    }
                }
            } else if (menuState == 2) {
                if (isEditingSetting) {
                    clampConfirmedSettingValue(2, advanceOption);
                    isEditingSetting = false;
                    lastUnlockActivity = bm_millis();
                } else if (holdTime < 350UL) {
                    if (pendingMenuSingleClick && (bm_millis() - lastMenuModeClickTime < 350UL)) {
                        pendingMenuSingleClick = false;
                        lastMenuModeClickTime = 0UL;
                        menuState = 1;
                        hiddenOption = 6;
                        oldMenuState = -1;
                        return;
                    } else {
                        lastMenuModeClickTime = bm_millis();
                        pendingMenuSingleClick = true;
                    }
                }
            } else if (menuState == 9) {
                if (holdTime >= 800UL) {
                    menuState = 1;
                    oldMenuState = -1;
                } else if (infoIndex == 2) {
                    infoIndex = 3;
                } else {
                    menuState = 1;
                    oldMenuState = -1;
                }
            } else if (menuState == 13) {
                if (saveExitChoice) {
                    for (int opt = 1; opt <= 4; opt++) clampConfirmedSettingValue(1, opt);
                    for (int opt = 1; opt <= 4; opt++) clampConfirmedSettingValue(2, opt);
                    const bool geometryChanged = (driverResolution != tempDriverRes) ||
                                                 (fabsf(rollerDia - tempRollerDia) > 0.001f);
                    const bool dirChanged      = (motorDirection != tempMotorDir);
                    if (driverResolution != tempDriverRes)         driverResolution    = tempDriverRes;
                    if (fabsf(rollerDia - tempRollerDia) > 0.001f) rollerDia           = tempRollerDia;
                    if (maxRPMSetting != tempMaxRPM)               maxRPMSetting       = tempMaxRPM;
                    if (feedAngleDeg != tempFeedAngle)             feedAngleDeg        = tempFeedAngle;
                    if (safetyMarginPercent != tempSafetyMargin)   safetyMarginPercent = tempSafetyMargin;
                    if (motorDirection != tempMotorDir)            motorDirection      = tempMotorDir;
                    if (keypad6ButtonMode != tempKeypad6Btn)       keypad6ButtonMode   = tempKeypad6Btn;
                    if (autoLockSec != tempAutoLockSec)            autoLockSec         = tempAutoLockSec;
                    if (backlightSec != tempBacklightSec)          backlightSec        = tempBacklightSec;
                    if (motorSleepMin != tempMotorSleepMin)        motorSleepMin       = tempMotorSleepMin;
                    if (dirChanged) applyMotorDirection();
                    if (geometryChanged) {
                        recalculatePitchProfiles();
                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        if (currentSize == 1) currentPulsesFixed = p5_fixed;
                        else if (currentSize == 2) currentPulsesFixed = p8_fixed;
                        else currentPulsesFixed = p10_fixed;
                        __set_PRIMASK(primask);
                    }
                    calculateAllPulseWidths();
                    refreshPulseTimingValidity();
                    hasStagedChanges = false;
                    isEditingSetting = false;
                    menuState = 0;
                    oldMenuState = -1;
                    lastUnlockActivity = bm_millis();
                    isUiLocked = false;
                    if (isMachineSafelyIdle() && currentRPM == 0UL) {
                        bool saveOk = saveToEEPROM();
                        if (saveOk) {
                            autoSavePendingStandstill = false;
                            autoSaveEngine.clearPendingSave();
                            pulseModifiedByUser = false;
                            hasStagedChanges = false;
                            if (!checkAndShowAllSizesSettingsLimitNotice()) {
                                uiBannerLine1 = "SETTINGS SAVED  ";
                                uiBannerLine2 = "DIRECT SAVE OK  ";
                                uiMessageTimer = bm_millis() + 1500UL;
                            }
                        } else {
                            uiBannerLine1 = "SAVE FAILED!    ";
                            uiBannerLine2 = "RETRY AT 0 RPM  ";
                            uiMessageTimer = bm_millis() + 1500UL;
                        }
                    } else {
                        uiBannerLine1 = "SAVE BLOCKED!   ";
                        uiBannerLine2 = "STOP MACHINE 1ST";
                        uiMessageTimer = bm_millis() + 1500UL;
                    }
                } else {
                    tempDriverRes     = driverResolution;
                    tempRollerDia     = rollerDia;
                    tempMaxRPM        = maxRPMSetting;
                    tempFeedAngle     = feedAngleDeg;
                    tempSafetyMargin  = safetyMarginPercent;
                    tempMotorDir      = motorDirection;
                    tempKeypad6Btn    = keypad6ButtonMode;
                    tempAutoLockSec   = autoLockSec;
                    tempBacklightSec  = backlightSec;
                    tempMotorSleepMin = motorSleepMin;
                    hasStagedChanges  = false;
                    isEditingSetting  = false;
                    menuState         = 0;
                    oldMenuState      = -1;
                    lastUnlockActivity = bm_millis();
                    isUiLocked        = false;
                }
            } else if (menuState == 3) {
                if (resetChoice) {
                    loadFactoryDefaults();
                    saveToEEPROM();
                    uiBannerLine1 = "FACTORY RESET OK";
                    uiBannerLine2 = "DEFAULTS LOADED ";
                    uiMessageTimer = bm_millis() + 1500UL;
                }
                menuState = 0;
                oldMenuState = -1;
            }
        }

        bool upRaw = upPinLow;
        bool triggerUpStep = false;
        if (upRaw && !upDownPressed) {
            if (!upPressedState) {
                upPressedState = true;
                upFirstPressTime = bm_millis();
                lastUpRepeatTime = bm_millis();
                triggerUpStep = true;
            } else if (bm_millis() - upFirstPressTime >= 600UL) {
                if (bm_millis() - lastUpRepeatTime >= 200UL) {
                    lastUpRepeatTime = bm_millis();
                    triggerUpStep = true;
                }
            }
        } else {
            upPressedState = false;
        }

        if (triggerUpStep) {
            lastUnlockActivity = bm_millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        unlockPendingDown = false;
                        uiBannerLine1 = "** KEYPAD LOCKED **";
                        uiBannerLine2 = "PRESS MODE+DOWN ";
                        uiMessageTimer = bm_millis() + 1500UL;
                        oldMenuState = -1;
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        clearSpeedDial();
                        uint64_t proposedPulses = currentPulsesFixed;
                        if (!isEditingMainDecimal) {
                            proposedPulses = currentPulsesFixed + 1000000ULL;
                            if (proposedPulses > PULSE_STEP_MAX_FIXED) proposedPulses = PULSE_STEP_MAX_FIXED;
                            blinkTarget = BLINK_MAIN_GEAR_INT;
                        } else {
                            int pInt  = (int)(currentPulsesFixed / 1000000ULL);
                            int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                            int th = pInt / 1000;
                            int h  = (pInt / 100) % 10;
                            int t  = (pInt / 10) % 10;
                            int u  = pInt % 10;
                            if (mainEditCursor == 0) {
                                pFrac = (pFrac + 1) % 10;
                                blinkTarget = BLINK_MAIN_GEAR_DEC;
                            } else if (mainEditCursor == 1) {
                                u = (u + 1) % 10;
                                blinkTarget = BLINK_MAIN_UNITS;
                            } else if (mainEditCursor == 2) {
                                t = (t + 1) % 10;
                                blinkTarget = BLINK_MAIN_TENS;
                            } else {
                                if (th == 0) {
                                    h = (h >= 5) ? 0 : (h + 1);
                                } else {
                                    h = (h + 1) % 10;
                                }
                                blinkTarget = BLINK_MAIN_HUNDREDS;
                            }
                            int newInt = th * 1000 + h * 100 + t * 10 + u;
                            if (newInt < 1) newInt = 1;
                            proposedPulses = (uint64_t)newInt * 1000000ULL + (uint64_t)pFrac * 100000ULL;
                            if (proposedPulses > PULSE_STEP_MAX_FIXED) proposedPulses = PULSE_STEP_MAX_FIXED;
                            lastEditKeyPressMs = bm_millis();
                        }

                        uint32_t primask = __get_PRIMASK();
                        __disable_irq();
                        currentPulsesFixed = proposedPulses;
                        if (currentSize == 1) p5_fixed = currentPulsesFixed;
                        else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                        else p10_fixed = currentPulsesFixed;
                        __set_PRIMASK(primask);

                        updateActivePulseWidth();
                        checkAndShowPulseOutOfRangeNotice(currentPulsesFixed);
                        pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                              (p8_fixed != pulseStepStored_p8) ||
                                              (p10_fixed != pulseStepStored_p10);
                        if (pulseModifiedByUser) {
                            autoSaveEngine.notifyModification(bm_millis());
                        } else {
                            autoSaveEngine.clearPendingSave();
                        }
                        autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                        blinkUntilMs = bm_millis() + (isEditingMainDecimal ? MAIN_INLINE_EDIT_TIMEOUT_MS : 2000UL);
                        lastUnlockActivity = bm_millis();
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption--;
                        if (hiddenOption < 1) hiddenOption = 7;
                    } else {
                        if (hiddenOption == 1) {
                            int th = (tempMaxRPM / 1000) % 10;
                            int hd = (tempMaxRPM / 100) % 10;
                            int tn = (tempMaxRPM / 10) % 10;
                            int un = tempMaxRPM % 10;
                            if (settingDigitCursor == 0)      th = (th >= 4) ? 0 : (th + 1);
                            else if (settingDigitCursor == 1) hd = (hd + 1) % 10;
                            else if (settingDigitCursor == 2) tn = (tn + 1) % 10;
                            else                              un = (un + 1) % 10;
                            tempMaxRPM = th * 1000 + hd * 100 + tn * 10 + un;
                            if (tempMaxRPM > 4000) tempMaxRPM = 4000;
                        } else if (hiddenOption == 2) {
                            tempMotorDir = !tempMotorDir;
                        } else if (hiddenOption == 3) {
                            if (settingDigitCursor == 0) {
                                if (tempAutoLockSec > 0UL) {
                                    if (tempAutoLockSec >= 10UL && tempAutoLockSec <= 300UL) {
                                        lastEnabledAutoLockSec = tempAutoLockSec;
                                    }
                                    tempAutoLockSec = 0UL;
                                } else {
                                    tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL)
                                                      ? lastEnabledAutoLockSec : 30UL;
                                }
                            } else {
                                int h = (int)(tempAutoLockSec / 100UL) % 10;
                                int t = (int)(tempAutoLockSec / 10UL) % 10;
                                int u = (int)(tempAutoLockSec % 10UL);
                                if (settingDigitCursor == 1)      h = (h >= 3) ? 0 : (h + 1);
                                else if (settingDigitCursor == 2) t = (t + 1) % 10;
                                else                              u = (u + 1) % 10;
                                tempAutoLockSec = (uint32_t)(h * 100 + t * 10 + u);
                                if (tempAutoLockSec > 300UL) tempAutoLockSec = 300UL;
                                if (tempAutoLockSec >= 10UL) lastEnabledAutoLockSec = tempAutoLockSec;
                            }
                        } else if (hiddenOption == 4) {
                            int h = (tempBacklightSec / 100) % 10;
                            int t = (tempBacklightSec / 10) % 10;
                            int u = tempBacklightSec % 10;
                            if (settingDigitCursor == 0)      h = (h >= 3) ? 0 : (h + 1);
                            else if (settingDigitCursor == 1) t = (t + 1) % 10;
                            else                              u = (u + 1) % 10;
                            tempBacklightSec = h * 100 + t * 10 + u;
                            if (tempBacklightSec > 300) tempBacklightSec = 300;
                        }
                        hasStagedChanges = computeHasStagedChanges();
                        lastEditKeyPressMs = bm_millis();
                    }
                    break;

                case 2:
                    if (!isEditingSetting) {
                        advanceOption--;
                        if (advanceOption < 1) advanceOption = 5;
                    } else {
                        if (advanceOption == 1) {
                            int idx = getDriverResIndex(tempDriverRes);
                            if (idx < (int)DRIVER_RES_TABLE_SIZE - 1) idx++;
                            else idx = 0;
                            tempDriverRes = DRIVER_RES_TABLE[idx];
                        } else if (advanceOption == 2) {
                            int dTenths = (int)(tempRollerDia * 10.0f + 0.5f);
                            int h = (dTenths / 1000) % 10;
                            int t = (dTenths / 100) % 10;
                            int u = (dTenths / 10) % 10;
                            int d = dTenths % 10;
                            if (settingDigitCursor == 0)      d = (d + 1) % 10;
                            else if (settingDigitCursor == 1) u = (u + 1) % 10;
                            else if (settingDigitCursor == 2) t = (t + 1) % 10;
                            else                              h = (h >= 1) ? 0 : 1;
                            int newTenths = h * 1000 + t * 100 + u * 10 + d;
                            if (newTenths > 1000) newTenths = 1000;
                            tempRollerDia = (float)newTenths / 10.0f;
                        } else if (advanceOption == 3) {
                            int h = (tempFeedAngle / 100) % 10;
                            int t = (tempFeedAngle / 10) % 10;
                            int u = tempFeedAngle % 10;
                            if (settingDigitCursor == 0)      h = (h >= 2) ? 0 : (h + 1);
                            else if (settingDigitCursor == 1) t = (t + 1) % 10;
                            else                              u = (u + 1) % 10;
                            tempFeedAngle = h * 100 + t * 10 + u;
                            if (tempFeedAngle > 270) tempFeedAngle = 270;
                        } else if (advanceOption == 4) {
                            int t = (tempSafetyMargin / 10) % 10;
                            int u = tempSafetyMargin % 10;
                            if (settingDigitCursor == 0) t = (t >= 2) ? 0 : (t + 1);
                            else                         u = (u + 1) % 10;
                            tempSafetyMargin = t * 10 + u;
                            if (tempSafetyMargin > 29) tempSafetyMargin = 29;
                        }
                        hasStagedChanges = computeHasStagedChanges();
                        lastEditKeyPressMs = bm_millis();
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 9:
                    if (infoIndex != 2 && infoIndex != 3) {
                        infoIndex--;
                        if (infoIndex < 1) infoIndex = 5;
                    }
                    break;
            }
        }

        bool downRaw = downPinLow;
        bool triggerDownStep = false;
        if (downRaw && !upDownPressed) {
            if (!downPressedState) {
                downPressedState = true;
                downFirstPressTime = bm_millis();
                lastDownRepeatTime = bm_millis();
                triggerDownStep = true;
            } else if (bm_millis() - downFirstPressTime >= 600UL) {
                if (bm_millis() - lastDownRepeatTime >= 200UL) {
                    lastDownRepeatTime = bm_millis();
                    triggerDownStep = true;
                }
            }
        } else {
            downPressedState = false;
        }

        if (triggerDownStep) {
            lastUnlockActivity = bm_millis();
            switch (menuState) {
                case 0:
                    if (isUiLocked) {
                        if (unlockPendingDown && bm_millis() <= unlockPromptUntil) {
                            isUiLocked = false;
                            unlockPendingDown = false;
                            lastUnlockActivity = bm_millis();
                            uiBannerLine1 = "** UNLOCKED **  ";
                            uiBannerLine2 = "READY TO OPERATE";
                            uiMessageTimer = bm_millis() + 1200UL;
                            oldMenuState = -1;
                        } else {
                            unlockPendingDown = false;
                            uiBannerLine1 = "** KEYPAD LOCKED **";
                            uiBannerLine2 = "PRESS MODE+DOWN ";
                            uiMessageTimer = bm_millis() + 1500UL;
                            oldMenuState = -1;
                        }
                    } else if (currentRPM == 0UL && stepsRemaining == 0 && !hwBurstActive) {
                        clearSpeedDial();
                        if (isEditingMainDecimal) {
                            setMainEditCursorAndBlink((uint8_t)((mainEditCursor + 1U) % 4U));
                            lastUnlockActivity = bm_millis();
                        } else {
                            uint32_t primask = __get_PRIMASK();
                            __disable_irq();
                            if (currentPulsesFixed >= 1000000ULL + PULSE_STEP_MIN_FIXED) {
                                currentPulsesFixed -= 1000000ULL;
                            } else {
                                currentPulsesFixed = PULSE_STEP_MIN_FIXED + (currentPulsesFixed % 1000000ULL);
                            }
                            if (currentSize == 1) p5_fixed = currentPulsesFixed;
                            else if (currentSize == 2) p8_fixed = currentPulsesFixed;
                            else p10_fixed = currentPulsesFixed;
                            __set_PRIMASK(primask);

                            updateActivePulseWidth();
                            checkAndShowPulseOutOfRangeNotice(currentPulsesFixed);
                            pulseModifiedByUser = (p5_fixed != pulseStepStored_p5) ||
                                                  (p8_fixed != pulseStepStored_p8) ||
                                                  (p10_fixed != pulseStepStored_p10);
                            if (pulseModifiedByUser) {
                                autoSaveEngine.notifyModification(bm_millis());
                            } else {
                                autoSaveEngine.clearPendingSave();
                            }
                            autoSavePendingStandstill = autoSaveEngine.autoSavePendingStandstill;

                            blinkTarget  = BLINK_MAIN_GEAR_INT;
                            blinkUntilMs = bm_millis() + 2000UL;
                            lastUnlockActivity = bm_millis();
                        }
                    }
                    break;

                case 1:
                    if (!isEditingSetting) {
                        hiddenOption++;
                        if (hiddenOption > 7) hiddenOption = 1;
                    } else {
                        if (hiddenOption == 1) {
                            settingDigitCursor = (settingDigitCursor + 1) % 4;
                        } else if (hiddenOption == 2) {
                            tempMotorDir = !tempMotorDir;
                            hasStagedChanges = computeHasStagedChanges();
                        } else if (hiddenOption == 3) {
                            if (tempAutoLockSec == 0UL) {
                                tempAutoLockSec = (lastEnabledAutoLockSec >= 10UL && lastEnabledAutoLockSec <= 300UL)
                                                  ? lastEnabledAutoLockSec : 30UL;
                                settingDigitCursor = 1;
                                hasStagedChanges = computeHasStagedChanges();
                            } else {
                                settingDigitCursor = (settingDigitCursor + 1) % 4;
                            }
                        } else if (hiddenOption == 4) {
                            settingDigitCursor = (settingDigitCursor + 1) % 3;
                        }
                        lastEditKeyPressMs = bm_millis();
                    }
                    break;

                case 2:
                    if (!isEditingSetting) {
                        advanceOption++;
                        if (advanceOption > 5) advanceOption = 1;
                    } else {
                        if (advanceOption == 1) {
                            int idx = getDriverResIndex(tempDriverRes);
                            if (idx > 0) idx--;
                            else idx = (int)DRIVER_RES_TABLE_SIZE - 1;
                            tempDriverRes = DRIVER_RES_TABLE[idx];
                            hasStagedChanges = computeHasStagedChanges();
                        } else if (advanceOption == 2) {
                            settingDigitCursor = (settingDigitCursor + 1) % 4;
                        } else if (advanceOption == 3) {
                            settingDigitCursor = (settingDigitCursor + 1) % 3;
                        } else if (advanceOption == 4) {
                            settingDigitCursor = (settingDigitCursor == 0) ? 1 : 0;
                        }
                        lastEditKeyPressMs = bm_millis();
                    }
                    break;

                case 3:  resetChoice = !resetChoice; break;
                case 13: saveExitChoice = !saveExitChoice; break;
                case 9:
                    if (infoIndex != 2) {
                        infoIndex++;
                        if (infoIndex > 5) infoIndex = 1;
                    }
                    break;
            }
        }

        if (!upPinLow && !downPinLow) {
            upDownPressed = false;
        }
    }

    if (uiBannerLine1 != nullptr) {
        if (bm_millis() < uiMessageTimer) {
            lcdPrint16(0, uiBannerLine1);
            lcdPrint16(1, uiBannerLine2 ? uiBannerLine2 : "");
            oldMenuState = -2;
            return;
        } else {
            uiBannerLine1 = nullptr;
            uiBannerLine2 = nullptr;
            oldMenuState = -1;
            lcd.clear();
            invalidateLcdShadow();
        }
    }



    if (menuState == 0 && oldMenuState == menuState && !hwBurstActive) {
        if (bm_millis() - lastRpmDisplayUpdate > 250UL) {
            lastRpmDisplayUpdate = bm_millis();
            unsigned int dispRpm = (currentRPM > 9999UL) ? 9999U : (unsigned int)currentRPM;
            char rpmBuf[5] = {
                (char)('0' + (dispRpm / 1000U) % 10U),
                (char)('0' + (dispRpm / 100U) % 10U),
                (char)('0' + (dispRpm / 10U) % 10U),
                (char)('0' + (dispRpm % 10U)),
                '\0'
            };
            if (!s_lcdShadowValid[0] || memcmp(&s_lcdShadow[0][5], rpmBuf, 4) != 0) {
                lcd.setCursor(5, 0);
                lcd.print(rpmBuf);
                if (s_lcdShadowValid[0]) {
                    memcpy(&s_lcdShadow[0][5], rpmBuf, 4);
                }
            }
            char runBellChar = ' ';
            if (activePulseWidth <= 8 || pulseTimingInvalid) {
                runBellChar = (((bm_millis() / 500UL) % 2UL) == 0UL) ? LCD_BELL_CHAR : ' ';
            } else if (activePulseWidth == 9) {
                runBellChar = LCD_BELL_CHAR; // Steady ON at 9 us (Early Warning)
            }
            if (s_lcdShadowValid[1] && s_lcdShadow[1][12] != runBellChar) {
                char bcStr[2] = { runBellChar, '\0' };
                lcd.setCursor(12, 1);
                lcd.print(bcStr);
                s_lcdShadow[1][12] = runBellChar;
            }
            const char* runLockStr = isUiLocked ? "[L]" : "[U]";
            if (s_lcdShadowValid[1] && memcmp(&s_lcdShadow[1][13], runLockStr, 3) != 0) {
                lcd.setCursor(13, 1);
                lcd.print(runLockStr);
                memcpy(&s_lcdShadow[1][13], runLockStr, 3);
            }
        }
    }

    if (bm_millis() >= blinkUntilMs && (blinkTarget != BLINK_NONE || isEditingMainDecimal)) {
        blinkTarget = BLINK_NONE;
        isEditingMainDecimal = false;
    }
    const bool blinkHide = ((bm_millis() - lastEditKeyPressMs) >= 400UL) && ((bm_millis() % 750UL) >= 500UL);

    if ((currentRPM == 0UL || menuState != oldMenuState || menuState == 9) && bm_millis() - lastDisplayUpdate > 125UL) {
        if (menuState != oldMenuState) {
            lcd.clear();
            invalidateLcdShadow();
            oldMenuState = menuState;
        }

        char l1[48] = "                ";
        char l2[48] = "                ";
        switch (menuState) {
            case 0:
            {


                int szNum = (currentSize == 1) ? 5 : ((currentSize == 2) ? 8 : 10);
                const float feedMm = ((float)currentPulsesFixed / 1000000.0f) *
                    (3.14159265f * rollerDia) / (float)driverResolution;
                unsigned long feedHundredths = (feedMm > 0.0f) ? (unsigned long)(feedMm * 100.0f + 0.5f) : 0UL;
                if (feedHundredths > 9999UL) feedHundredths = 9999UL;
                unsigned int dispRpm = constrain((unsigned int)currentRPM, 0U, 9999U);
                memcpy(l1, "S:   0000 F:0.00 ", 17);
                if (blinkTarget != BLINK_MAIN_SIZE || !blinkHide) {
                    if (szNum < 10) {
                        l1[2] = '0' + (char)szNum;
                    } else {
                        l1[2] = '0' + (char)(szNum / 10);
                        l1[3] = '0' + (char)(szNum % 10);
                    }
                }
                formatUint(l1 + 5, dispRpm, 4, true);
                formatFixed2(l1 + 12, (uint32_t)feedHundredths, 1, false);

                char cue = ' ';
                if (activePulseWidth <= 8 || pulseTimingInvalid) {
                    cue = (((bm_millis() / 500UL) % 2UL) == 0UL) ? LCD_BELL_CHAR : ' ';
                } else if (activePulseWidth == 9) {
                    cue = LCD_BELL_CHAR; // Steady ON at 9 us (Early Warning)
                }

                int pInt = (int)(currentPulsesFixed / 1000000ULL);
                int pFrac = (int)((currentPulsesFixed % 1000000ULL) / 100000ULL);
                const char* lockStr = (blinkTarget == BLINK_MAIN_LOCK && blinkHide)
                    ? "   " : (isUiLocked ? "[L]" : "[U]");

                char pulseField[16];
                memset(pulseField, 0, sizeof(pulseField));
                if (pInt < 0) pInt = 0;
                const bool show4IntDigits = (pInt >= 1000);
                const bool show3IntDigits = !show4IntDigits && (isEditingMainDecimal || (pInt >= 100));
                if (show4IntDigits) {
                    formatUint(pulseField, (uint32_t)(pInt % 10000), 4, true);
                    pulseField[4] = '.';
                    pulseField[5] = '0' + (char)(pFrac % 10);
                    pulseField[6] = '\0';
                } else if (show3IntDigits) {
                    formatUint(pulseField, (uint32_t)(pInt % 1000), 3, true);
                    pulseField[3] = '.';
                    pulseField[4] = '0' + (char)(pFrac % 10);
                    pulseField[5] = '\0';
                } else {
                    formatUint(pulseField, (uint32_t)(pInt % 100), 2, true);
                    pulseField[2] = '.';
                    pulseField[3] = '0' + (char)(pFrac % 10);
                    pulseField[4] = '\0';
                }
                if (!show4IntDigits && !show3IntDigits && pInt < 10 && pulseField[0] == '0' && !isEditingMainDecimal) {
                    pulseField[0] = pulseField[1];
                    pulseField[1] = pulseField[2];
                    pulseField[2] = pulseField[3];
                    pulseField[3] = '\0';
                }
                int pfLen = (int)strlen(pulseField);
                if (blinkHide && pfLen >= 3) {
                    if (blinkTarget == BLINK_MAIN_PULSE) {
                        for (int k = 0; k < pfLen; k++) pulseField[k] = ' ';
                    } else if (blinkTarget == BLINK_MAIN_GEAR_INT) {
                        for (int k = 0; k < pfLen - 2; k++) pulseField[k] = ' ';
                    } else if (blinkTarget == BLINK_MAIN_GEAR_DEC) {
                        pulseField[pfLen - 1] = ' ';
                    } else if (blinkTarget == BLINK_MAIN_UNITS && pfLen >= 3) {
                        pulseField[pfLen - 3] = ' ';
                    } else if (blinkTarget == BLINK_MAIN_TENS && pfLen >= 4) {
                        pulseField[pfLen - 4] = ' ';
                    } else if (blinkTarget == BLINK_MAIN_HUNDREDS && pfLen >= 5) {
                        pulseField[pfLen - 5] = ' ';
                    }
                }

                memcpy(l2, "P:              ", 17);
                for (int k = 0; k < pfLen && (2 + k) < 16; ++k) l2[2 + k] = pulseField[k];
                int wPos = 2 + pfLen + 1;
                if (show4IntDigits) {
                    wPos = (activePulseWidth < 10) ? 9 : 8;
                } else if (show3IntDigits) {
                    wPos = 8;
                } else {
                    wPos = 7;
                }
                l2[wPos - 1] = ' ';
                l2[wPos] = 'W';
                l2[wPos + 1] = ':';
                char wBuf[4] = "  ";
                formatUint(wBuf, (uint32_t)activePulseWidth, 2, false);
                l2[wPos + 2] = wBuf[0];
                l2[wPos + 3] = wBuf[1];
                l2[12] = cue;
                l2[13] = lockStr[0];
                l2[14] = lockStr[1];
                l2[15] = lockStr[2];
                l2[16] = '\0';

                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
            }
            break;

            case 1: // Level 1: Main User Menu (7 Clean Options)
            {
                static const char* const kMenu1Titles[7] = {
                    "1. Max RPM      ", "2. Motor Dir    ", "3. Auto Lock    ",
                    "4. Backlight    ", "5. Diagnostics  ", "6. Advance Menu ", "7. Save & Exit  "
                };
                const char* m1Title = (hiddenOption >= 1 && hiddenOption <= 7) ? kMenu1Titles[hiddenOption - 1] : kMenu1Titles[0];
                const bool hideVal = isEditingSetting && blinkHide;

                if (hiddenOption == 1) {
                    memcpy(l2, "Val: 0000 RPM   ", 17);
                    formatUint(l2 + 5, (uint32_t)tempMaxRPM, 4, true);
                    if (hideVal && settingDigitCursor < 4) l2[5 + settingDigitCursor] = ' ';
                } else if (hiddenOption == 2) {
                    strcpy(l2, hideVal ? (tempMotorDir ? "Dir: REVERSE    " : "Dir: NORMAL     ")
                                       : (tempMotorDir ? "Dir: REVERSE[RV]" : "Dir: NORMAL [FW]"));
                } else if (hiddenOption == 3) {
                    if (tempAutoLockSec == 0UL) {
                        strcpy(l2, hideVal ? "Lock: OFF       " : "Lock: OFF  [OFF]");
                    } else {
                        memcpy(l2, "Lock: 000s [ON] ", 17);
                        formatUint(l2 + 6, (uint32_t)tempAutoLockSec, 3, true);
                        if (hideVal) {
                            if (settingDigitCursor == 0) memcpy(&l2[11], "    ", 4);
                            else if (settingDigitCursor <= 3) l2[5 + settingDigitCursor] = ' ';
                        }
                    }
                } else if (hiddenOption == 4) {
                    if (tempBacklightSec == 0 && !isEditingSetting) {
                        strcpy(l2, "Light: ALWAYS ON");
                    } else {
                        memcpy(l2, "Light: 000 s    ", 17);
                        formatUint(l2 + 7, (uint32_t)tempBacklightSec, 3, true);
                        if (hideVal && settingDigitCursor < 3) l2[7 + settingDigitCursor] = ' ';
                    }
                } else if (hiddenOption == 5) {
                    strcpy(l2, "Open Diagnostics");
                } else if (hiddenOption == 6) {
                    strcpy(l2, "Open Advance >> ");
                } else {
                    strcpy(l2, "Select Save/Exit");
                }

                lcdPrint16(0, m1Title);
                lcdPrint16(1, l2);
            }
            break;

            case 2: // Level 2: Advance Menu (5 Machine Geometry Options)
            {
                static const char* const kMenu2Titles[5] = {
                    "1. Driver Res   ", "2. Roller Dia   ", "3. Feed Angle   ",
                    "4. Safety Margin", "5. << Back      "
                };
                const char* m2Title = (advanceOption >= 1 && advanceOption <= 5) ? kMenu2Titles[advanceOption - 1] : kMenu2Titles[0];
                const bool hideVal = isEditingSetting && blinkHide;

                if (advanceOption == 1) {
                    if (hideVal) strcpy(l2, "Val:       steps");
                    else {
                        memcpy(l2, "Val:       steps", 17);
                        formatUint(l2 + 5, (uint32_t)tempDriverRes, 5, false);
                    }
                } else if (advanceOption == 2) {
                    int dTenths = (int)(tempRollerDia * 10.0f + 0.5f);
                    memcpy(l2, "Val: 000.0 mm   ", 17);
                    formatFixed1(l2 + 5, (uint32_t)dTenths, 3, true);
                    if (hideVal) {
                        if (settingDigitCursor == 0)      l2[9] = ' ';
                        else if (settingDigitCursor == 1) l2[7] = ' ';
                        else if (settingDigitCursor == 2) l2[6] = ' ';
                        else                              l2[5] = ' ';
                    }
                } else if (advanceOption == 3) {
                    memcpy(l2, "Val: 000 deg    ", 17);
                    formatUint(l2 + 5, (uint32_t)tempFeedAngle, 3, true);
                    if (hideVal && settingDigitCursor < 3) l2[5 + settingDigitCursor] = ' ';
                } else if (advanceOption == 4) {
                    memcpy(l2, "Val: 00 %       ", 17);
                    formatUint(l2 + 5, (uint32_t)tempSafetyMargin, 2, true);
                    if (hideVal && settingDigitCursor < 2) l2[5 + settingDigitCursor] = ' ';
                } else {
                    strcpy(l2, "Return to Main  ");
                }

                lcdPrint16(0, m2Title);
                lcdPrint16(1, l2);
            }
            break;

            case 13:
                memcpy(l1, "SAVE CHANGES?   ", 17);
                if (saveExitChoice) {
                    memcpy(l2, blinkHide ? "       NO       " : ">YES   NO       ", 17);
                } else {
                    memcpy(l2, blinkHide ? " YES            " : " YES  >NO       ", 17);
                }
                lcdPrint16(0, l1);
                lcdPrint16(1, l2);
                break;

            case 3:
                lcdPrint16(0, "Factory Reset?  ");
                if (resetChoice) {
                    lcdPrint16(1, blinkHide ? "      NO        " : ">YES  NO        ");
                } else {
                    lcdPrint16(1, blinkHide ? " YES            " : " YES >NO        ");
                }
                break;

            case 9: // Streamlined 5-Page Essential Diagnostics (Page 1: Active Issue immediately at 0 scrolls!)
            {
                int cycle = (bm_millis() / 1500UL) % 2;
                char dl1[24] = "                ";
                char dl2[24] = "                ";
                switch (infoIndex) {
                    case 1:
                        evaluateDiagnostics();
                        memcpy(dl1, diagFixLine1 ? diagFixLine1 : "ACTIVE ISSUE:   ", 16);
                        dl1[16] = '\0';
                        memcpy(dl2, diagFixLine2 ? diagFixLine2 : "NONE / OPTIMAL  ", 16);
                        dl2[16] = '\0';
                        break;
                    case 2:
                        memcpy(dl1, "STEPPER JOG TST ", 17);
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            memcpy(dl2, "BLOCKED: RUNNING", 17);
                        } else {
                            bool jFwd = (bm_digitalRead(btnUp) == LOW);
                            bool jRev = (bm_digitalRead(btnDown) == LOW);
                            if (jFwd)      memcpy(dl2, "JOG FWD >>> [UP]", 17);
                            else if (jRev) memcpy(dl2, "JOG REV <<< [DN]", 17);
                            else           memcpy(dl2, "UP:FWD   DN:REV ", 17);
                        }
                        break;
                    case 3:
                        memcpy(dl1, "OPTO SINK TST   ", 17);
                        if (currentRPM != 0UL || hwBurstActive || stepsRemaining != 0) {
                            memcpy(dl2, "BLOCKED: RUNNING", 17);
                        } else {
                            bool sOn = (bm_digitalRead(btnUp) == LOW);
                            if (sOn) memcpy(dl2, "V<=0.5V SINK ON ", 17);
                            else     memcpy(dl2, "HOLD [UP] TEST  ", 17);
                        }
                        break;
                    case 4:
                        memcpy(dl1, "TRIGGER & NOISE ", 17);
                        if (isMotionSyncLost) {
                            memcpy(dl2, "FAULT:SYNC LOST!", 17);
                        } else {
                            memcpy(dl2, "T:     O:   R:  ", 17);
                            formatUint(dl2 + 2, (uint32_t)(validTriggerCount % 100000UL), 5, false);
                            formatUint(dl2 + 9, (uint32_t)(tim2CaptureOverrunCount % 100UL), 2, false);
                            formatUint(dl2 + 14, (uint32_t)(rejectedTriggerCount % 100UL), 2, false);
                        }
                        break;
                    case 5:
                        memcpy(dl1, "V17.1.0 (NIPON) ", 17);
                        if (cycle == 0) {
                            memcpy(dl2, "DEV: RAJESH SHAH", 17);
                        } else {
                            memcpy(dl2, "BLD: OCT-2026   ", 17);
                        }
                        if (g_firmware_build_tag[0] == 0) { (void)g_firmware_build_tag; }
                        break;
                    default:
                        infoIndex = 1;
                        break;
                }
                lcdPrint16(0, dl1);
                lcdPrint16(1, dl2);
            }
            break;
        }
        lastDisplayUpdate = bm_millis();
    }
}
