#ifndef BAREMETAL_CMSIS_STM32F103_H
#define BAREMETAL_CMSIS_STM32F103_H

/*
 * ============================================================================
 * 100% PURE FREESTANDING BARE-METAL CMSIS HEADER FOR STM32F103C6T6 / C8T6
 * Zero Arduino Core, Zero STM32 HAL, Zero Newlib Heap Overhead.
 * Directly maps Cortex-M3 & STM32F103 silicon registers, 72 MHz HSE PLL clock,
 * SysTick 1kHz timebase, DWT 72MHz cycle counter, and ARM vector table.
 * ============================================================================
 */
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>

#if defined(PURE_BAREMETAL_BUILD) && !defined(HOST_SIMULATION_TEST)

#define HIGH 1
#define LOW  0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2

#define PA0  0
#define PA2  2
#define PA8  8
#define PB0  16
#define PB1  17
#define PB6  22
#define PB7  23
#define PB8  24
#define PB9  25
#define PB10 26
#define PB11 27
#define PB12 28
#define PB13 29
#define PB14 30
#define PB15 31
#define PC13 45

// --- Cortex-M3 Core Peripherals ---
struct SCB_Type {
    volatile uint32_t CPUID;
    volatile uint32_t ICSR;
    volatile uint32_t VTOR;
    volatile uint32_t AIRCR;
    volatile uint32_t SCR;
    volatile uint32_t CCR;
    volatile uint8_t  SHP[12];
    volatile uint32_t SHCSR;
};
#define SCB ((SCB_Type *)0xE000ED00UL)

struct SysTick_Type {
    volatile uint32_t CTRL;
    volatile uint32_t LOAD;
    volatile uint32_t VAL;
    volatile uint32_t CALIB;
};
#define SysTick ((SysTick_Type *)0xE000E010UL)

struct NVIC_Type {
    volatile uint32_t ISER[8];
    uint32_t RESERVED0[24];
    volatile uint32_t ICER[8];
    uint32_t RSERVED1[24];
    volatile uint32_t ISPR[8];
    uint32_t RESERVED2[24];
    volatile uint32_t ICPR[8];
    uint32_t RESERVED3[24];
    volatile uint32_t IABR[8];
    uint32_t RESERVED4[56];
    volatile uint8_t  IP[240];
};
#define NVIC ((NVIC_Type *)0xE000E100UL)

struct CoreDebug_Type {
    volatile uint32_t DHCSR;
    volatile uint32_t DCRSR;
    volatile uint32_t DCRDR;
    volatile uint32_t DEMCR;
};
#define CoreDebug ((CoreDebug_Type *)0xE000EDF0UL)
#define CoreDebug_DEMCR_TRCENA_Msk (1U << 24)

struct DWT_Type {
    volatile uint32_t CTRL;
    volatile uint32_t CYCCNT;
};
#define DWT ((DWT_Type *)0xE0001000UL)
#define DWT_CTRL_CYCCNTENA_Msk (1U << 0)

enum IRQn_Type {
    SysTick_IRQn = -1,
    TIM1_UP_IRQn = 25,
    TIM2_IRQn    = 28,
    TIM4_IRQn    = 30
};

static inline uint32_t __get_PRIMASK(void) {
    uint32_t result = 0;
#if defined(__ARM_ARCH)
    __asm volatile ("MRS %0, primask" : "=r" (result));
#endif
    return result;
}
static inline void __disable_irq(void) {
#if defined(__ARM_ARCH)
    __asm volatile ("cpsid i" : : : "memory");
#endif
}
static inline void __enable_irq(void) {
#if defined(__ARM_ARCH)
    __asm volatile ("cpsie i" : : : "memory");
#endif
}
static inline void __set_PRIMASK(uint32_t priMask) {
#if defined(__ARM_ARCH)
    __asm volatile ("MSR primask, %0" : : "r" (priMask) : "memory");
#else
    (void)priMask;
#endif
}

static inline void NVIC_EnableIRQ(IRQn_Type IRQn) {
    if ((int32_t)IRQn >= 0) {
        NVIC->ISER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1U << (((uint32_t)IRQn) & 0x1FUL));
    }
}
static inline void NVIC_ClearPendingIRQ(IRQn_Type IRQn) {
    if ((int32_t)IRQn >= 0) {
        NVIC->ICPR[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1U << (((uint32_t)IRQn) & 0x1FUL));
    }
}
static inline void NVIC_SetPriority(IRQn_Type IRQn, uint32_t priority) {
    if ((int32_t)IRQn >= 0) {
        NVIC->IP[(uint32_t)IRQn] = (uint8_t)((priority << 4U) & 0xFFUL);
    } else {
        SCB->SHP[(((uint32_t)IRQn) & 0xFUL) - 4UL] = (uint8_t)((priority << 4U) & 0xFFUL);
    }
}

// --- STM32F103 Peripherals ---
struct RCC_TypeDef {
    volatile uint32_t CR;
    volatile uint32_t CFGR;
    volatile uint32_t CIR;
    volatile uint32_t APB2RSTR;
    volatile uint32_t APB1RSTR;
    volatile uint32_t AHBENR;
    volatile uint32_t APB2ENR;
    volatile uint32_t APB1ENR;
    volatile uint32_t BDCR;
    volatile uint32_t CSR;
};
#define RCC ((RCC_TypeDef *)0x40021000UL)
#define RCC_APB1ENR_TIM2EN (1U << 0)
#define RCC_APB1ENR_TIM4EN (1U << 2)
#define RCC_APB2ENR_TIM1EN (1U << 11)

struct GPIO_TypeDef {
    volatile uint32_t CRL;
    volatile uint32_t CRH;
    volatile uint32_t IDR;
    volatile uint32_t ODR;
    volatile uint32_t BSRR;
    volatile uint32_t BRR;
    volatile uint32_t LCKR;
};
#define GPIOA ((GPIO_TypeDef *)0x40010800UL)
#define GPIOB ((GPIO_TypeDef *)0x40010C00UL)
#define GPIOC ((GPIO_TypeDef *)0x40011000UL)

struct AFIO_TypeDef {
    volatile uint32_t EVCR;
    volatile uint32_t MAPR;
    volatile uint32_t EXTICR[4];
    uint32_t RESERVED0;
    volatile uint32_t MAPR2;
};
#define AFIO ((AFIO_TypeDef *)0x40010000UL)

struct IWDG_TypeDef {
    volatile uint32_t KR;
    volatile uint32_t PR;
    volatile uint32_t RLR;
    volatile uint32_t SR;
};
#define IWDG ((IWDG_TypeDef *)0x40003000UL)

struct TIM_TypeDef {
    volatile uint32_t CR1;
    volatile uint32_t CR2;
    volatile uint32_t SMCR;
    volatile uint32_t DIER;
    volatile uint32_t SR;
    volatile uint32_t EGR;
    volatile uint32_t CCMR1;
    volatile uint32_t CCMR2;
    volatile uint32_t CCER;
    volatile uint32_t CNT;
    volatile uint32_t PSC;
    volatile uint32_t ARR;
    volatile uint32_t RCR;
    volatile uint32_t CCR1;
    volatile uint32_t CCR2;
    volatile uint32_t CCR3;
    volatile uint32_t CCR4;
    volatile uint32_t BDTR;
    volatile uint32_t DCR;
    volatile uint32_t DMAR;
};
#define TIM1 ((TIM_TypeDef *)0x40012C00UL)
#define TIM2 ((TIM_TypeDef *)0x40000000UL)

#define TIM_CR1_CEN     (1U << 0)
#define TIM_CR1_OPM     (1U << 3)
#define TIM_CR1_ARPE    (1U << 7)
#define TIM_DIER_UIE    (1U << 0)
#define TIM_DIER_CC1IE  (1U << 1)
#define TIM_SR_UIF      (1U << 0)
#define TIM_SR_CC1IF    (1U << 1)
#define TIM_SR_CC1OF    (1U << 9)
#define TIM_EGR_UG      (1U << 0)
#define TIM_CCMR1_CC1S  (3UL << 0)
#define TIM_CCMR1_OC1PE (1U << 3)
#define TIM_CCMR1_OC1M  (7UL << 4)
#define TIM_CCMR1_IC1F  (0xFUL << 4)
#define TIM_CCER_CC1E   (1U << 0)
#define TIM_CCER_CC1P   (1U << 1)
#define TIM_BDTR_MOE    (1U << 15)

template <typename T, typename A, typename B>
static inline T constrain(T x, A a, B b) {
    if (x < (T)a) return (T)a;
    if (x > (T)b) return (T)b;
    return x;
}

using std::abs;

// --- Pure Bare-Metal 1kHz SysTick & 72MHz DWT Timebase ---
static volatile uint32_t g_bm_systick_ms = 0UL;

extern "C" void SysTick_Handler(void) {
    g_bm_systick_ms++;
}

static inline unsigned long bm_millis(void) {
    return (unsigned long)g_bm_systick_ms;
}

static inline unsigned long bm_micros(void) {
    uint32_t ms, val;
    do {
        ms  = g_bm_systick_ms;
        val = SysTick->VAL;
    } while (ms != g_bm_systick_ms);
    return (unsigned long)(ms * 1000UL + (71999UL - val) / 72UL);
}

static inline void bm_delay_us(unsigned int us) {
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = (uint32_t)us * 72UL;
    while ((uint32_t)(DWT->CYCCNT - start) < ticks) {}
}

static inline void bm_delay_ms(unsigned long ms) {
    while (ms-- > 0UL) {
        bm_delay_us(1000U);
    }
}

#define millis           bm_millis
#define micros           bm_micros
#define delay            bm_delay_ms
#define delayMicroseconds bm_delay_us

// --- Pure Bare-Metal 72 MHz Clock Init (HSE 8MHz x 9 PLL, Flash 2WS) ---
static void bm_system_clock_72mhz_init(void) {
    RCC->CR |= (1U << 16); // HSEON
    uint32_t timeout = 0x10000UL;
    while (!(RCC->CR & (1U << 17)) && --timeout) {} // Wait HSERDY

    *(volatile uint32_t *)0x40022000UL = 0x12UL; // FLASH->ACR = PRFTBE | LATENCY_2

    RCC->CFGR &= ~(0xFUL << 4 | 0x7UL << 8 | 0x7UL << 11 | 0xFUL << 18 | 1UL << 16 | 1UL << 17);
    RCC->CFGR |= (0x4UL << 8); // PPRE1 = DIV2 (36 MHz max APB1)

    if (RCC->CR & (1U << 17)) {
        RCC->CFGR |= (1U << 16) | (0x7UL << 18); // HSE * 9 = 72 MHz
    } else {
        RCC->CFGR |= (0xEUL << 18); // HSI/2 * 16 = 64 MHz fallback
    }

    RCC->CR |= (1U << 24); // PLLON
    timeout = 0x10000UL;
    while (!(RCC->CR & (1U << 25)) && --timeout) {} // Wait PLLRDY

    RCC->CFGR = (RCC->CFGR & ~0x3UL) | 0x2UL; // SW = PLL
    timeout = 0x10000UL;
    while (((RCC->CFGR & 0xCUL) != 0x8UL) && --timeout) {} // Wait SWS = PLL

    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0UL;
    DWT->CTRL  |= DWT_CTRL_CYCCNTENA_Msk;

    SysTick->LOAD = 72000UL - 1UL;
    SysTick->VAL  = 0UL;
    SysTick->CTRL = 0x07UL; // CLKSOURCE=CPU (72MHz), TICKINT=1, ENABLE=1
}

// --- Pure Bare-Metal Startup & Cortex-M3 Vector Table (@ 0x08000000) ---
extern "C" {
    extern uint32_t _estack;
    extern uint32_t _sidata;
    extern uint32_t _sdata;
    extern uint32_t _edata;
    extern uint32_t _sbss;
    extern uint32_t _ebss;
    extern void (*__preinit_array_start[])(void);
    extern void (*__preinit_array_end[])(void);
    extern void (*__init_array_start[])(void);
    extern void (*__init_array_end[])(void);

    void TIM1_UP_IRQHandler(void);
    void TIM2_IRQHandler(void);
    void setup(void);
    void loop(void);

    void Default_Handler(void) {
        while (1) {}
    }

    void __attribute__((noreturn, used)) Reset_Handler(void) {
        uint32_t *src = &_sidata;
        uint32_t *dst = &_sdata;
        while (dst < &_edata) {
            *dst++ = *src++;
        }
        dst = &_sbss;
        while (dst < &_ebss) {
            *dst++ = 0UL;
        }
        for (void (**p)(void) = __preinit_array_start; p < __preinit_array_end; ++p) {
            (*p)();
        }
        for (void (**p)(void) = __init_array_start; p < __init_array_end; ++p) {
            (*p)();
        }
        bm_system_clock_72mhz_init();
        __enable_irq();
        setup();
        for (;;) {
            loop();
        }
    }

    typedef void (*isr_vector_fn)(void);

    __attribute__((section(".isr_vector"), used))
    const isr_vector_fn g_pfnVectors[60] = {
        (isr_vector_fn)(&_estack), // 0: Initial Stack Pointer (0x20002800)
        Reset_Handler,             // 1: Reset Handler
        Default_Handler,           // 2: NMI
        Default_Handler,           // 3: HardFault
        Default_Handler,           // 4: MemManage
        Default_Handler,           // 5: BusFault
        Default_Handler,           // 6: UsageFault
        0, 0, 0, 0,                // 7..10: Reserved
        Default_Handler,           // 11: SVCall
        Default_Handler,           // 12: Debug Monitor
        0,                         // 13: Reserved
        Default_Handler,           // 14: PendSV
        SysTick_Handler,           // 15: SysTick (1.000 ms bare-metal timebase)
        // External Interrupts (IRQ 0 .. 43)
        Default_Handler,           // IRQ 0:  WWDG
        Default_Handler,           // IRQ 1:  PVD
        Default_Handler,           // IRQ 2:  TAMPER
        Default_Handler,           // IRQ 3:  RTC
        Default_Handler,           // IRQ 4:  FLASH
        Default_Handler,           // IRQ 5:  RCC
        Default_Handler,           // IRQ 6:  EXTI0
        Default_Handler,           // IRQ 7:  EXTI1
        Default_Handler,           // IRQ 8:  EXTI2
        Default_Handler,           // IRQ 9:  EXTI3
        Default_Handler,           // IRQ 10: EXTI4
        Default_Handler,           // IRQ 11: DMA1_Channel1
        Default_Handler,           // IRQ 12: DMA1_Channel2
        Default_Handler,           // IRQ 13: DMA1_Channel3
        Default_Handler,           // IRQ 14: DMA1_Channel4
        Default_Handler,           // IRQ 15: DMA1_Channel5
        Default_Handler,           // IRQ 16: DMA1_Channel6
        Default_Handler,           // IRQ 17: DMA1_Channel7
        Default_Handler,           // IRQ 18: ADC1_2
        Default_Handler,           // IRQ 19: USB_HP_CAN1_TX
        Default_Handler,           // IRQ 20: USB_LP_CAN1_RX0
        Default_Handler,           // IRQ 21: CAN1_RX1
        Default_Handler,           // IRQ 22: CAN1_SCE
        Default_Handler,           // IRQ 23: EXTI9_5
        Default_Handler,           // IRQ 24: TIM1_BRK
        TIM1_UP_IRQHandler,        // IRQ 25: TIM1_UP (PA8 Step Pulse Generator)
        Default_Handler,           // IRQ 26: TIM1_TRG_COM
        Default_Handler,           // IRQ 27: TIM1_CC
        TIM2_IRQHandler,           // IRQ 28: TIM2 (PA0 Cam Proximity Capture)
        Default_Handler,           // IRQ 29: TIM3
        Default_Handler,           // IRQ 30: TIM4
        Default_Handler,           // IRQ 31: I2C1_EV
        Default_Handler,           // IRQ 32: I2C1_ER
        Default_Handler,           // IRQ 33: I2C2_EV
        Default_Handler,           // IRQ 34: I2C2_ER
        Default_Handler,           // IRQ 35: SPI1
        Default_Handler,           // IRQ 36: SPI2
        Default_Handler,           // IRQ 37: USART1
        Default_Handler,           // IRQ 38: USART2
        Default_Handler,           // IRQ 39: USART3
        Default_Handler,           // IRQ 40: EXTI15_10
        Default_Handler,           // IRQ 41: RTC_Alarm
        Default_Handler,           // IRQ 42: USBWakeUp
        Default_Handler            // IRQ 43: Reserved
    };
}


extern "C" {
__attribute__((weak, used, optimize("O2"))) void *memcpy(void *dst, const void *src, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (n--) *d++ = *s++;
    return dst;
}

__attribute__((weak, used, optimize("O2"))) void *memset(void *dst, int c, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    while (n--) *d++ = (uint8_t)c;
    return dst;
}

__attribute__((weak, used, optimize("O2"))) int memcmp(const void *s1, const void *s2, size_t n) {
    const uint8_t *p1 = (const uint8_t *)s1;
    const uint8_t *p2 = (const uint8_t *)s2;
    while (n--) {
        if (*p1 != *p2) return (int)*p1 - (int)*p2;
        p1++;
        p2++;
    }
    return 0;
}

__attribute__((weak, used, optimize("O2"))) char *strcpy(char *dst, const char *src) {
    char *d = dst;
    while ((*d++ = *src++) != 0) {}
    return dst;
}

__attribute__((weak, used, optimize("O2"))) size_t strlen(const char *s) {
    size_t len = 0;
    while (s[len]) len++;
    return len;
}

__attribute__((weak, used, optimize("O2"))) int strncmp(const char *s1, const char *s2, size_t n) {
    while (n--) {
        unsigned char c1 = (unsigned char)*s1++;
        unsigned char c2 = (unsigned char)*s2++;
        if (c1 != c2) return (int)c1 - (int)c2;
        if (c1 == 0) return 0;
    }
    return 0;
}
} // extern "C"

#endif // PURE_BAREMETAL_BUILD && !HOST_SIMULATION_TEST
#endif // BAREMETAL_CMSIS_STM32F103_H
