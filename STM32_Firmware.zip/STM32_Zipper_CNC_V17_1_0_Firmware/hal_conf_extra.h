#ifndef HAL_CONF_EXTRA_H
#define HAL_CONF_EXTRA_H

/*
 * Pure Bare-Metal CMSIS Register Configuration for STM32F103C6T6 (32KB) & C8T6 (64KB)
 * Original C8T6 V17.1.0 (100% Features Retained: 7-Option Menu, 5-Page Diagnostics,
 * Backlight Timeout, Auto-Lock, Dual-Slot Ping-Pong Flash @ 0x08007C00).
 *
 * Disables STM32duino HardwareTimer C++ wrapper (HAL_TIM_MODULE_ONLY) and unused
 * HAL peripheral drivers so the full-featured firmware compiles into ~16-22 KB Flash.
 */
#define HAL_TIM_MODULE_ONLY
#define HAL_I2C_MODULE_DISABLED
#define HAL_UART_MODULE_DISABLED
#define HAL_USART_MODULE_DISABLED
#define HAL_SPI_MODULE_DISABLED
#define HAL_ADC_MODULE_DISABLED
#define HAL_DAC_MODULE_DISABLED
#define HAL_RTC_MODULE_DISABLED
#define HAL_PCD_MODULE_DISABLED
#define HAL_CAN_MODULE_DISABLED
#define HAL_ETH_MODULE_DISABLED
#define HAL_SD_MODULE_DISABLED
#define HAL_QSPI_MODULE_DISABLED
#define HAL_WWDG_MODULE_DISABLED

#endif /* HAL_CONF_EXTRA_H */
