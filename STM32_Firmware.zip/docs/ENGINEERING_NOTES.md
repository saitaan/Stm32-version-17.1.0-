# STM32 Zipper CNC Engineering Decision Record (V17.1.0 Production Master)

## 1. Direct Max-RPM Clamped Step Engine (Zero Redundant ISR Division)
**Date:** 2026-10-27  
**Project:** STM32 Zipper CNC (Adaptive Servo-Sync Master-Follower Engine)  
**Location:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat  
**Systems Architect:** Rajesh Shah  

### Context & Engineering Rationale
1. **Direct Button & Pedal 500W AC Servo Compatibility:**
   - Industrial zipper sewing machines at Nipon Zipper Industries operate both with foot pedals and with **Direct Push-Button Start (pedal-less auto-start)**.
   - On a Direct Push-Button 500W AC Servo machine, pressing Start applies 100% step-input torque (`0 -> 2500..3000 RPM`), reaching high shaft velocity within the very first revolution (`90°` window $\le 6.0\text{ ms}$).
   - Computing a dynamic 1st-stitch Cam-Gap RPM or variable low-RPM window inside the ISR only to clamp it back to `configuredDeadlineUs = maximumBurstWindowUs(maxRPMSetting, feedAngleDeg, safetyMarginPercent)` wasted CPU cycles on 64-bit software division (`__aeabi_uldivmod`) and added unnecessary menu complexity (`Start RPM` and `Cam Gap Deg`).
2. **Operating Rule:**
   - `calculateAdaptiveStepPeriodQ16()` directly uses `maximumBurstWindowUs(maxRPMSetting, feedAngleDeg, safetyMarginPercent)`.
   - Changing **`1. Max RPM`** (or `Feed Angle` / `Safety Margin`) in the Settings Menu immediately updates the step window clamp (`configuredDeadlineUs`), nominal step period `W` (`activePulseWidth`), and Q16.16 timer period (`servoPeriodQ16`).
   - Every stitch from Stitch #1 to Stitch #N executes with deterministic, identical pulse timing and tension.
   - Measured `PA0` trigger intervals (`diff`) are used strictly for:
     1. **Live 4-Digit LCD RPM Display** (`0000` at standstill, live filtered RPM while running — `AUTO` indicator removed).
     2. **Plausibility & Contact-Chatter Noise Filtering** (`minimumPlausibleIntervalUs`).
     3. **Motion Sync Watchdog** (`>= 150 RPM` threshold; 100% muted below `150 RPM` for handwheel testing).
   - Useless `Start RPM` and `Cam Gap Deg` options and `TIM2_CH2` rising-edge interrupts are completely removed, streamlining Level 2 Advance Menu to **5 clean options** (`1. Driver Res`, `2. Roller Dia`, `3. Feed Angle`, `4. Safety Margin`, `5. << Back`).

---

## 2. Fractional Accumulator Reset on Standstill (> 400 ms / > 2.0 Seconds)
1. **Standstill Reset:** When the machine pauses for `> 400 ms` (in `loop()` or ISR backup net) or `> 2.0 s` standstill timeout, `pulseFracAccumulator = 0UL;` and `hwBurstPeriodFrac = 0UL;` reset to zero.
2. **Determinism:** Every fresh piece begins with an exact zero-residue phase baseline, while continuous running preserves `< 0.025 mm` mathematical convergence over 1.6 km of zipper tape.

---

## 3. Strict Pure V17.1.0 EEPROM Schema (`0x5A431710UL`)
1. `pulsestep_persistence.h` and `loadFromEEPROM()` strictly require `rec.magic == EEPROM_MAGIC_V17_1_0` (`0x5A431710UL`) and full CRC-32 validation, rejecting any untested legacy records and initializing clean V17.1.0 factory defaults.

---

## 4. 2-Tier Notification Bell & 8 us Hardware Floor (Leadshine DM542 Optocoupler Protection)
1. **Leadshine DM542 Optocoupler Turn-Off Protection:**
   - The Leadshine DM542 input optocoupler requires a minimum pulse space (inactive off-time) of >= 2.5 us to fully de-saturate the phototransistor.
   - At a 7 us step period with a 5.0 us active-LOW pulse (STEP_PULSE_WIDTH_US = 5), the inactive HIGH space is only 2.0 us, crossing the optocoupler turnaround safety margin.
   - Therefore, SERVO_PERIOD_MIN_US is set strictly to 8U, giving 5.0 us active pulse + 3.0 us space (3.0 us >= 2.5 us), eliminating step dropping risk at maximum speed.
2. **2-Tier Notification Bell (\x01 at Column 12):**
   - **W >= 10 us:** Safe operating window; Bell icon is completely OFF (hidden space).
   - **W = 9 us:** Early Warning; Bell icon is displayed Solid / Steady ON (\x01), alerting the operator that settings are nearing the limit without distracting blinking.
   - **W <= 8 us (or invalid timing):** Critical Limit Warning; Bell icon blinks (500 ms ON / 500 ms OFF), and the step period is clamped strictly at 8 us.
