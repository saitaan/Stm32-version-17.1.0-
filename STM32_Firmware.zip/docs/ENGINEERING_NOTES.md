# STM32 Zipper CNC Engineering Decision Record

## Decision: Fractional Accumulator Reset on Standstill (> 2.0 Seconds)
**Date:** 2026-10-21  
**Project:** STM32 Zipper CNC (Adaptive Servo-Sync Master-Follower Engine)  
**Location:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat  
**Systems Architect:** Rajesh Shah  

### Context & Problem
During production stitching of zipper tape and coil, operators frequently stop the machine for > 2.0 seconds (`diff > 2000000UL`) to:
1. Re-thread needle thread after a cut or spool change.
2. Load a fresh roll of zipper tape or coil.
3. Position a new garment/workpiece under the needle clamp.

If the internal 32-bit micro-fractional accumulator (`pulseFracAccumulator`) retains the residue of the previous piece (e.g. 0.85 microsteps), that leftover fraction immediately forces an unexpected extra microstep (+1 carry step) on stitch #1 or #2 of the fresh piece.

### Decision & Operating Rule
1. **Standstill Reset:** When machine standstill timeout occurs (`diff > 2,000,000 µs` without cam triggers), `pulseFracAccumulator = 0UL;` and `hwBurstPeriodFrac = 0UL;` are reset to zero.
2. **Determinism:** Every fresh piece begins with an exact, identical zero-residue phase baseline.
3. **Continuous Stitching Intact:** During continuous running within a piece, the accumulator is never reset, guaranteeing mathematical convergence (< 0.025 mm error over 1.6 km of continuous tape).

## Queued Batch Update Item: Strict Pure V17.1.0 EEPROM Schema (Remove Legacy V16.5.1 / V17.0.0 Migration)
**Status:** QUEUED FOR NEXT BATCH UPDATE (On Hold per Rajesh Shah Directive)  
**Date Logged:** 2026-10-21 23:28 IST  

### Objective & Architecture
1. **Remove Legacy Backward-Compatibility Branches:**
   - Remove `EEPROM_MAGIC_V17_0_0` (`0x5A431700UL`) and `EEPROM_MAGIC_V16_5_1` (`0x5A431651UL`) validation logic in `pulsestep_persistence.h` and `loadFromEEPROM()`.
   - Require strictly `rec.magic == EEPROM_MAGIC_V17_1_0` (`0x5A431710UL`) and 72-byte CRC validation for record acceptance.
2. **Prevent Contamination from Untested Firmware Builds:**
   - Flashing a fresh or updated board will automatically reject any stale/corrupt settings left in Flash EEPROM by older experimental builds.
   - On boot, if `rec.magic != EEPROM_MAGIC_V17_1_0`, system cleanly falls back to `loadFactoryDefaults()` and initializes a pure `V17.1.0` ping-pong slot.
3. **Execution Plan:**
   - Wait for Rajesh Shah's instruction to execute alongside upcoming batch updates.
   - Update `pulsestep_persistence.h`, `STM32_Zipper_CNC_V17_1_0_Firmware.ino`, and `test_pulsestep_persistence.cpp` / `test_v17_all_bugfixes_hil.cpp`.

## Queued Batch Update Item: Dynamic Standstill Cam Alignment Auto-Arm Indicator ('AUTO') on Line 1
**Status:** QUEUED FOR NEXT BATCH UPDATE (Design Approved by Rajesh Shah)  
**Date Logged:** 2026-10-22 06:21 IST  

### Operator Ergonomics & Behavior Specification (per Rajesh Shah):
1. **Running State (`currentRPM > 0` or `hwBurstActive`):**
   - No 'A' shown. Line 1 retains full original 2-decimal feed precision:
     `S:8   2400 F:2.81` (16 characters exact).
2. **Standstill Unaligned (`currentRPM == 0`, cam not in slot):**
   - Shows normal standstill display without 'A':
     `S:8   0000 F:2.81` (16 characters exact).
3. **Standstill Armed & Aligned (`currentRPM == 0`, `proxSensorPin == LOW`):**
   - Cam is aligned and armed for Auto 1st RPM measurement.
   - Screen dynamically displays `A` and shifts feed to 1-decimal `F:2.8`:
     `S:8   AUTO F:2.81` (16 characters exact).
   - As soon as pedal is pressed and machine runs, `A` instantly disappears and Line 1 reverts to `F:2.81`.
