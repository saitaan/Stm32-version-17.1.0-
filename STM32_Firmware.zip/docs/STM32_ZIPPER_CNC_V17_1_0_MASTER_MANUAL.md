# STM32 ZIPPER CNC FEEDER — MASTER TECHNICAL MANUAL & SYSTEM GUIDE

**Firmware Version:** V17.1.0 Production Master (`V17.1.0-PA0-TIM2-CAPTURE-PA8-TIM1`)  
**Target Hardware:** STM32F103C6T6 (32 KB) & STM32F103C8T6 (64 KB) (ARM Cortex-M3 @ 72 MHz, "Blue Pill")  
**Application:** High-Speed Zipper Stitching CNC Feeder (Direct Max-RPM Clamped Step Engine)  
**Factory Installation:** Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat  
**Lead Embedded Systems Architect:** Rajesh Shah  
**Release Date:** October 2026  

---

## 1. SYSTEM OVERVIEW & SPECIFICATIONS

### 1.1 Machine Mission & Direct Max-RPM Clamped Operating Principle
The STM32 Zipper CNC Feeder is an ultra-precise, real-time slave-following CNC feeding mechanism mounted on heavy-duty industrial zipper sewing machines (compatible with both **Direct Push-Button Auto-Start** and **Foot-Pedal** 500W AC Servo machines). At line speeds of up to **3000 RPM (20,000 µs per complete stitch cycle)**, the feeder advances zipper tape by the exact tooth pitch of the zipper coil (Size #5, Size #8, or Size #10) strictly within the needle-retracted clearance angle (Feed Window), stopping completely with full holding torque before the sewing needle descends to pierce the zipper tape.

- **Direct `Max RPM` Clamp Step Engine:**
  - The step burst window (`configuredDeadlineUs`) and pulse period (`W`) are directly governed by **`maximumBurstWindowUs(maxRPMSetting, feedAngleDeg, safetyMarginPercent)`** with zero redundant per-stitch dynamic-RPM division inside the real-time interrupt.
  - Whenever **`1. Max RPM`** (or `Feed Angle` / `Safety Margin`) is changed in Settings, the clamp window and step pulse period (`W` / `TIM1->ARR`) update immediately and proportionally:
    - `Max RPM = 3000`, `90°`, `15%` margin → Clamp = **`4,250 µs`** (`W = 53 µs` for 80 pulses).
    - `Max RPM = 2000`, `90°`, `15%` margin → Clamp = **`6,375 µs`** (`W = 79 µs` for 80 pulses).
    - `Max RPM = 1500`, `90°`, `15%` margin → Clamp = **`8,500 µs`** (`W = 106 µs` for 80 pulses).
  - Measured `PA0` trigger intervals (`diff`) are used strictly for **Live 4-Digit LCD RPM Display** (`0000` at standstill, live RPM while running), **Noise/Glitch Rejection**, **Standstill Accumulator Reset (`> 400 ms` / `> 2.0 s`)**, and **Motion Sync Watchdog (`>= 150 RPM`)**.

```text
       3000 RPM Full Spindle Cycle (20,000 µs Total)
┌──────────────────────────────────────┬──────────────────────────────────────┐
│  Needle Clear Zone: 90° Feed Window  │ Needle Penetration Zone: 270° Locked │
│ Gross Time: 5,000 µs                 │ Spindle & Tape Locked Stiff          │
│ Effective Burst Clamp: 4,250 µs      │ Zero Stepper Motion                  │
│ Cushion: 750 µs (15% Safety Margin)  │ Zero Needle Collisions               │
└──────────────────────────────────────┴──────────────────────────────────────┘
```

### 1.2 Master Performance Specifications
| Specification | Parameter Value | Engineering Rationale |
| :--- | :--- | :--- |
| **Max Sewing Spindle Speed** | **3000 RPM Default (100–4000 RPM)** | Directly sets the step burst clamp window (`maximumBurstWindowUs`) and `W` |
| **Gross Feed Angle** | **90° Default (30°–270°)** | Mechanical cam window where needle is outside fabric/tape |
| **Safety Margin Cushion** | **15% Default (0%–29%)** | Eliminates needle deflection & collision risk (750 µs cushion at 3000 RPM) |
| **Effective Feed Window Clamp** | **4,250 µs (at 3000 RPM / 90° / 15%)** | Deterministic time budget for every stitch from Stitch #1 to Stitch #N |
| **Authoritative Input Trigger** | **`PA0` (`TIM2_CH1` Input Capture)** | 1 MHz hardware falling-edge capture latched in silicon (`NVIC Priority 1`, `IC1F=0x3` 8-cycle filter) |
| **Authoritative Output Step** | **`PA8` (`TIM1_CH1` Hardware PWM)** | 1 MHz autonomous hardware PWM Mode 2 burst engine (`5.0 µs` Active-LOW pulse, `NVIC Priority 0`, `8 µs` opto-safe floor) |
| **Direction Output** | **`PA2` (`dirPin`)** | `HIGH` = Normal Forward (`[FW]`), `LOW` = Reverse (`[RV]`), `20 µs` hardware setup/hold guard |
| **Driver Enable Output** | **`PB1` (`motorEnaPin`)** | Permanently `LOW` (Driver Always Active & Stiff) |
| **Microstep Resolution** | **6400 steps/rev Default** | Discrete DM542 DIP table: `400` to `51200` steps/rev |
| **Feed Roller Diameter** | **45.0 mm Default (10.0–100.0 mm)** | Circumference = 141.37 mm; 45.27 pulses per mm at 6400 steps/rev |
| **Default Active Size** | **Size #8 (`currentSize = 2`)** | Machine defaults to Size #8 on factory reset |
| **Default Pulse Baselines** | **#5: `70.0` \| #8: `80.0` \| #10: `100.0`** | Stored in 64-bit `1,000,000x` fixed-point micro-units (`001.0` to `1500.0` pulses) |
| **LCD Display Driver** | **`FastLiquidCrystal_I2C` (`0x27`)** | Zero-blink power-on splash (`NIPON ZIPPER IND` / `DEV: RAJESH SHAH` for `2.0s` at `100 kHz`, runtime `400 kHz`) |
| **Watchdog Protection** | **500 ms Hardware IWDG + Software Sync** | Hardware IWDG = `500 ms` (`PR=0x03, RLR=625`); Software Sync Watchdog armed strictly at `>= 150 RPM` |
| **Flash Memory Persistence** | **True Dual-Slot Ping-Pong EEPROM** | Alternates `Slot 0` (offset 0) $\leftrightarrow$ `Slot 1` (offset 128), pure `V17.1.0` (`0x5A431710UL`) CRC32 validated |

---

## 2. USER MANUAL: COMPLETE OPERATION, 2-TIER SETTINGS & 6-PAGE DIAGNOSTICS

### 2.1 Power-On Boot, 1-Time Guided Calibration & 16x2 LCD Main Screen
1. **Zero-Blink Instant Splash (`0.06s` to `2.06s`):**
   ```text
   Row 1: NIPON ZIPPER IND
   Row 2: DEV: RAJESH SHAH
   ```
2. **Main Operational Screen (`menuState == 0` — Direct Boot, Zero Calibration Gate):**
   ```text
   Row 1: S:8  0000 F:1.77
   Row 2: P:80.0 W:53  [U]
   ```
   - **`S:8 `** → Active Zipper Size (`S:5 `, `S:8 `, or `S:10`).
   - **`0000`** → Displays `0000` at standstill (`0 RPM`) and live 4-digit RPM (`0150..4000`) while running.
   - **`F:1.77`** → Calculated Feed Length in `mm` per stitch.
   - **`P:80.0`** → Active Step Pulse Count.
   - **`W:53 `** → Step Period in `µs` (computed from `Max RPM` clamp) + Notification Bell (`\x01` at column 12: Steady ON at `W = 9 µs` as Early Warning, Blinking at `W <= 8 µs` as Critical Limit; hardware hard clamp strictly at `8 µs` ensuring optocoupler recovery).
   - **`[U]` / `[L]`** → Keypad Unlocked (`[U]`) or Locked (`[L]`).

---

### 2.2 Universal 3-Mode Keypad Controls (3-Button, 6-Button & 4x4 Matrix)

| Action / Gesture on Main Screen (`menuState == 0`) | 3-Button Mode (`[UP]`, `[DOWN]`, `[MODE]`) | 6-Button Mode (`+ [LEFT]`, `[RIGHT]`, `[BACK]`) | 4x4 Matrix Mode (`0..9`, `A..D`, `*`, `#`) |
| :--- | :--- | :--- | :--- |
| **Direct Speed Dial (`88*54# -> 88.50`)** | N/A | N/A | Type **`0..9`**, **`*`** for `.` (Tenths-Only), **`#`** to confirm, **`C`** to clear |
| **Adjust Whole Pulses (`+1.0` / `-1.0`)** | Tap/Hold `[UP]` / `[DOWN]` | Tap/Hold `[UP]` / `[DOWN]` | Tap/Hold **`[A]`** (`+1.0`) / **`[B]`** (`-1.0`) |
| **Enter 4-Digit Watch Inline Editor** | **Single-Click `[MODE]`** | **Single-Click `[MODE]`** or `[LEFT]`/`[RIGHT]` | Press **`*`** (`[MODE]`) or **`[C]`/`[D]`** |
| **Switch Zipper Size (`#5 -> #8 -> #10`)** | **Double-Click `[MODE]`** at `0 RPM` | **Double-Click `[MODE]`** at `0 RPM` | **Double-Click `*`** at `0 RPM` |
| **Open Settings Menu (`menuState = 1`)** | **Hold `[MODE]` for 5 seconds** | **Hold `[MODE]` for 5 seconds** | **Hold `*` for 5 seconds** |
| **Unlock Keypad (`[L]` → `[U]`)** | Press **`[MODE]`**, then **`[DOWN]`** within 3s | Press **`[MODE]`**, then **`[DOWN]`** within 3s | Press **`*`**, then **`[B]`** within 3s |
| **Emergency Factory Reset (`> 10s`)** | Hold **`[UP] + [DOWN]`** for `> 10s` | Hold **`[UP] + [DOWN]`** for `> 10s` | Hold **`[A] + [B]`** for `> 10s` |

---

### 2.3 2-Tier Settings Menu (Level 1: 8 Main Options + Level 2: 5 Advance Options)

#### Level 1: Main User Menu (`menuState == 1` — 7 Options)
1. **`1. Max RPM` (`0100` to `4000 RPM`, Default `3000 RPM`):**
   - 4-digit Digital Watch editor.
   - **Directly controls the step window clamp (`maximumBurstWindowUs`) and `W`.** Changing `Max RPM` immediately updates the clamp and step pulse width.
2. **`2. Motor Dir` (`NORMAL [FW]` $\leftrightarrow$ `REVERSE[RV]`, Default `NORMAL [FW]`):**
   - Toggles stepper motor rotation direction (`PA2`).
3. **`3. Auto Lock` (`Lock: 030s [ON]` $\leftrightarrow$ `Lock: OFF [OFF]`, Range `010..300s`, Default `030s [ON]`):**
   - Cursor 0 toggles `[ON]`/`[OFF]`; Cursors 1..3 edit the 3-digit seconds (`010..300s`).
4. **`4. Backlight` (`ALWAYS ON` or `010..300s`, Default `ALWAYS ON`):**
   - 3-digit timeout (`000s` = `ALWAYS ON`, `010..300s` auto-off). Protected by the **Backlight Wake-Up Shield**.
5. **`5. Diagnostics` (`Open Diagnostics`):**
   - Opens the **Streamlined 5-Page Essential Diagnostics Suite (`menuState == 9`)**.
6. **`6. Advance Menu` (`Open Advance >>`):**
   - Opens the **Level 2 Advance Menu (`menuState == 2`, 5 Machine Geometry Options)**.
7. **`7. Save & Exit` (`Select Save/Exit`):**
   - Opens `SAVE CHANGES? >YES  NO` (`menuState = 13`) to commit changes to Dual-Slot Ping-Pong EEPROM.

#### Level 2: Advance Menu (`menuState == 2` — 5 Clean Options)
1. **`1. Driver Res` (`400` to `51200 steps`, Default `6400 steps`):**
   - 16 discrete DM542 DIP switch resolutions (numeric keys blocked; step with `[UP]`/`[DOWN]` or `[A]`/`[B]`).
2. **`2. Roller Dia` (`010.0` to `100.0 mm`, Default `045.0 mm`):**
   - 4-digit Digital Watch & 4x4 direct numeric editor. Recalculates `#5`, `#8`, `#10` pulse baselines when geometry changes.
3. **`3. Feed Angle` (`030` to `270 deg`, Default `090 deg`):**
   - 3-digit Digital Watch & 4x4 direct numeric editor for cam safe feeding window angle.
4. **`4. Safety Margin` (`00` to `29 %`, Default `15 %`):**
   - 2-digit Digital Watch & 4x4 direct numeric editor for needle clearance cushion percentage.
5. **`5. << Back` (`Return to Main`):**
   - Returns to Level 1 Main User Menu (`7. Advance Menu`).

---

### 2.4 Streamlined 5-Page Essential Diagnostics Suite (`menuState == 9`)

| Page # | LCD Line 1 Title | LCD Line 2 Telemetry / Action | Navigation & Operation |
| :---: | :--- | :--- | :--- |
| **Page 1** | `ACTIVE ISSUE:   ` | `NONE / OPTIMAL  ` *(or `SET RES = 6400` / `MAX RPM <= XXXX` / `FAULT:SYNC LOST!`)* | **Displayed immediately at 0 scrolls!** Shows instant actionable remedy if timing is pushed beyond hardware limits. |
| **Page 2** | `STEPPER JOG TST ` | `UP:FWD   DN:REV ` | Hold **`[UP]`** = Jog Forward (`1.2 kHz`); Hold **`[DOWN]`** = Jog Reverse. Short-click `[MODE]` advances to Page 3. |
| **Page 3** | `OPTO SINK TST   ` | `HOLD [UP] TEST  ` | Hold **`[UP]`** to pull `PA8` (`PUL-`) LOW (`V<=0.5V SINK ON`) for multimeter verification. |
| **Page 4** | `TRIGGER & NOISE ` | `T:14520 O:0  R:0` *(or `FAULT:SYNC LOST!`)* | `T:` Valid Triggers, `O:` `TIM2` Overcaptures, `R:` Rejected Noise Spikes. |
| **Page 5** | `V17.1.0 (NIPON) ` | `DEV: RAJESH SHAH` / `BLD: OCT-2026` | Alternates developer credit and build date every `1.5s`. |

---

## 3. HARDWARE WIRING & SCHEMATIC CONNECTION GUIDE

### 3.1 Authoritative STM32F103C8T6 Pinout Allocation Table

| STM32 Pin | Firmware Symbol | Direction / Peripheral | Electrical Standard | External Hardware Connection |
| :--- | :--- | :--- | :--- | :--- |
| **`PA0`** | `proxSensorPin` | Input (`TIM2_CH1`) | `INPUT_PULLUP` + `IC1F=0x3` Filter | `PC817` Optocoupler Collector (Pin 4) from 24V NPN Proximity Sensor (`LJ12A3-4-Z/BX`) |
| **`PA8`** | `stepPin` | Output (`TIM1_CH1`) | 3.3V Push-Pull / AF PWM Mode 2 | Logic Level Converter `LV1` → `HV1` → DM542 `PUL-` (Active-LOW `5.0 µs` pulse) |
| **`PA2`** | `dirPin` | Output (GPIO) | 3.3V Push-Pull | Logic Level Converter `LV2` → `HV2` → DM542 `DIR-` (`HIGH`=Normal, `LOW`=Reverse) |
| **`PB1`** | `motorEnaPin` | Output (GPIO) | 3.3V Push-Pull | Logic Level Converter `LV3` → `HV3` → DM542 `ENA-` (`LOW`=Enabled/Run, `HIGH`=Sleep) |
| **`PB6`** | `I2C1_SCL` | I2C Clock | 5V-Tolerant Open-Drain (`100/400 kHz`) | 16x2 I2C LCD (`0x27` PCF8574) `SCL` Pin (with `4.7 kΩ` Pull-Up to `+5V`) |
| **`PB7`** | `I2C1_SDA` | I2C Data | 5V-Tolerant Open-Drain (`100/400 kHz`) | 16x2 I2C LCD (`0x27` PCF8574) `SDA` Pin (with `4.7 kΩ` Pull-Up to `+5V`) |
| **`PB12`** | `btnDown` / Row 1 | Input (`INPUT_PULLUP`) | Active-LOW / Matrix Row 1 | 3B/6B **`[DOWN]`** to `GND` \| 4x4 Matrix **Row 1** (`1, 2, 3, A`) |
| **`PB13`** | `btnUp` / Row 2 | Input (`INPUT_PULLUP`) | Active-LOW / Matrix Row 2 | 3B/6B **`[UP]`** to `GND` \| 4x4 Matrix **Row 2** (`4, 5, 6, B`) |
| **`PB14`** | `btnMode` / Row 3 | Input (`INPUT_PULLUP`) | Active-LOW / Matrix Row 3 | 3B/6B **`[MODE]`** to `GND` \| 4x4 Matrix **Row 3** (`7, 8, 9, C`) |
| **`PB15`** | `btnBack` / Row 4 | Input (`INPUT_PULLUP`) | Active-LOW / Matrix Row 4 | 6B **`[BACK]`** to `GND` \| 4x4 Matrix **Row 4** (`*, 0, #, D`) |
| **`PB8`** | `colPin0` | Matrix Strobe / Input | `INPUT_PULLUP` / Low Strobe | 4x4 Matrix **Column 1** (`1, 4, 7, *`) |
| **`PB9`** | `colPin1` | Matrix Strobe / Input | `INPUT_PULLUP` / Low Strobe | 4x4 Matrix **Column 2** (`2, 5, 8, 0`) |
| **`PB10`** | `btnRight` / Col 3 | Input / Matrix Strobe | Active-LOW / Matrix Col 3 | 6B **`[RIGHT]`** to `GND` \| 4x4 Matrix **Column 3** (`3, 6, 9, #`) |
| **`PB11`** | `btnLeft` / Col 4 | Input / Matrix Strobe | Active-LOW / Matrix Col 4 | 6B **`[LEFT]`** to `GND` \| 4x4 Matrix **Column 4** (`A, B, C, D`) |
| **`PC13`** | `statusLedPin` | Output (GPIO) | Active-LOW Onboard LED | Onboard Trigger & Burst Activity Indicator |

---

## 4. COMPLETE COMPONENT BILL OF MATERIALS (BOM)

| Ref | Component Value | Rating / Package | Connected Pin / Net | Function in V17.1.0 Circuit |
| :--- | :--- | :--- | :--- | :--- |
| **R0** | **1.0 kΩ** | 0.25W Metal Film | `+5V` (`HV`) to `HV1` (`PUL-`) | High-speed pull-up on 5V side of Level Converter for crisp rising edges |
| **R1** | **2.2 kΩ** | 0.5W Metal Film | 24V Sensor Output to `PC817` Pin 1 | Current limiter (~10 mA) for 24V proximity sensor into `PC817` optocoupler |
| **R2** | **4.7 kΩ** | 0.25W Metal Film | `+3.3V` to `PA0` (`PC817` Pin 4) | Pull-up resistor for `PA0` (`TIM2_CH1` capture input) |
| **R4, R5** | **4.7 kΩ** | 0.25W Metal Film | `+5V` to `PB6` (`SCL`) & `PB7` (`SDA`) | I2C bus pull-up resistors for 16x2 LCD (`0x27`) |
| **C1, C2** | **100 nF (0.1 µF)** | 50V Ceramic | STM32 `5V`/`3.3V` to `GND` | High-frequency decoupling capacitors close to MCU power pins |
| **C3** | **10 nF (0.01 µF)** | 50V Ceramic | `PA0` to `GND` | Hardware RC low-pass filter (`τ = 47 µs` with `R2`) + `TIM2` `IC1F` digital filter |
| **C4** | **1000 µF / 50V** | Electrolytic | Stepper Driver `+24V/+36V` to `GND` | Bulk DC bus reservoir capacitor to absorb stepper deceleration back-EMF |
| **U1** | **PC817 / EL817** | DIP-4 Optocoupler | Between 24V Sensor & `PA0` | 5000V RMS optical isolation between sewing machine 24V rail and 3.3V MCU |
| **U2** | **4-Ch BSS138 LLC** | Bi-Directional Module | `PA8`/`PA2`/`PB1` (`3.3V` → `5V`) | Shifts 3.3V MCU outputs (`LV1..LV3`) to 5V (`HV1..HV3`) for DM542 driver |

---

## 5. FACTORY PRE-FLIGHT VERIFICATION CHECKLIST (SURAT SHOP FLOOR)

1. **Power-On Splash & Keypad Calibration:** Flip main power switch ON. Verify the 16x2 LCD immediately displays `NIPON ZIPPER IND` / `DEV: RAJESH SHAH` for `2.0 seconds` without blinking. Complete the 1-time Keypad Calibration Gate (`4x4`, `6-Button`, or `3-Button`).
2. **DIP Switch Confirmation:** Confirm DM542 switches match Advance Menu Option 1 (`1. Driver Res = 6400 steps`, SW5=ON, SW6=OFF, SW7=ON, SW8=OFF).
3. **Sensor Air Gap:** Verify inductive proximity sensor gap to cam tooth is **1.0 mm to 1.5 mm**. At standstill (`0 RPM`), rotating the handwheel onto the cam tooth must light the onboard `PC13` LED while the LCD cleanly displays `0000` RPM.
4. **Max RPM Clamp Check (`1. Max RPM`):** Verify that changing `1. Max RPM` in Level 1 Settings immediately updates `W` (`activePulseWidth`) and the step burst clamp window.
5. **Diagnostics Check (`6. Diagnostics`):** Open `6. Diagnostics` → Page 1 immediately shows `ACTIVE ISSUE: / NONE / OPTIMAL` at 0 scrolls; Page 2 tests Forward/Reverse Stepper Jog; Page 3 tests `PA8` Optocoupler Sinking (`V<=0.5V`).

---
*Manual compiled and verified against authoritative V17.1.0 Production Master source code for Nipon Zipper Industries Pvt. Ltd., Sarigam GIDC / Surat, Gujarat.*
