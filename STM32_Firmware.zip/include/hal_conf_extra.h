#ifndef _HAL_CONF_EXTRA_H_
#define _HAL_CONF_EXTRA_H_

/*
 * Nipon Zipper CNC V17.1.0 - STM32F103C6T6 (32KB Flash) Size Optimization
 * Disables unused STM32 HAL peripheral drivers to reduce Flash footprint by ~6 to 10 KB.
 */
#define HAL_ADC_MODULE_DISABLED
#define HAL_RTC_MODULE_DISABLED
#define HAL_SPI_MODULE_DISABLED
#define HAL_DAC_MODULE_DISABLED
#define HAL_CAN_MODULE_DISABLED
#define HAL_ETH_MODULE_DISABLED
#define HAL_SD_MODULE_DISABLED
#define HAL_QSPI_MODULE_DISABLED
#define HAL_PCD_MODULE_DISABLED
#define HAL_WWDG_MODULE_DISABLED

#endif /* _HAL_CONF_EXTRA_H_ */
