#include <cstdint>
#include <cstdio>
#include <cassert>
#include <cstring>
#include <iostream>
#include <string>

// =========================================================================
// TEST SUITE: 4X4 MATRIX KEYPAD & DIRECT NUMERIC DIAL ENGINE (TEST 12)
// Verifies:
// 12a: Direct Dial on Main Screen: "80#" -> 80.00 pulses
// 12b: Direct Dial with Decimal: "80*6#" -> 80.60 pulses
// 12c: Second decimal digit discard: "80*60#" -> 80.60 pulses
// 12d: Hundred pulse entry: "100#" -> 100.00 pulses
// 12e: Tenths rule with discard: "88*54#" -> 88.50 pulses (4 is discarded!)
// 12f: One-Time Factory Auto-Detection with Sense Pin PB0 & EEPROM lock
// =========================================================================

enum KeypadModeType : uint8_t {
    KEYPAD_MODE_3BTN   = 0,
    KEYPAD_MODE_6BTN   = 1,
    KEYPAD_MODE_4X4MAT = 2
};

struct DirectDialParser {
    bool isDirectDialActive = false;
    uint32_t directDialIntPart = 0UL;
    int8_t directDialDecDigit = -1; // -1: no decimal yet, 0..9: tenths digit
    bool directDialHasDecPoint = false;
    uint64_t resultingPulsesFixed = 0ULL;
    bool valueConfirmed = false;

    void reset() {
        isDirectDialActive = false;
        directDialIntPart = 0UL;
        directDialDecDigit = -1;
        directDialHasDecPoint = false;
        valueConfirmed = false;
    }

    void handleKeyPress(char key) {
        if (key >= '0' && key <= '9') {
            if (!isDirectDialActive) {
                isDirectDialActive = true;
                directDialIntPart = key - '0';
                directDialHasDecPoint = false;
                directDialDecDigit = -1;
            } else {
                if (!directDialHasDecPoint) {
                    uint32_t nextVal = directDialIntPart * 10UL + (key - '0');
                    if (nextVal <= 1500UL) {
                        directDialIntPart = nextVal;
                    }
                } else {
                    if (directDialDecDigit < 0) {
                        // First decimal digit: TENTHS (0..9 -> .00 to .90)
                        directDialDecDigit = key - '0';
                    } else {
                        // Second and subsequent decimal digits: STRICTLY DISCARDED!
                        // e.g. '4' in 88*54# or '0' in 80*60# is IGNORED!
                    }
                }
            }
        } else if (key == '*') {
            // Decimal Point (.)
            if (!isDirectDialActive) {
                isDirectDialActive = true;
                directDialIntPart = 0UL;
            }
            directDialHasDecPoint = true;
        } else if (key == '#') {
            // ENTER / CONFIRM
            if (isDirectDialActive) {
                isDirectDialActive = false;
                uint64_t pulses = (uint64_t)directDialIntPart * 1000000ULL;
                if (directDialDecDigit >= 0) {
                    pulses += (uint64_t)directDialDecDigit * 100000ULL;
                }
                resultingPulsesFixed = pulses;
                valueConfirmed = true;
            }
        } else if (key == 'C') {
            // Cancel / Clear
            reset();
        }
    }

    void feedString(const std::string& input) {
        for (char c : input) {
            handleKeyPress(c);
        }
    }
};

int main() {
    std::cout << "============================================================\n";
    std::cout << "RUNNING TEST 12: 4X4 MATRIX & DIRECT NUMERIC DIAL ENGINE\n";
    std::cout << "============================================================\n";

    DirectDialParser parser;

    // Test 12a: "80#" -> 80.00 pulses
    parser.reset();
    parser.feedString("80#");
    assert(parser.valueConfirmed == true);
    assert(parser.resultingPulsesFixed == 80000000ULL);
    std::cout << "[PASS] Test 12a: '80#' -> 80.00 pulses (" << parser.resultingPulsesFixed << " fixed)\n";

    // Test 12b: "80*6#" -> 80.60 pulses
    parser.reset();
    parser.feedString("80*6#");
    assert(parser.valueConfirmed == true);
    assert(parser.resultingPulsesFixed == 80600000ULL);
    std::cout << "[PASS] Test 12b: '80*6#' -> 80.60 pulses (" << parser.resultingPulsesFixed << " fixed)\n";

    // Test 12c: "80*60#" -> 80.60 pulses (second 0 discarded)
    parser.reset();
    parser.feedString("80*60#");
    assert(parser.valueConfirmed == true);
    assert(parser.resultingPulsesFixed == 80600000ULL);
    std::cout << "[PASS] Test 12c: '80*60#' -> 80.60 pulses (second 0 discarded)\n";

    // Test 12d: "100#" -> 100.00 pulses
    parser.reset();
    parser.feedString("100#");
    assert(parser.valueConfirmed == true);
    assert(parser.resultingPulsesFixed == 100000000ULL);
    std::cout << "[PASS] Test 12d: '100#' -> 100.00 pulses (" << parser.resultingPulsesFixed << " fixed)\n";

    // Test 12e: "88*54#" -> 88.50 pulses (4 discarded)
    parser.reset();
    parser.feedString("88*54#");
    assert(parser.valueConfirmed == true);
    assert(parser.resultingPulsesFixed == 88500000ULL);
    std::cout << "[PASS] Test 12e: '88*54#' -> 88.50 pulses (4 is discarded!)\n";

    // Test 12f: One-Time Factory Auto-Detection with Sense Pin PB0 & EEPROM lock
    // Scenario 1: PB0 == LOW (Resistor/Jumper to GND on 6-Button harness)
    bool pb0_low = true;
    bool eeprom_locked = false;
    uint8_t mode = KEYPAD_MODE_3BTN;

    if (!eeprom_locked) {
        if (pb0_low) {
            mode = KEYPAD_MODE_6BTN;
            eeprom_locked = true;
        }
    }
    assert(mode == KEYPAD_MODE_6BTN);
    assert(eeprom_locked == true);
    std::cout << "[PASS] Test 12f-1: PB0 LOW -> 6-BTN instantly locked in EEPROM\n";

    // Scenario 2: Normal Daily Boot with EEPROM locked
    // Even if signals fluctuate, locked mode is never re-evaluated
    uint8_t daily_boot_mode = mode; // read from EEPROM
    assert(daily_boot_mode == KEYPAD_MODE_6BTN);
    std::cout << "[PASS] Test 12f-2: Daily boot loads locked 6-BTN mode with zero re-detection\n";

    // Scenario 3: Factory Reset / First Boot with PB0 HIGH (3-BTN vs 4X4-MAT)
    eeprom_locked = false;
    bool pb0_high = true; // open
    char first_pressed_source = 'M'; // 'M' = Matrix Column, 'G' = Direct GND
    if (!eeprom_locked && pb0_high) {
        if (first_pressed_source == 'M') {
            mode = KEYPAD_MODE_4X4MAT;
            eeprom_locked = true;
        } else {
            mode = KEYPAD_MODE_3BTN;
            eeprom_locked = true;
        }
    }
    assert(mode == KEYPAD_MODE_4X4MAT);
    assert(eeprom_locked == true);
    std::cout << "[PASS] Test 12f-3: Matrix touch -> 4X4-MAT locked in EEPROM\n";

    std::cout << "============================================================\n";
    std::cout << "ALL TEST 12 SUBTESTS PASSED 100% GREEN!\n";
    std::cout << "============================================================\n";
    return 0;
}
