#include <iostream>
#include <cassert>
#include <cstdint>
#include <cmath>
#include <vector>

// Simulation of the exact V17.0.0 Settings Menu Digital Watch Inline Editor
const int32_t DRIVER_RES_TABLE[] = {
    400, 800, 1000, 1600, 2000, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 20000, 25600, 40000, 51200
};
const uint8_t DRIVER_RES_TABLE_SIZE = sizeof(DRIVER_RES_TABLE) / sizeof(DRIVER_RES_TABLE[0]);

static inline int getDriverResIndex(int32_t res) {
    for (int i = 0; i < (int)DRIVER_RES_TABLE_SIZE; i++) {
        if (DRIVER_RES_TABLE[i] == res) return i;
    }
    return 8; // 6400 default
}

int main() {
    std::cout << "================================================================================" << std::endl;
    std::cout << "  SIMULATION TEST: SETTINGS MENU DIGITAL WATCH INLINE EDITOR & LIMITS           " << std::endl;
    std::cout << "  Firmware: STM32 Zipper CNC V17.0.0 Production                                " << std::endl;
    std::cout << "================================================================================" << std::endl;

    // 1. Test Driver Resolution Discrete Jumps
    int32_t tempDriverRes = 6400;
    int idx = getDriverResIndex(tempDriverRes);
    assert(idx == 8 && DRIVER_RES_TABLE[idx] == 6400);

    // [UP] press: jumps to 8000 -> 10000 -> 12800
    idx++; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 8000);
    idx++; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 10000);
    idx++; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 12800);
    // [DOWN] press: jumps back to 10000 -> 8000 -> 6400
    idx--; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 10000);
    idx--; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 8000);
    idx--; tempDriverRes = DRIVER_RES_TABLE[idx]; assert(tempDriverRes == 6400);
    std::cout << "[PASS] 1. Driver Resolution Discrete DIP Jumps Verified (6400 <-> 12800)." << std::endl;

    // 2. Test Roller Diameter (10.0 to 100.0 mm)
    float tempRollerDia = 45.0f;
    uint8_t settingDigitCursor = 0; (void)settingDigitCursor; // 0: Decimal (.x), 1: Integer (xx.)
    
    // Edit decimal: 45.0 -> 45.1 -> 45.2 -> ... -> 45.9 -> 45.0
    for (int i = 1; i <= 9; i++) {
        int dInt = (int)tempRollerDia;
        int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
        dFrac = (dFrac + 1) % 10;
        tempRollerDia = (float)dInt + ((float)dFrac / 10.0f);
        assert(std::abs(tempRollerDia - (45.0f + (float)i * 0.1f)) < 0.01f);
    }
    // Shift cursor to Integer
    settingDigitCursor = 1;
    // Increment to 100.0 mm
    tempRollerDia = 99.0f;
    int dInt = (int)tempRollerDia;
    int dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
    dInt = dInt + 1;
    if (dInt > 100) dInt = 10;
    tempRollerDia = (float)dInt + ((float)dFrac / 10.0f);
    assert(tempRollerDia == 100.0f);
    // Wrap at 100 -> 10
    dInt = (int)tempRollerDia;
    dFrac = (int)((tempRollerDia - (float)dInt) * 10.0f + 0.5f);
    dInt = dInt + 1;
    if (dInt > 100) dInt = 10;
    tempRollerDia = (float)dInt + ((float)dFrac / 10.0f);
    assert(tempRollerDia == 10.0f);
    std::cout << "[PASS] 2. Roller Diameter Range (10.0 to 100.0 mm) and Decimal Shift Verified." << std::endl;

    // 3. Test Feed Angle (30 to 270 deg)
    int32_t tempFeedAngle = 90;
    // Shift cursor: Tens (0) -> Hundreds (1) -> Units (2)
    settingDigitCursor = 1; // Hundreds
    int h = (tempFeedAngle / 100) % 10;
    int t = (tempFeedAngle / 10) % 10;
    int u = tempFeedAngle % 10;
    h = (h >= 2) ? 0 : (h + 1); // 0 -> 1 (190 deg)
    tempFeedAngle = h * 100 + t * 10 + u;
    assert(tempFeedAngle == 190);
    h = (h >= 2) ? 0 : (h + 1); // 1 -> 2 (290 -> clamped 270 deg)
    tempFeedAngle = h * 100 + t * 10 + u;
    if (tempFeedAngle > 270) tempFeedAngle = 270;
    assert(tempFeedAngle == 270);
    h = 2;
    h = (h >= 2) ? 0 : (h + 1); // 2 -> 0 (090 -> 90 deg)
    tempFeedAngle = h * 100 + t * 10 + u;
    assert(tempFeedAngle == 90);
    std::cout << "[PASS] 3. Feed Angle 3-Digit Digital Watch Editing (30 to 270 deg) Verified." << std::endl;

    // 4. Test Safety Margin (0 to 29 %)
    int32_t tempSafetyMargin = 15;
    settingDigitCursor = 1; // Tens digit
    t = tempSafetyMargin / 10;
    u = tempSafetyMargin % 10;
    // Tens digit cycles: 1 -> 2 -> 0 -> 1 (Never 3, 4, 5!)
    t = (t >= 2) ? 0 : (t + 1); assert(t == 2);
    tempSafetyMargin = t * 10 + u; assert(tempSafetyMargin == 25);
    t = (t >= 2) ? 0 : (t + 1); assert(t == 0);
    tempSafetyMargin = t * 10 + u; assert(tempSafetyMargin == 5);
    t = (t >= 2) ? 0 : (t + 1); assert(t == 1);
    tempSafetyMargin = t * 10 + u; assert(tempSafetyMargin == 15);
    std::cout << "[PASS] 4. Safety Margin 2-Digit Editing (0 to 29 %, Tens cycles 0->1->2->0) Verified." << std::endl;

    // 5. Test Backlight (0 to 300 sec)
    int32_t tempBacklightSec = 300;
    settingDigitCursor = 1; // Hundreds digit
    h = (tempBacklightSec / 100) % 10;
    t = (tempBacklightSec / 10) % 10;
    u = tempBacklightSec % 10;
    assert(h == 3);
    // In 300s limit: [3]00 wraps to [0]00, never 4 or 5!
    h = (h >= 3) ? 0 : (h + 1);
    tempBacklightSec = h * 100 + t * 10 + u;
    assert(tempBacklightSec == 0); // 000s = ALWAYS ON
    h = (h >= 3) ? 0 : (h + 1);
    tempBacklightSec = h * 100 + t * 10 + u;
    assert(tempBacklightSec == 100);
    h = (h >= 3) ? 0 : (h + 1);
    tempBacklightSec = h * 100 + t * 10 + u;
    assert(tempBacklightSec == 200);
    h = (h >= 3) ? 0 : (h + 1);
    tempBacklightSec = h * 100 + t * 10 + u;
    assert(tempBacklightSec == 300);
    std::cout << "[PASS] 5. Backlight Limit (0 to 300s, [3]00 wraps to [0]00) Verified." << std::endl;

    // 6. Test Motor Sleep (0, 30 to 300 min)
    uint32_t tempMotorSleepMin = 300;
    settingDigitCursor = 1; // Hundreds digit
    h = (int)(tempMotorSleepMin / 100UL) % 10;
    t = (int)(tempMotorSleepMin / 10UL) % 10;
    u = (int)(tempMotorSleepMin % 10UL);
    assert(h == 3);
    // In 300m limit: [3]00 wraps to [0]00, never 4 or 5!
    h = (h >= 3) ? 0 : (h + 1);
    tempMotorSleepMin = (uint32_t)(h * 100 + t * 10 + u);
    assert(tempMotorSleepMin == 0); // 000m = OFF / Always On
    std::cout << "[PASS] 6. Motor Sleep Limit (0 to 300 min, [3]00 wraps to [0]00) Verified." << std::endl;

    std::cout << "================================================================================" << std::endl;
    std::cout << "  ALL SETTINGS DIGITAL WATCH SIMULATION TESTS PASSED (100% GREEN)!              " << std::endl;
    std::cout << "================================================================================" << std::endl;
    return 0;
}
