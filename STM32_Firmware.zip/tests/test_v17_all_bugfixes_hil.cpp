#define HOST_SIMULATION_TEST 1
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstddef>

// Minimal STM32 + Arduino Hardware Mocks for compiling STM32_Zipper_CNC_V17_1_0_Firmware.ino directly
#define HIGH 1
#define LOW  0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define TIMER_INPUT_CAPTURE_FALLING 1

#define PC13 13
#define PA0  0
#define PA8  8
#define PA2  2
#define PB1  1
#define PB13 130
#define PB12 120
#define PB14 140
#define PB15 150
#define PB11 110
#define PB10 100

static uint32_t g_mockMillis = 1000UL;
static uint32_t g_mockMicros = 1000000UL;
inline unsigned long millis() { return g_mockMillis; }
inline unsigned long micros() { return g_mockMicros; }
inline void delay(unsigned long ms) { g_mockMillis += ms; g_mockMicros += ms * 1000UL; }
inline void delayMicroseconds(unsigned int us) { g_mockMicros += us; }

template <typename T, typename A, typename B>
inline T constrain(T x, A a, B b) {
    if (x < (T)a) return (T)a;
    if (x > (T)b) return (T)b;
    return x;
}

static int g_pinStates[256];
static int g_pinModes[256];
inline void pinMode(int pin, int mode) { if (pin >= 0 && pin < 256) g_pinModes[pin] = mode; }
inline void digitalWrite(int pin, int val) { if (pin >= 0 && pin < 256) g_pinStates[pin] = val; }
extern int g_matrixRowConnected;
extern int g_matrixColConnected;
inline int digitalRead(int pin) {
    if (pin >= 0 && pin < 256) {
        if (pin == g_matrixRowConnected && g_matrixColConnected >= 0 &&
            g_pinModes[g_matrixColConnected] == OUTPUT && g_pinStates[g_matrixColConnected] == LOW) {
            return LOW;
        }
        return g_pinStates[pin];
    }
    return HIGH;
}

static uint32_t g_primask = 0;
inline uint32_t __get_PRIMASK() { return g_primask; }
inline void __disable_irq() { g_primask = 1; }
inline void __set_PRIMASK(uint32_t p) { g_primask = p; }

enum IRQn_Type { TIM1_UP_IRQn = 25, TIM2_IRQn = 28, SysTick_IRQn = -1 };
inline void NVIC_SetPriority(IRQn_Type, uint32_t) {}
inline void NVIC_ClearPendingIRQ(IRQn_Type) {}
inline void NVIC_EnableIRQ(IRQn_Type) {}

struct GPIO_TypeDef { volatile uint32_t CRL, CRH, BSRR, BRR; };
static GPIO_TypeDef g_gpioA{}, g_gpioB{}, g_gpioC{};
#define GPIOA (&g_gpioA)
#define GPIOB (&g_gpioB)
#define GPIOC (&g_gpioC)

struct IWDG_TypeDef { volatile uint32_t KR, PR, RLR; };
static IWDG_TypeDef g_iwdg{};
#define IWDG (&g_iwdg)

struct RCC_TypeDef { volatile uint32_t APB1ENR, APB2ENR, CSR; };
static RCC_TypeDef g_rcc{};
#define RCC (&g_rcc)
#define RCC_APB1ENR_TIM2EN (1U << 0)
#define RCC_APB1ENR_TIM4EN (1U << 2)
#define RCC_APB2ENR_TIM1EN (1U << 11)

struct TIM_TypeDef {
    volatile uint32_t CR1, DIER, SR, EGR, CCMR1, CCER, CNT, PSC, ARR, RCR, CCR1, CCR2, BDTR;
};
static TIM_TypeDef g_tim1{}, g_tim2{}, g_tim4{};
#define TIM1 (&g_tim1)
#define TIM2 (&g_tim2)
#define TIM4 (&g_tim4)

#define TIM_CR1_CEN     (1U << 0)
#define TIM_CR1_OPM     (1U << 3)
#define TIM_CR1_ARPE    (1U << 7)
#define TIM_DIER_UIE    (1U << 0)
#define TIM_SR_UIF      (1U << 0)
#define TIM_SR_CC1IF    (1U << 1)
#define TIM_SR_CC1OF    (1U << 9)
#define TIM_EGR_UG      (1U << 0)
#define TIM_CCMR1_CC1S  (3U << 0)
#define TIM_CCMR1_OC1PE (1U << 3)
#define TIM_CCMR1_OC1M  (7U << 4)
#define TIM_CCMR1_IC1F  (0xFU << 4)
#define TIM_CCER_CC1E   (1U << 0)
#define TIM_CCER_CC1P   (1U << 1)
#define TIM_BDTR_MOE    (1U << 15)

class HardwareTimer {
public:
    TIM_TypeDef *inst;
    void (*updateCb)() = nullptr;
    void (*ch1Cb)() = nullptr;
    void (*ch2Cb)() = nullptr;
    HardwareTimer(TIM_TypeDef *t) : inst(t) {}
    void pause() {}
    void resume() {}
    void setPrescaleFactor(uint32_t) {}
    void setOverflow(uint32_t) {}
    void setCount(uint32_t c) { if (inst) inst->CNT = c; }
    void setInterruptPriority(uint32_t, uint32_t) {}
    void setMode(int, int, int) {}
    void attachInterrupt(void (*cb)()) { updateCb = cb; }
    void attachInterrupt(int ch, void (*cb)()) {
        if (ch == 1) ch1Cb = cb;
        else if (ch == 2) ch2Cb = cb;
    }
    uint32_t getCaptureCompare(int ch) {
        if (ch == 2) return inst ? inst->CCR2 : 0;
        return inst ? inst->CCR1 : 0;
    }
};

class TwoWire {
public:
    void begin() {}
    void setClock(uint32_t) {}
    void setTimeout(uint32_t) {}
};
static TwoWire Wire;

class LiquidCrystal_I2C {
public:
    char screen[2][17];
    uint8_t curCol = 0, curRow = 0;
    bool backlightOn = false; // Real LiquidCrystal_I2C constructor starts with _backlightval = LCD_NOBACKLIGHT (0x00)
    bool blinkedOffDuringInit = false;
    uint32_t i2cWriteCount = 0;
    LiquidCrystal_I2C(uint8_t, uint8_t, uint8_t) { clear(); }
    void init() {
        if (!backlightOn) blinkedOffDuringInit = true;
        clear();
    }
    void backlight() { backlightOn = true; }
    void noBacklight() { backlightOn = false; }
    uint8_t customChars[8][8] = {{0}};
    void createChar(uint8_t loc, const uint8_t map[]) { if (loc < 8) std::memcpy(customChars[loc], map, 8); }
    void clear() {
        std::memset(screen[0], ' ', 16); screen[0][16] = '\0';
        std::memset(screen[1], ' ', 16); screen[1][16] = '\0';
    }
    void setCursor(uint8_t c, uint8_t r) { curCol = c; curRow = r; }
    void print(const char *s) {
        if (!s || curRow > 1) return;
        i2cWriteCount++;
        while (*s && curCol < 16) {
            screen[curRow][curCol++] = *s++;
        }
        screen[curRow][16] = '\0';
    }
};

class EEPROMClass {
public:
    uint8_t mem[512];
    uint32_t putCount = 0;
    EEPROMClass() { std::memset(mem, 0xFF, sizeof(mem)); }
    template <typename T>
    void get(int addr, T &val) {
        std::memcpy(&val, &mem[addr], sizeof(T));
    }
    template <typename T>
    void put(int addr, const T &val) {
        std::memcpy(&mem[addr], &val, sizeof(T));
        putCount++;
    }
};
static EEPROMClass EEPROM;

// Include the authoritative V17.1.0 sketch directly
#include "STM32_Zipper_CNC_V17_1_0_Firmware.ino"

static inline void syncTim4Hardware() {
    TIM4->CNT = (uint16_t)(g_mockMicros & 0xFFFF);
    tim4_overflow_count = g_mockMicros >> 16;
    TIM2->CNT = (uint16_t)(g_mockMicros & 0xFFFF);
    tim2OverflowCount = g_mockMicros >> 16;
}

static void stepLoop(uint32_t advanceMs = 25) {
    g_mockMillis += advanceMs;
    g_mockMicros += advanceMs * 1000UL;
    syncTim4Hardware();
    loop();
}

static inline void advanceTimeUs(uint32_t us) {
    g_mockMicros += us;
    g_mockMillis = g_mockMicros / 1000UL;
    syncTim4Hardware();
}

static void initButtonsIdle() {
    for (int i = 0; i < 256; i++) g_pinStates[i] = HIGH;
}

// Override digitalWrite/digitalRead to support 4x4 matrix crosspoint simulation
int g_matrixRowConnected = -1;
int g_matrixColConnected = -1;

static void tapMatrixKey(int rowPin, int colPin, uint32_t holdMs = 60) {
    // During scan4x4MatrixKey(), when colPin is driven LOW, rowPin reads LOW
    g_matrixRowConnected = rowPin;
    g_matrixColConnected = colPin;
    stepLoop(25);
    stepLoop(holdMs);
    g_matrixRowConnected = -1;
    g_matrixColConnected = -1;
    stepLoop(25);
}

static void tapButton(int pin, uint32_t holdMs = 60) {
    g_pinStates[pin] = LOW;
    stepLoop(25);
    stepLoop(holdMs);
    g_pinStates[pin] = HIGH;
    stepLoop(25);
}

int main() {
    initButtonsIdle();
    syncTim4Hardware();
    setup();

    std::printf("==================================================================\n");
    std::printf("  V17.1.0 CHATGPT AUDIT FINDINGS RESOLUTION & HIL VERIFICATION    \n");
    std::printf("==================================================================\n");

    // -------------------------------------------------------------------------
    // TEST 1: Finding 3 Fix — True Dual-Slot Ping-Pong EEPROM Save
    // -------------------------------------------------------------------------
    loadFactoryDefaults();
    activeEEPROMSlot = 0;
    eepromSeqNumber  = 10;
    autoLockSec = 45UL;
    assert(saveToEEPROM() == true);
    assert(activeEEPROMSlot == 1U);
    assert(eepromSeqNumber == 11U);

    autoLockSec = 60UL;
    assert(saveToEEPROM() == true);
    assert(activeEEPROMSlot == 0U);
    assert(eepromSeqNumber == 12U);

    std::memset(&EEPROM.mem[128], 0x00, 64);
    loadFromEEPROM();
    assert(activeEEPROMSlot == 0U);
    assert(autoLockSec == 60UL);
    std::printf("[PASS] Finding 3 Fixed: True Dual-Slot Ping-Pong EEPROM strictly alternates slots (0 <-> 1) with 100%% power-loss recovery.\n");

    // -------------------------------------------------------------------------
    // TEST 2: Finding 1 Fix — Anti-Lump FIFO Queue & Instant Save-Abort on Trigger
    // -------------------------------------------------------------------------
    flashSaveTx.reset();
    assert(flashSaveTx.requestSaveLock() == true);
    assert(flashSaveTx.isSaveLockActive() == true);

    flashSaveTx.deferTrigger(80, 0, 100000UL);
    flashSaveTx.deferTrigger(80, 0, 120000UL);
    flashSaveTx.deferTrigger(100, 0, 140000UL);
    assert(flashSaveTx.deferredTriggerCount == 3);

    uint8_t outDir = 0;
    uint32_t outTs = 0;
    uint32_t t1 = flashSaveTx.captureDeferredForDispatch(outDir, outTs);
    assert(t1 == 80 && outTs == 100000UL);
    uint32_t t2 = flashSaveTx.captureDeferredForDispatch(outDir, outTs);
    assert(t2 == 80 && outTs == 120000UL);
    uint32_t t3 = flashSaveTx.captureDeferredForDispatch(outDir, outTs);
    assert(t3 == 100 && outTs == 140000UL);
    uint32_t t4 = flashSaveTx.captureDeferredForDispatch(outDir, outTs);
    assert(t4 == 0);
    flashSaveTx.completeHandoff();
    assert(flashSaveTx.lockState == SAVE_LOCK_IDLE);

    // Also verify Instant Save-Abort when a real PA0 trigger arrives during acquiring save lock:
    flashSaveTx.reset();
    flashSaveTx.requestSaveLock();
    hwBurstActive = false;
    advanceTimeUs(25000UL);
    processSensorTrigger(get_hardware_timestamp_us());
    assert(flashSaveTx.lockState == SAVE_LOCK_IDLE); // Save aborted in 0 us!
    assert(hwBurstActive == true);                   // Real-time TIM1 burst fired immediately!
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    std::printf("[PASS] Finding 1 Fixed: Instant Save-Abort on Trigger & Zero-Latency TIM1 Direct Register Burst Verified.\n");

    // -------------------------------------------------------------------------
    // TEST 3: Finding 2 Fix — Queue Saturation & Timing Overrun Detection
    // -------------------------------------------------------------------------
    hwBurstActive = true;
    isTimingOverrun = false;
    uint32_t rejBefore = rejectedTriggerCount;

    while (burstQueue.enqueue(50, 0, 1000, 1, 20, 20 << 16)) {}

    startHardwareTimerBurst(50, 20, 20 << 16);
    assert(rejectedTriggerCount == rejBefore + 1);
    assert(isTimingOverrun == true);

    stepLoop(25);
    assert(uiBannerLine1 != nullptr && std::strncmp(uiBannerLine1, "ERR: TIMING OVRN", 16) == 0);
    burstQueue.abortAll();
    hwBurstActive = false;
    movementState = STATE_IDLE;
    std::printf("[PASS] Finding 2 Fixed: Burst queue saturation immediately triggers rejectedTriggerCount++ and ERR: TIMING OVRN.\n");

    // -------------------------------------------------------------------------
    // TEST 4: Finding 4 Fix — Real Motion Sync Watchdog Implementation
    // -------------------------------------------------------------------------
    lastTriggerMicros = 0UL;
    lastMeasuredIntervalUs = 0UL;
    currentRPM = 0UL;
    motionWatchdogArmed = false;
    isMotionSyncLost = false;

    for (int i = 0; i < 6; i++) {
        advanceTimeUs(25000UL);
        processSensorTrigger(get_hardware_timestamp_us());
        stepLoop(5);
    }
    assert(motionWatchdogArmed == true);
    assert(currentRPM >= 1000UL);
    assert(isMotionSyncLost == false);

    advanceTimeUs(30000UL);
    stepLoop(5);
    assert(isMotionSyncLost == false);

    advanceTimeUs(45000UL);
    stepLoop(5);
    assert(isMotionSyncLost == true);
    assert(faultType == 3);

    uiBannerLine1 = nullptr;
    uiBannerLine2 = nullptr;
    menuState = 9;
    infoIndex = 4;
    oldMenuState = -1;
    stepLoop(150);
    assert(std::strncmp(lcd.screen[1], "FAULT:SYNC LOST!", 16) == 0);

    // Verify 150 RPM Handwheel Threshold: at 100 RPM (< 150 RPM), Motion Watchdog is 100% muted!
    isMotionSyncLost = false;
    currentRPM = 100UL;
    lastMeasuredIntervalUs = 600000UL;
    lastTriggerMicros = get_hardware_timestamp_us();
    advanceTimeUs(1600000UL); // > 2.5x interval, but RPM < 150
    stepLoop(5);
    assert(isMotionSyncLost == false);

    advanceTimeUs(25000UL);
    processSensorTrigger(get_hardware_timestamp_us());
    assert(isMotionSyncLost == false);
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    std::printf("[PASS] Finding 4 Fixed: Real Motion Sync Watchdog accurately trips isMotionSyncLost=true at 2.5x interval and clears on resume.\n");

    // -------------------------------------------------------------------------
    // TEST 5: Auto-Lock ON/OFF Feature & 6-Button Navigation
    // -------------------------------------------------------------------------
    menuState = 1;
    hiddenOption = 3; // Level 1 Option 3: Auto Lock
    isEditingSetting = true;
    settingDigitCursor = 0;
    tempAutoLockSec = 30UL;
    tapButton(btnUp, 60);
    assert(tempAutoLockSec == 0UL);
    tapButton(btnUp, 60);
    assert(tempAutoLockSec == 30UL);
    std::printf("[PASS] Auto-Lock ON/OFF Feature Verified.\n");

    // -------------------------------------------------------------------------
    // TEST 6: Zero-Blink Power-On LCD Backlight & Guaranteed 2.2s Splash Screen
    // -------------------------------------------------------------------------
    lcd.backlightOn = false;
    lcd.blinkedOffDuringInit = false;
    // Simulate cold power-on even with sticky IWDGRSTF + PORRSTF and spurious PA0 trigger count
    RCC->CSR = (1U << 29) | (1U << 27);
    validTriggerCount = 5UL;
    uint32_t bootStartMs = g_mockMillis;
    setup();
    uint32_t bootElapsedMs = g_mockMillis - bootStartMs;
    assert(lcd.blinkedOffDuringInit == false);
    assert(lcd.backlightOn == true);
    assert(bootElapsedMs >= 2000UL);
    assert(std::strncmp(lcd.screen[0], "NIPON ZIPPER IND", 16) == 0);
    assert(std::strncmp(lcd.screen[1], "DEV: RAJESH SHAH", 16) == 0);
    assert(IWDG->PR == 0x03U && IWDG->RLR == 625U); // 500ms Hardware IWDG verified
    assert(validTriggerCount == 0UL);
    assert(lastTriggerMicros == 0UL);
    assert(lastMeasuredIntervalUs == 0UL);
    assert(acceptedTriggerPulses == 0UL);
    assert(currentRPM == 0UL);
    assert(movementState == STATE_IDLE);

    // Verify Direct Real-Time `diff` StepPulse Calculation (Zero median3u32 Lag on Deceleration):
    // Run 3 fast revolutions at 20,000 us (3000 RPM), then decelerate to 35,000 us (~1714 RPM).
    // StepPulse period must immediately reflect 35,000 us (not the 20,000 us median of the prior 3!).
    for (int i = 0; i < 4; i++) {
        advanceTimeUs(20000UL);
        stopHardwareTimerImmediately();
        movementState = STATE_IDLE;
        processSensorTrigger(get_hardware_timestamp_us());
    }
    uint32_t fastPeriodQ16 = servoPeriodQ16;
    advanceTimeUs(35000UL);
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    processSensorTrigger(get_hardware_timestamp_us());
    assert(servoLastIntervalUs == 35000UL);
    assert(servoPeriodQ16 == calculateAdaptiveStepPeriodQ16(35000UL, 80U));
    assert(servoPeriodQ16 >= fastPeriodQ16);
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    // Verify MODE 5-second long press on Main Screen opens Settings Menu (menuState == 1)
    menuState = 0;
    isUiLocked = false;
    currentRPM = 0UL;
    stepsRemaining = 0;
    hwBurstActive = false;
    digitalWrite(btnMode, LOW);
    for (int i = 0; i < 210; i++) stepLoop(25); // Hold MODE for 5.25 seconds
    assert(menuState == 1);
    assert(hiddenOption == 1);
    assert(isEditingSetting == false);
    digitalWrite(btnMode, HIGH);
    stepLoop(50);
    assert(menuState == 1);
    assert(hiddenOption == 1);
    assert(isEditingSetting == false);
    std::printf("[PASS] Power-On Zero-Blink Backlight, 2.0s Splash Screen & 5s MODE Long-Press Settings Launch Verified.\n");

    // -------------------------------------------------------------------------
    // TEST 7: 2-Tier Settings Menu (Level 1: 8 Options, Level 2: 7 Options),
    //         6-Page Diagnostics, 4x4 Direct Speed Dial & Sleep Wake-Up Shield
    // -------------------------------------------------------------------------
    // Level 1 Option 1: Max RPM (6-BTN Mode)
    keypad6ButtonMode = true;
    keypadMode = 1U;
    menuState = 1;
    hiddenOption = 1;
    isEditingSetting = false;
    tapButton(btnMode, 60);
    stepLoop(400); // Single-click MODE enters edit on Option 1 (Max RPM)
    assert(isEditingSetting == true && settingDigitCursor == 0);
    tapButton(btnRight, 60);
    assert(settingDigitCursor == 1);
    tapButton(btnLeft, 60);
    assert(settingDigitCursor == 0);
    tapButton(btnMode, 60);
    assert(isEditingSetting == false);

    // Navigate Level 1 Options 1..6 -> Open Option 6 (6-Page Diagnostics)
    keypad6ButtonMode = false;
    keypadMode = 0U;
    for (int opt = 2; opt <= 6; opt++) {
        tapButton(btnDown, 60);
        assert(hiddenOption == opt);
    }
    tapButton(btnMode, 60);
    stepLoop(400);
    assert(menuState == 9 && infoIndex == 1); // Page 1: ACTIVE ISSUE (0 scrolls!)
    tapButton(btnDown, 60);
    assert(infoIndex == 2); // Page 2: STEPPER JOG TST
    tapButton(btnMode, 60); // Short-click MODE on Page 2 advances to Page 3 (OPTO SINK TST)
    assert(infoIndex == 3);
    for (int p = 4; p <= 6; p++) {
        tapButton(btnDown, 60);
        assert(infoIndex == p);
    }
    tapButton(btnMode, 60); // Return to Level 1 Settings Menu
    assert(menuState == 1);

    // Open Option 7 (Advance Menu -> menuState == 2)
    tapButton(btnDown, 60);
    assert(hiddenOption == 7);
    tapButton(btnMode, 60);
    stepLoop(400);
    assert(menuState == 2 && advanceOption == 1); // Advance Option 1: Driver Res

    // Test Driver Res discrete DIP step in Advance Menu
    tapButton(btnMode, 60);
    stepLoop(400);
    assert(isEditingSetting == true);
    int32_t origRes = tempDriverRes;
    tapButton(btnUp, 60);
    assert(tempDriverRes > origRes);
    tapButton(btnDown, 60);
    assert(tempDriverRes == origRes);
    tapButton(btnMode, 60);
    assert(isEditingSetting == false);

    // Scroll to Advance Option 7 (<< Back) and return to Level 1
    for (int a = 2; a <= 7; a++) {
        tapButton(btnDown, 60);
        assert(advanceOption == a);
    }
    tapButton(btnMode, 60);
    stepLoop(400);
    assert(menuState == 1 && hiddenOption == 7);

    // Option 8: Save & Exit -> returns to Main Screen (menuState == 0)
    tapButton(btnDown, 60);
    assert(hiddenOption == 8);
    tapButton(btnMode, 60);
    stepLoop(400);
    assert(menuState == 13 && saveExitChoice == true);
    tapButton(btnMode, 60);
    assert(menuState == 0);
    std::printf("[PASS] 2-Tier Settings Menu (8 Main + 7 Advance) & 6-Page Diagnostics Verified (3-BTN, 6-BTN & 4x4).\n");

    // -------------------------------------------------------------------------
    // TEST 8: Main Screen DOWN Hold Auto-Repeat, Backlight Timeout & Motor Sleep Wake ISR
    // -------------------------------------------------------------------------
    currentPulsesFixed = 80000000ULL;
    isEditingMainDecimal = false;
    isUiLocked = false;
    // Hold DOWN for 1.1 seconds -> initial tap (-1.0) + 3 auto-repeat steps (-3.0)
    digitalWrite(btnDown, LOW);
    for (int i = 0; i < 45; i++) stepLoop(25);
    digitalWrite(btnDown, HIGH);
    stepLoop(25);
    assert(currentPulsesFixed < 78000000ULL);
    assert(menuState == 0); // Never enters Settings on DOWN hold!

    // Motor Sleep (20-Minute Minimum Limit) & Sleep Wake-Up Shield Verification
    motorSleepMin = 20UL;
    backlightSec  = 30;
    currentRPM = 0UL;
    stepsRemaining = 0;
    hwBurstActive = false;
    stepLoop(21UL * 60000UL);
    assert(isMotorCurrentlyAsleep == true);
    assert(isBacklightCurrentlyOn == false);
    // Sleep Wake-Up Shield: pressing UP while screen is OFF and motor is asleep MUST wake both
    // into Active Standby and consume that 1st button press (pulse count MUST NOT change!)
    uint64_t pulsesBeforeWakePress = currentPulsesFixed;
    tapButton(btnUp, 60);
    assert(isMotorCurrentlyAsleep == false);
    assert(isBacklightCurrentlyOn == true);
    assert(currentPulsesFixed == pulsesBeforeWakePress); // 1st press consumed by Sleep Wake-Up Shield!
    backlightSec = 0;
    // Now put motor back to sleep and test 1-Cycle Hardware Pedal Trigger Wake:
    stepLoop(21UL * 60000UL);
    assert(isMotorCurrentlyAsleep == true);
    assert(captureTimer->ch1Cb == tim2WakeOnceCallback);
    // Simulate PA0 trigger while asleep -> wakes motor in 1 cycle and fires burst!
    TIM2->CCR1 = 5000U;
    TIM2->CNT  = 5005U;
    captureTimer->ch1Cb();
    assert(isMotorCurrentlyAsleep == false);
    assert(captureTimer->ch1Cb == tim2HardwareCaptureCallback);
    assert(hwBurstActive == true);
    stopHardwareTimerImmediately();
    motorSleepMin = 0UL;
    std::printf("[PASS] Main Screen DOWN Hold Auto-Repeat & Motor Sleep 1-Cycle Hardware Wake ISR Verified.\n");

    // -------------------------------------------------------------------------
    // TEST 9: 5-Point Surgical Audit Verification (Diag <8us, >=1000.0 LCD,
    //         pulseFracAccumulator Reset on Change, Zero-Flicker Auto-Lock,
    //         Cold-Boot Splash TIM2 Masking & Untouched TIM1 PWM Mode 2)
    // -------------------------------------------------------------------------
    // 9a. Diagnostics Page 7 threshold < 8 us (e.g. 7 us triggers warning)
    tempDriverRes = 40000;
    tempRollerDia = 45.0f;
    tempMaxRPM = 3000;
    tempFeedAngle = 90;
    tempSafetyMargin = 15;
    evaluateDiagnostics();
    assert(diagMinW < 8);
    assert(isTimingWarningActive == true);
    assert(diagFixLine1 != nullptr && diagFixLine2 != nullptr);

    // 9b. Main Screen >= 1000.0 pulse display without % 1000 wrap-around
    loadFactoryDefaults();
    autoSaveEngine.clearPendingSave();
    syncStoredBaselinesWithRam();
    uiBannerLine1 = nullptr;
    uiBannerLine2 = nullptr;
    currentPulsesFixed = 1234500000ULL; // 1234.5 steps
    updateActivePulseWidth();
    menuState = 0;
    oldMenuState = -1;
    currentRPM = 0UL;
    stepLoop(150);
    assert(std::strncmp(lcd.screen[1], "P:1234.5", 8) == 0);

    // 9c. pulseFracAccumulator resets on parameter change, stays intact on identical commit
    pulseFracAccumulator = 750000UL;
    commitPulseParameters(currentPulsesInt, currentPulsesFrac); // Same params -> must NOT reset!
    assert(pulseFracAccumulator == 750000UL);
    commitPulseParameters(currentPulsesInt + 1U, currentPulsesFrac); // Changed params -> MUST reset to 0!
    assert(pulseFracAccumulator == 0UL);

    // 9d. Auto-Lock 30s does NOT reset oldMenuState = -1 (zero lcd.clear() motion flicker)
    isUiLocked = false;
    autoLockSec = 30UL;
    menuState = 0;
    oldMenuState = 0;
    lastUnlockActivity = g_mockMillis;
    currentRPM = 2400UL;
    hwBurstActive = false;
    stepLoop(31000UL);
    assert(isUiLocked == true);
    assert(oldMenuState == 0); // Must stay 0 (never -1)!
    assert(std::strncmp(&lcd.screen[1][13], "[L]", 3) == 0);

    // 9e. Verify TIM1 PWM Mode 2 (0x7) is 100% preserved and TIM2 CC1IE is armed after setup()
    assert(((TIM1->CCMR1 >> 4) & 0x7U) == 0x7U);
    assert((TIM2->DIER & TIM_DIER_CC1IE) != 0U);
    std::printf("[PASS] 5-Point Surgical Audit Fixes & Untouched TIM1 PWM Mode 2 Verified.\n");

    // -------------------------------------------------------------------------
    // TEST 10: Cam Gap 300-Degree Startup Speed & 2.0s Standstill Accumulator Reset
    // -------------------------------------------------------------------------
    // 10a. Normal Startup with Preceding Rising Edge (Light OFF) then Falling Edge (Light ON):
    // 300 deg gap traversed in 33,333 us => exact 1500 RPM startup calculation!
    loadFactoryDefaults();
    refreshPulseTimingValidity();
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    lastTriggerMicros = 0UL;
    hasValidRisingEdge = false;
    lastRisingEdgeCaptureUs = 0UL;
    startupMeasuredRpm = 0UL;

    advanceTimeUs(100000UL); // Standstill elapsed
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb(); // Rising edge (Light OFF)
    assert(hasValidRisingEdge == true);

    advanceTimeUs(33333UL); // Exactly 300 deg at 1500 RPM
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Falling edge (Light ON -> 1st Stitch Trigger!)
    assert(startupMeasuredRpm >= 1495UL && startupMeasuredRpm <= 1505UL);
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;

    // 10b. Boundary / Direct Falling Edge Start (without preceding Rising Edge):
    // Must safely fall back to maxRPMSetting without crash or error
    hasValidRisingEdge = false;
    lastRisingEdgeCaptureUs = 0UL;
    startupMeasuredRpm = 0UL;
    lastTriggerMicros = 0UL;
    maxRPMSetting = 2800;

    advanceTimeUs(100000UL);
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Direct falling edge
    assert(startupMeasuredRpm == 0UL); // No rising edge -> no gap calculated
    assert(hwBurstActive == true);      // Stepper burst successfully fired via safe fallback!
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    maxRPMSetting = 3000;

    // 10c. Standstill (>2.0s) Fractional Accumulator Reset Verification:
    pulseFracAccumulator = 650000UL; // Simulate leftover fractional residue from prior piece
    advanceTimeUs(2100000UL);        // 2.1 seconds standstill (tape/coil change)
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb();          // 1st edge of new piece
    assert(pulseFracAccumulator == 0UL); // Clean baseline zero reset verified!
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
        // 10d. Hand-Crank Cam Setting to Pedal Start within 0.8s (<2.0s Human Pause Race Condition):
    // Operator hand-turns wheel to park cam (Falling Edge at t=100,000 us), then pauses for 800 ms.
    // Under old code, diff = 833,333 us (<2.0s) was misclassified as 75 RPM continuous sewing!
    // With new Human Pause Standstill Detection, it correctly recognizes the pause, resets accumulator,
    // and fires Stitch #1 synchronized to the measured 1500 RPM from the 300-deg gap!
    loadFactoryDefaults();
    refreshPulseTimingValidity();
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    lastTriggerMicros = 0UL;
    hasValidRisingEdge = false;
    lastRisingEdgeCaptureUs = 0UL;
    startupMeasuredRpm = 0UL;

    // Hand-turn parks cam with Light ON (Falling edge):
    advanceTimeUs(100000UL);
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Hand crank stitch
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    pulseFracAccumulator = 700000UL; // Leftover residue after hand turn

    // Operator pauses 800 ms (0.8s, well under 2.0s), then steps on pedal!
    advanceTimeUs(800000UL);
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb(); // Motor starts rotating -> Light turns OFF!
    assert(hasValidRisingEdge == true);

    // Motor crosses 300 deg gap in 33,333 us (1500 RPM):
    advanceTimeUs(33333UL);
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Light turns ON -> 1st Stitch of motor run!

    // Assert that the 833 ms pause was caught, accumulator was reset, and 1500 RPM was used:
    assert(pulseFracAccumulator == 0UL);
    assert(startupMeasuredRpm >= 1495UL && startupMeasuredRpm <= 1505UL);
    assert(hwBurstActive == true);
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    std::printf("[PASS] Hand-Crank Cam Setting to Pedal Start (0.8s Pause) Race Condition Fixed & Verified.\n");

    // 10e. Option 11 Cam Gap Deg LCD Editing & EEPROM Persistence Verification:
    loadFactoryDefaults();
    assert(camGapAngleDeg == 300UL);
    menuState = 2;
    advanceOption = 6; // Level 2 Option 6: Cam Gap Deg
    isEditingSetting = true;
    settingDigitCursor = 1; // Hundreds
    tempCamGapAngle = 300UL;
    tapButton(btnUp, 60); // 300 -> 030 (Hundreds wrapped 3 -> 0, clamped to 30)
    assert(tempCamGapAngle == 30UL);
    tapButton(btnUp, 60); // 030 -> 130
    assert(tempCamGapAngle == 130UL);
    camGapAngleDeg = tempCamGapAngle;
    assert(saveToEEPROM() == true);
    
    // Reboot / reload from EEPROM to verify persistence & backward migration
    loadFromEEPROM();
    assert(camGapAngleDeg == 130UL);
    assert(activeEEPROMSlot == 1U || activeEEPROMSlot == 0U);
    loadFactoryDefaults();
    saveToEEPROM();
    menuState = 0;
    isEditingSetting = false;
    std::printf("[PASS] Option 11 Cam Gap Deg LCD Editing & EEPROM Persistence Verified.\n");

    std::printf("[PASS] Cam Gap 300-Degree Startup Speed & 2.0s Standstill Accumulator Reset Verified.\n");

    // ------------------------------------------------------------------
    // TEST 11: 2-Tier Proactive Stop Invalidation (loop() + Backup ISR),
    //          V17.1.0 -> V17.1.0 EEPROM Selective-Save Upgrade,
    //          and Instant 0->3000 RPM Servo Jump & Needle Sync Safety
    // ------------------------------------------------------------------
    std::printf("-> Running Test 11: Proactive Stop Invalidation, V17.1.0->V17.1.0 EEPROM Upgrade & 3000 RPM Sync...\n");
    loadFactoryDefaults();
    refreshPulseTimingValidity();
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    lastTriggerMicros = 0UL;
    hasValidRisingEdge = false;
    lastRisingEdgeCaptureUs = 0UL;
    startupMeasuredRpm = 0UL;

    // 11a. Proactive Stop Invalidation directly in loop() at >400 ms idle:
    // Simulate a sewing stitch followed by a stop where Light went OFF during coast-down
    advanceTimeUs(100000UL);
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb(); // Rising edge before falling edge
    advanceTimeUs(20000UL);
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Falling edge (Stitch #1)
    loop(); // Let loop() see acceptedTriggerPulses advance and arm proactiveStopInvalidated = false
    // Simulate step completion:
    while (hwBurstActive) {
        advanceTimeUs(TIM1->ARR + 1UL);
        stepTimer->updateCb();
    }
    // Simulate motor coasting slightly so Light goes OFF 10ms after falling edge, then stopping:
    advanceTimeUs(10000UL);
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb();
    pulseFracAccumulator = 550000UL;
    startupMeasuredRpm = 1500UL;
    assert(hasValidRisingEdge == true);

    // Advance 450 ms (>400 ms idle threshold) and run loop():
    // BEFORE any next trigger arrives, loop() MUST proactively invalidate accumulator, edge flag, and old RPM!
    advanceTimeUs(450000UL);
    loop();
    assert(pulseFracAccumulator == 0UL);
    assert(hwBurstPeriodFrac == 0UL);
    assert(startupMeasuredRpm == 0UL);
    assert(hasValidRisingEdge == false);
    assert(lastRisingEdgeCaptureUs == 0UL);
    std::printf("[PASS] 11a: Proactive Stop Invalidation in loop() (>400ms idle) Verified.\n");

    // 11b. Live loop() running during 300-deg startup gap MUST NOT wipe fresh Rising Edge:
    // Machine is stopped for 1.0s. Operator presses pedal -> Rising Edge fires (Light OFF).
    // While motor rotates through the 300-deg gap (33.3 ms at 1500 RPM), loop() executes every 1 ms!
    advanceTimeUs(1000000UL);
    loop();
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb(); // Fresh Rising Edge at pedal start!
    assert(hasValidRisingEdge == true);
    for (int ms = 0; ms < 33; ++ms) {
        advanceTimeUs(1000UL);
        loop(); // loop() running continuously during the 300-deg gap!
        assert(hasValidRisingEdge == true); // MUST NOT wipe the live startup rising edge!
    }
    advanceTimeUs(333UL);
    TIM2->CCR1 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch1Cb(); // Falling Edge arrives after 33,333 us!
    assert(startupMeasuredRpm >= 1495UL && startupMeasuredRpm <= 1505UL);
    assert(hwBurstActive == true);
    while (hwBurstActive) {
        advanceTimeUs(TIM1->ARR + 1UL);
        stepTimer->updateCb();
    }
    loop();
    std::printf("[PASS] 11b: Live loop() during 300-deg startup gap preserves fresh Rising Edge Verified.\n");

    // 11c. Orphan Rising Edge Expiration (>1.8s) in loop():
    // Suppose machine stops with Light ON, then operator bumps handwheel so Light goes OFF,
    // and walks away for 2.0 seconds without completing the rotation.
    advanceTimeUs(500000UL);
    loop(); // Proactive stop invalidation fires here
    advanceTimeUs(100000UL);
    TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
    captureTimer->ch2Cb(); // Hand bump triggers Rising Edge
    assert(hasValidRisingEdge == true);
    advanceTimeUs(1900000UL); // 1.9 seconds pass without Falling Edge
    loop(); // loop() must expire the orphan rising edge (>1.8s old)!
    assert(hasValidRisingEdge == false);
    assert(lastRisingEdgeCaptureUs == 0UL);
    std::printf("[PASS] 11c: Orphan Rising Edge Expiration (>1.8s) in loop() Verified.\n");

    // 11d. Strict Pure V17.1.0 EEPROM Security & Untested Build Rejection:
    // Verify that legacy V17.0.0 (0x5A431700UL) or V16.5.1 (0x5A431651UL) records are STRICTLY rejected,
    // ensuring no corrupt or untested experimental settings can ever contaminate V17.1.0!
    {
        MachineConfigRecord legacy_v17_0;
        std::memset(&legacy_v17_0, 0, sizeof(MachineConfigRecord));
        legacy_v17_0.magic = 0x5A431700UL; // Untested V17.0.0 magic
        legacy_v17_0.seq = 99UL;
        legacy_v17_0.payload.p8_fixed = 99999999ULL; // Corrupted/untested setting
        legacy_v17_0.crc32 = calculateCRC32((const uint8_t*)&legacy_v17_0.payload, sizeof(MachineConfigPayload));

        EEPROM.put(0, legacy_v17_0);
        EEPROM.put(128, legacy_v17_0);

        // Boot V17.1.0: Must reject older legacy magic and preserve clean Factory Defaults!
        eepromSlotInitialized = false;
        activeEEPROMSlot = 0;
        eepromSeqNumber = 0;
        loadFactoryDefaults();
        loadFromEEPROM();
        assert(eepromSlotInitialized == false); // Legacy build strictly rejected!
        assert(p8_fixed == 80000000ULL);        // Clean V17.1.0 Factory Default safe!

        // Now perform a clean V17.1.0 save and verify pure V17.1.0 operation:
        p8_fixed = 82500000ULL;
        currentPulsesFixed = p8_fixed;
        assert(saveToEEPROM() == true);
        assert(activeEEPROMSlot == 1U); // Saved into alternate slot 1

        MachineConfigRecord recSlot1;
        EEPROM.get(128, recSlot1);
        assert(recSlot1.magic == EEPROM_MAGIC_V17_1_0);
        assert(recSlot1.payload.p8_fixed == 82500000ULL);
        assert(recSlot1.crc32 == calculateCRC32((const uint8_t*)&recSlot1.payload, sizeof(MachineConfigPayload)));

        // Power cycle simulation: Reloads pure V17.1.0 record perfectly!
        p8_fixed = 0ULL;
        loadFromEEPROM();
        assert(eepromSlotInitialized == true);
        assert(activeEEPROMSlot == 1U);
        assert(p8_fixed == 82500000ULL);
    }
    std::printf("[PASS] 11d: Strict Pure V17.1.0 EEPROM: Untested builds strictly rejected & clean defaults loaded.\n");

    // 11e. Full End-to-End 0 -> 3000 RPM Instant Servo Jump, Continuous Stitching,
    //      Fractional Accumulator Precision & Zero Needle Collision Audit:
    loadFactoryDefaults();
    currentSize = 2;
    p8_fixed = 80350000ULL; // 80.35 pulses per stitch -> tests 0.35 fractional accumulator!
    currentPulsesFixed = p8_fixed;
    calculateAllPulseWidths();
    refreshPulseTimingValidity();
    stopHardwareTimerImmediately();
    movementState = STATE_IDLE;
    lastTriggerMicros = 0UL;
    hasValidRisingEdge = false;
    lastRisingEdgeCaptureUs = 0UL;
    startupMeasuredRpm = 0UL;
    pulseFracAccumulator = 0UL;

    // Wait 1.0s at standstill, then jump straight to 3000 RPM (20,000 us per 360 deg revolution):
    // 300-deg gap = 16,667 us; 60-deg needle window = 3,333 us.
    // Feed Angle = 90 deg -> 5,000 us feeding window (with 15% safety margin = 4,250 us target).
    advanceTimeUs(1000000UL);
    loop();

    uint32_t totalGeneratedSteps = 0UL;
    for (int stitch = 0; stitch < 20; ++stitch) {
        // Rising Edge (Light OFF as needle leaves sensor slot):
        TIM2->CCR2 = (uint16_t)(get_hardware_timestamp_us() & 0xFFFF);
        captureTimer->ch2Cb();

        // Advance across 300-deg gap (16,667 us) in 1ms steps while running loop():
        for (int ms = 0; ms < 16; ++ms) {
            advanceTimeUs(1000UL);
            loop();
        }
        advanceTimeUs(667UL);

        // Falling Edge (Light ON as needle reaches safe top zone -> Trigger!):
        uint32_t triggerStartUs = get_hardware_timestamp_us();
        TIM2->CCR1 = (uint16_t)(triggerStartUs & 0xFFFF);
        captureTimer->ch1Cb();

        if (stitch == 0) {
            // Stitch #1 must use the 300-deg startup measurement (~3000 RPM):
            assert(startupMeasuredRpm >= 2990UL && startupMeasuredRpm <= 3010UL);
        }

        // Stepper burst must finish well within the 5,000 us 90-deg feeding window (and <16,666 us 300-deg gap!):
        uint32_t stepsThisStitch = 0UL;
        while (hwBurstActive) {
            advanceTimeUs(TIM1->ARR + 1UL);
            stepTimer->updateCb();
            stepsThisStitch++;
        }
        uint32_t burstDurationUs = get_hardware_timestamp_us() - triggerStartUs;
        assert(burstDurationUs <= 5000UL); // 100% Needle Sync Safety: finished within 90-deg feed window!
        totalGeneratedSteps += stepsThisStitch;

        // Advance remaining time of the 3,333 us Light-ON window before next Rising Edge:
        if (burstDurationUs < 3333UL) {
            advanceTimeUs(3333UL - burstDurationUs);
        }
        loop();
    }
    // 20 stitches at 80.35 pulses/stitch = 1607.00 pulses exact! Zero fractional error!
    assert(totalGeneratedSteps == 1607UL);
    assert(pulseFracAccumulator == 0UL);
    std::printf("[PASS] 11e: 0->3000 RPM Instant Jump, Needle Sync Window (<5.0ms / 90-deg) & Exact Fractional Accuracy (1607 steps) Verified.\n");

    // 11f. Standstill Dynamic AUTO Cam Alignment Indicator on Line 1:
    // Operator turns handwheel while stopped:
    // When Cam is aligned (PA0 == LOW / Light ON): Line 1 displays "S:8  AUTO F:1.77"
    // When Cam is not aligned (PA0 == HIGH / Light OFF): Line 1 displays "S:8  0000 F:1.77"
    // When Machine runs (RPM > 0): Line 1 displays live speed "S:8  2400 F:1.77"
    loadFactoryDefaults();
    currentSize = 2; // Size #8
    rollerDia = 45.0f;
    driverResolution = 6400;
    p8_fixed = 80000000ULL;
    currentPulsesFixed = p8_fixed;
    currentRPM = 0UL;
    hwBurstActive = false;
    stepsRemaining = 0;
    menuState = 0;
    oldMenuState = -1;

    // State 1: Standstill with Cam Aligned (PA0 LOW):
    digitalWrite(proxSensorPin, LOW);
    stepLoop(150);
    assert(std::strncmp(lcd.screen[0], "S:8  AUTO F:1.77", 16) == 0);
    assert(std::strncmp(lcd.screen[1], "P:80.0 W:53  [U]", 16) == 0);

    // State 2: Standstill with Cam NOT Aligned (PA0 HIGH):
    digitalWrite(proxSensorPin, HIGH);
    stepLoop(150);
    assert(std::strncmp(lcd.screen[0], "S:8  0000 F:1.77", 16) == 0);

    // State 3: Machine Running at Speed (AUTO instantly vanishes and shows live RPM):
    lastMeasuredIntervalUs = 25000UL;
    currentRPM = 2400UL;
    processSensorTrigger(get_hardware_timestamp_us());
    stopHardwareTimerImmediately();
    stepLoop(300);
    assert(currentRPM > 1000UL);
    char expectedRunningScreen[17];
    snprintf(expectedRunningScreen, sizeof(expectedRunningScreen), "S:8  %04u F:1.77", (unsigned int)currentRPM);
    assert(std::strncmp(lcd.screen[0], expectedRunningScreen, 16) == 0);

    // State 4: Machine stops with needle parked in cam slot:
    currentRPM = 0UL;
    digitalWrite(proxSensorPin, LOW);
    stepLoop(150);
    assert(std::strncmp(lcd.screen[0], "S:8  AUTO F:1.77", 16) == 0);
    std::printf("[PASS] 11f: Standstill Dynamic AUTO Cam Alignment Indicator (S:8  AUTO F:1.77) 100%% Verified.\n");

    // ------------------------------------------------------------------
    // TEST 12: 4x4 Matrix Guided Calibration, Direct Speed Dial (Tenths-Only),
    //          Direct Numeric Settings Entry & Blinking Notification Bell
    // ------------------------------------------------------------------
    loadFactoryDefaults();
    keypadCalibrationLocked = false;
    calibStep = 0;
    currentRPM = 0UL;
    menuState = 0;
    oldMenuState = -1;
    stepLoop(150);
    assert(std::strncmp(lcd.screen[0], "CALIBRATION     ", 16) == 0);
    assert(std::strncmp(lcd.screen[1], "PRESS ANY KEY   ", 16) == 0);

    // Press any 4x4 key ('2' = Row 0 PB12, Col 1 PB9) -> prompts "4X4 DETECTED / PRESS [1] KEY"
    tapMatrixKey(PB12, PB9, 60);
    stepLoop(150);
    assert(calibStep == 2);
    assert(std::strncmp(lcd.screen[0], "4X4 DETECTED    ", 16) == 0);

    // Press '1' (Row 0 PB12, Col 0 PB8) -> prompts "VERIFY KEY: / PRESS [5] KEY"
    tapMatrixKey(PB12, PB8, 60);
    stepLoop(150);
    assert(calibStep == 3);
    assert(std::strncmp(lcd.screen[0], "VERIFY KEY:     ", 16) == 0);

    // Press '5' (Row 1 PB13, Col 1 PB9) -> locks 4x4 Keypad Mode (keypadMode == 2) & saves to EEPROM!
    tapMatrixKey(PB13, PB9, 60);
    assert(keypadCalibrationLocked == true);
    assert(keypadMode == 2U);
    stepLoop(1600); // Let 1.5s lock banner finish

    // Test 4x4 Main Screen Direct Speed Dial: dial "88*54#" -> Tenths-Only rule gives 88.50 (88500000ULL)!
    tapMatrixKey(PB14, PB9, 40);  // '8'
    tapMatrixKey(PB14, PB9, 40);  // '8'
    tapMatrixKey(PB15, PB8, 40);  // '*' (decimal point '.')
    tapMatrixKey(PB13, PB9, 40);  // '5' (1st decimal digit -> accepted)
    tapMatrixKey(PB13, PB8, 40);  // '4' (2nd decimal digit -> strictly discarded!)
    stepLoop(150);
    assert(std::strncmp(lcd.screen[0], "SET: 88.5", 9) == 0);
    tapMatrixKey(PB15, PB10, 40); // '#' (confirm immediately with zero banner delay!)
    assert(currentPulsesFixed == 88500000ULL);
    assert(uiBannerLine1 == nullptr); // Zero "PULSE SAVED!" delay banner!

    // Test 4x4 Direct Numeric Entry in Level 1 Settings Menu (Option 1: Max RPM = 2500):
    menuState = 1;
    hiddenOption = 1;
    isEditingSetting = true;
    settingDigitCursor = 0;
    tapMatrixKey(PB12, PB9, 40);  // '2' -> Thousands
    tapMatrixKey(PB13, PB9, 40);  // '5' -> Hundreds
    tapMatrixKey(PB15, PB9, 40);  // '0' -> Tens
    tapMatrixKey(PB15, PB9, 40);  // '0' -> Units
    assert(tempMaxRPM == 2500);

    // Test 4x4 Numeric Blocking on Option 2 (Motor Dir): pressing '1' or '9' must NOT change tempMotorDir!
    hiddenOption = 2;
    tempMotorDir = false;
    tapMatrixKey(PB12, PB8, 40);  // '1' -> blocked!
    tapMatrixKey(PB14, PB10, 40); // '9' -> blocked!
    assert(tempMotorDir == false);
    tapMatrixKey(PB12, PB11, 40); // 'A' (UP) -> toggles tempMotorDir!
    assert(tempMotorDir == true);
    isEditingSetting = false;
    menuState = 0;
    oldMenuState = -1;

    // Test Blinking Notification Bell ('\x01') at Standstill vs Auto-Hide during Running:
    maxRPMSetting = 3000;
    feedAngleDeg = 90;
    safetyMarginPercent = 15;
    // Set pulse to 580.0 (at 3000 RPM, window = 4250 us -> W = 7 us -> Bell blinks at standstill!)
    currentPulsesFixed = 580000000ULL;
    updateActivePulseWidth();
    assert(activePulseWidth == 7);
    assert(pulseTimingInvalid == true);
    currentRPM = 0UL;
    // Align mockMillis to an even 500ms window so Bell icon ('\x01') is in ON phase:
    g_mockMillis = (g_mockMillis / 1000UL) * 1000UL + 50UL;
    g_mockMicros = g_mockMillis * 1000UL;
    oldMenuState = -1;
    stepLoop(150);
    assert(lcd.screen[1][12] == '\x01'); // Custom Bell icon visible at column 12!

    // Now simulate sewing at 1500 RPM (live W = 14 us >= 8 us -> Bell icon AUTOMATICALLY disappears!):
    currentRPM = 1500UL;
    stepLoop(300);
    assert(lcd.screen[1][12] == ' '); // Bell icon automatically turned OFF during safe running!
    currentRPM = 0UL;
    loadFactoryDefaults();
    std::printf("[PASS] 12: 4x4 Guided Calibration, Direct Speed Dial (88*54# -> 88.50), Settings Numeric Entry & Blinking Bell Verified.\n");

    std::printf("==================================================================\n");
    std::printf("  ALL 9 HIL SUITES PASSED 100%% WITH ZERO WARNINGS OR ERRORS!      \n");
    std::printf("==================================================================\n");
    return 0;
}
